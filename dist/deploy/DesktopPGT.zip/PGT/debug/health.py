#!/usr/bin/env python3
"""
异步健康检查脚本 - 批次轮询（使用 httpx）
每轮并发请求两个 health 端点，都完成后等待 1 秒再开始下一轮。
结果输出到终端（错误红色高亮）并追加保存到 health_results.txt
"""

import asyncio
import sys
from datetime import datetime

import httpx

# 两个目标地址
URLS = [
    "http://127.0.0.1:9099/health",
    "http://127.0.0.1:12580/prod-api/health",
]

LOG_FILE = "health_results.txt"


def format_result(timestamp: str, url: str, status: int | None, content: str | None, error: Exception | None = None):
    """生成统一的日志行"""
    if error:
        return f"[{timestamp}] {url} - ERROR: {error}"
    else:
        preview = (content or "").replace("\n", " ")
        return f"[{timestamp}] {url} - Status: {status} - Response: {preview}"


async def fetch_one(client: httpx.AsyncClient, url: str):
    """
    单个 URL 的请求，返回 (结果字符串, 是否为错误)
    """
    timestamp = datetime.now().isoformat()
    try:
        resp = await client.get(url, timeout=10.0)
        content = resp.text
        status = resp.status_code
        result = format_result(timestamp, url, status, content)
        is_error = status >= 400
    except Exception as e:
        result = format_result(timestamp, url, None, None, error=e)
        is_error = True
    return result, is_error


async def main():
    async with httpx.AsyncClient() as client:
        # 追加模式打开日志文件（可保留历史记录）
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            print(f"开始批次健康检查，日志写入 {LOG_FILE}，按 Ctrl+C 停止...")
            while True:
                # 并发请求两个 URL
                tasks = [fetch_one(client, url) for url in URLS]
                results = await asyncio.gather(*tasks)

                # 处理本轮结果（顺序与 URLS 一致）
                for result, is_error in results:
                    # 终端输出：错误用红色 ANSI 码
                    if is_error:
                        print(f"\033[91m{result}\033[0m")
                    else:
                        print(result)

                    # 写入文件（普通写入，主循环串行，无需锁）
                    f.write(result + "\n")
                    f.flush()   # 实时落盘

                # 本轮全部完成后，等待 1 秒再继续下一轮
                await asyncio.sleep(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n用户中断，脚本已停止。")
        sys.exit(0)