# monitor_system.ps1
# System resource monitor (Memory, CPU, Edge browser, Python processes)
# Logs data to CSV file every second

$LogFile = "SystemMonitor_$(Get-Date -Format 'yyyyMMdd').csv"
$Header = "Timestamp,Total_MB,Used_MB,Free_MB,Mem_Pct,CPU_Pct,Edge_MB,Python_Count,Python_Exe_MB,Python_W_MB,Python_Total_MB"

if (-not (Test-Path $LogFile)) {
    $Header | Out-File -FilePath $LogFile -Encoding UTF8
}

Write-Host "Monitoring started. Log file: $LogFile"
Write-Host "Press Ctrl+C to stop..."

while ($true) {
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    # ---- Memory ----
    $OS = Get-CimInstance -ClassName Win32_OperatingSystem
    $TotalMem = [math]::Round($OS.TotalVisibleMemorySize / 1MB, 2)
    $FreeMem  = [math]::Round($OS.FreePhysicalMemory / 1MB, 2)
    $UsedMem  = $TotalMem - $FreeMem
    $MemPercent = [math]::Round(($UsedMem / $TotalMem) * 100, 1)

    # ---- CPU ----
    $CPU = (Get-Counter -Counter "\Processor(_Total)\% Processor Time" -ErrorAction SilentlyContinue).CounterSamples.CookedValue
    if ($CPU -eq $null) { $CPU = 0 }
    $CPU = [math]::Round($CPU, 1)

    # ---- Edge browser ----
    $EdgeProcs = Get-Process -Name msedge -ErrorAction SilentlyContinue
    $EdgeMem = 0
    if ($EdgeProcs) {
        $EdgeMem = [math]::Round(($EdgeProcs | Measure-Object -Property WorkingSet64 -Sum).Sum / 1MB, 2)
    }

    # ---- Python processes (python.exe and pythonw.exe) ----
    $PyExe = Get-Process -Name python -ErrorAction SilentlyContinue
    $PyW   = Get-Process -Name pythonw -ErrorAction SilentlyContinue

    $PyExeMem = 0
    $PyExeCount = 0
    if ($PyExe) {
        $PyExeCount = $PyExe.Count
        $PyExeMem = [math]::Round(($PyExe | Measure-Object -Property WorkingSet64 -Sum).Sum / 1MB, 2)
    }

    $PyWMem = 0
    $PyWCount = 0
    if ($PyW) {
        $PyWCount = $PyW.Count
        $PyWMem = [math]::Round(($PyW | Measure-Object -Property WorkingSet64 -Sum).Sum / 1MB, 2)
    }

    $PyTotalCount = $PyExeCount + $PyWCount
    $PyTotalMem = [math]::Round($PyExeMem + $PyWMem, 2)

    # ---- Build CSV line ----
    $Line = "$Timestamp,$TotalMem,$UsedMem,$FreeMem,$MemPercent,$CPU,$EdgeMem,$PyTotalCount,$PyExeMem,$PyWMem,$PyTotalMem"
    Add-Content -Path $LogFile -Value $Line -Encoding UTF8

    # ---- Console output ----
    Write-Host "$Timestamp | Memory:$MemPercent% | CPU:$CPU% | Edge:$EdgeMem MB | Python total:$PyTotalCount procs (exe:$PyExeMem MB / w:$PyWMem MB)"

    Start-Sleep -Seconds 1
}