import serial.tools.list_ports

ports = serial.tools.list_ports.comports()

for port in sorted(ports, key=lambda p: p.device):
    print("1", port.device)



import serial

found = []
for i in range(1, 257):
    name = f"COM{i}"
    try:
        s = serial.Serial(name, timeout=0.1)
        s.close()
        found.append(name)
    except (serial.SerialException, OSError):
        pass

for name in found:
    print("2", name)


import winreg

def list_ports_from_registry():
    ports = []
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"HARDWARE\DEVICEMAP\SERIALCOMM")
        i = 0
        while True:
            try:
                name, value, _ = winreg.EnumValue(key, i)
                ports.append(value)
                i += 1
            except OSError:
                break
        winreg.CloseKey(key)
    except FileNotFoundError:
        print("注册表中未找到 SERIALCOMM 项，可能没有串口设备。")
    return sorted(ports)

for port in list_ports_from_registry():
    print("3", port)



import wmi

def list_ports_from_wmi():
    ports = []
    try:
        c = wmi.WMI()
        for p in c.Win32_SerialPort():
            ports.append(p.DeviceID)
    except ImportError:
        print("需要安装 wmi 和 pywin32: pip install wmi pywin32")
    except Exception as e:
        print(f"WMI 查询失败: {e}")
    return sorted(ports)

for port in list_ports_from_wmi():
    print("4", port)