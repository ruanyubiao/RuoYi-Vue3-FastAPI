@echo off
chcp 65001 >nul

cd /d "%~dp0"

docker compose --project-directory D:\docker\mysql up -d
docker compose --project-directory D:\docker\redis up -d
docker compose --project-directory D:\docker\nginx up -d
