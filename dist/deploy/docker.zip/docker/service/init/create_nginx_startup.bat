@echo off
cd /d "%~dp0"

setlocal

set "VBS_NAME=run_start_nginx.vbs"
set "START_BAT=D:\tools\nginx\start_nginx.bat"
set "VBS_PATH=%~dp0%VBS_NAME%"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SHORTCUT_PATH=%STARTUP_DIR%\nginx.lnk"

if not exist "%START_BAT%" (
    echo [ERROR] start_nginx.bat not found at: %START_BAT%
    pause
    exit /b 1
)

(
    echo Set shell = CreateObject("WScript.Shell"^)
    echo shell.Run """%START_BAT%""", 0, False
    echo Set shell = Nothing
) > "%VBS_PATH%"
if errorlevel 1 (
    echo [ERROR] Failed to create VBS file.
    pause
    exit /b 1
)

echo Creating shortcut: %SHORTCUT_PATH%
powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%SHORTCUT_PATH%'); $Shortcut.TargetPath = 'wscript.exe'; $Shortcut.Arguments = '\"%VBS_PATH%\"'; $Shortcut.WorkingDirectory = '%~dp0'; $Shortcut.WindowStyle = 7; $Shortcut.Save()"
if errorlevel 1 (
    echo [ERROR] Failed to create shortcut.
    pause
    exit /b 1
)

echo [SUCCESS] Startup shortcut created.
exit /b 0