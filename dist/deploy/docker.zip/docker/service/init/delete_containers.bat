@echo off
chcp 65001 >nul

cd /d "%~dp0"

docker compose --project-directory D:\docker\mysql down
docker compose --project-directory D:\docker\redis down
docker compose --project-directory D:\docker\nginx down
