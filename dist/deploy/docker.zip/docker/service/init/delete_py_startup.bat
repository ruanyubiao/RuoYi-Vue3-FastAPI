@echo off
set "SHORTCUT=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PyStartup.lnk"
if exist "%SHORTCUT%" (
    del /f /q "%SHORTCUT%"
    echo Deleted.
) else (
    echo Not found.
)
