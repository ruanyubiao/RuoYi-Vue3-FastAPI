@echo off
chcp 65001 >nul

cd /d "%~dp0"

docker compose --project-directory D:\docker\mysql start
docker compose --project-directory D:\docker\redis start
docker compose --project-directory D:\docker\nginx start
