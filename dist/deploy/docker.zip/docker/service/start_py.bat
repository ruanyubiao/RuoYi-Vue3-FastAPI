@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "ScriptPath=%~dp0"
set "DataPath=%LOCALAPPDATA%\PGT"
set "WORKDIR=%DataPath%"


set "PYTHON_EXE=D:\docker\Python\python.exe"
if not exist "%PYTHON_EXE%" (
    for /f "delims=" %%i in ('where python.exe 2^>nul') do (
        set "PYTHON_EXE=%%i"
        goto :python_found
    )

    echo [ERROR] Python not found.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)

:python_found
echo Python: %PYTHON_EXE%


:: ---------- Parse parameters ----------
set "DELAY="
set "HIDE="
for %%a in (%*) do (
    set "arg=%%~a"
    if /i "!arg!"=="hide" (
        set "HIDE=hide"
    ) else (
        rem Check if argument is a number
        set "num=!arg!"
        set /a num=!num! 2>nul
        if not errorlevel 1 (
            set "DELAY=!arg!"
        )
    )
)

:: ---------- 1. Check if service is already running ----------
powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }) { exit 0 } else { exit 1 }"
if %errorlevel% equ 0 (
    echo PGT service is already running.
    powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' } | Select-Object ProcessId,CommandLine"

    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 0
)

:: ---------- 2. Optional delay (skip if 0 or not set) ----------
if defined DELAY (
    if not "%DELAY%"=="0" (
        echo Waiting %DELAY% seconds before starting PGT service...
        timeout /t %DELAY% /nobreak
    )
)

echo Starting PGT service...

:: ---------- 3. Launch based on HIDE parameter ----------
if defined HIDE (
    rem Hidden mode: no window, asynchronous, with working directory
    powershell -NoProfile -Command "Start-Process -FilePath '%PYTHON_EXE%' -ArgumentList '-m','pgt.app','--env','prod' -WorkingDirectory '%WORKDIR%' -WindowStyle Hidden"
) else (
    rem Foreground mode: pop up a new console window, asynchronous, with working directory
    start "" /d "%WORKDIR%" "%PYTHON_EXE%" -m pgt.app --env prod
)

timeout /t 2 /nobreak >nul

:: ---------- 4. Check if started successfully ----------
powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }) { exit 0 } else { exit 1 }"
if %errorlevel% equ 0 (
    echo PGT service started successfully.
    powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' } | Select-Object ProcessId,CommandLine"

    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 0
) else (
    echo PGT service failed to start.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)