@echo off
cd /d "%~dp0"


set "PYTHON_EXE=D:\docker\Python\python.exe"
if not exist "%PYTHON_EXE%" (
    for /f "delims=" %%i in ('where python.exe 2^>nul') do (
        set "PYTHON_EXE=%%i"
        goto :python_found
    )

    echo [ERROR] Python not found.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)

:python_found
echo Python: %PYTHON_EXE%


powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }) { exit 0 } else { exit 1 }"
if %errorlevel% equ 0 (
    echo PGT service is already running.
    powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' } | Select-Object ProcessId,CommandLine"
) else (
    echo PGT service is not running.
)

echo.
echo Waiting for 5 seconds, press a key to continue ...
timeout /t 5
exit /b 0