@echo off
chcp 65001 >nul

cd /d "%~dp0"

docker compose --project-directory D:\docker\mysql stop
docker compose --project-directory D:\docker\redis stop
docker compose --project-directory D:\docker\nginx stop
