@echo off
cd /d "%~dp0"


set "PYTHON_EXE=D:\docker\Python\python.exe"
if not exist "%PYTHON_EXE%" (
    for /f "delims=" %%i in ('where python.exe 2^>nul') do (
        set "PYTHON_EXE=%%i"
        goto :python_found
    )

    echo [ERROR] Python not found.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)

:python_found
echo Python: %PYTHON_EXE%


powershell -NoProfile -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }; if ($p) { $p | Select-Object ProcessId,CommandLine } else { exit 1 }"

if %errorlevel% neq 0 (
    echo PGT service is not running.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 0
)

echo Stopping PGT service...

powershell -NoProfile -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }; foreach ($x in $p) { Stop-Process -Id $x.ProcessId -Force -ErrorAction Stop }"

if %errorlevel% neq 0 (
    echo [ERROR] Failed to stop PGT service.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)

timeout /t 2 /nobreak >nul

powershell -NoProfile -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ExecutablePath -eq '%PYTHON_EXE%' -and $_.CommandLine -like '*pgt.app*' }; if ($p) { exit 1 } else { exit 0 }"

if %errorlevel% equ 0 (
    echo [SUCCESS] PGT service stopped.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 0
) else (
    echo [ERROR] PGT service is still running.
    echo.
    echo Waiting for 5 seconds, press a key to continue ...
    timeout /t 5
    exit /b 1
)