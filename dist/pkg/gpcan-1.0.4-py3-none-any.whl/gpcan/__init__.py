"""pygpcan 公共入口：硬件 SDK + 业务客户端 + 常用类型。

协议层见 ``gpcan.protocol``；厂家驱动见 ``gpcan.sdk``。
"""

from .sdk.can_sdk_def import (
    CanCardParam,
    CanExternFlag,
    CanRecvObj,
    CanRemoteFlag,
    CanRetCode,
    CanSendObj,
    CanSendType,
    CanVendorInfo,
    CanVendorType,
)
from .sdk.can_sdk_client import CanSdkClient
from .protocol.can_protocol_client import CanProtocolClient
from .protocol.can_protocol_def import (
    CanCableParam,
    CanProtocolParam,
    CanProtocolType,
    CanSendParam,
)
from .protocol.can_protocol_base import ProtocolBuildResult, ProtocolParseResult
from .protocol.time_sync import TimeSync, TimeSyncManager

__all__ = [
    "CanRetCode",
    "CanSendType",
    "CanRemoteFlag",
    "CanExternFlag",
    "CanVendorType",
    "CanVendorInfo",
    "CanProtocolType",
    "CanCardParam",
    "CanSendParam",
    "CanCableParam",
    "CanProtocolParam",
    "CanRecvObj",
    "CanSendObj",
    "ProtocolBuildResult",
    "ProtocolParseResult",
    "TimeSync",
    "TimeSyncManager",
    "CanSdkClient",
    "CanProtocolClient",
]
