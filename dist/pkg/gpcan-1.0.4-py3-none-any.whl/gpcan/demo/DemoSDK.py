"""DemoSDK：纯硬件 CanSdkClient 收发界面（支持多通道）。

运行（仓库根目录）::

    python -m gpcan.demo.DemoSDK
"""

from __future__ import annotations

import datetime
import sys
from typing import Any

from PyQt6.QtCore import QMutex, QMutexLocker, QThread, Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from gpcan import (
    CanCardParam,
    CanExternFlag,
    CanRemoteFlag,
    CanRetCode,
    CanSdkClient,
    CanSendObj,
    CanSendType,
    CanVendorType,
)

_DEFAULT_HEX = "00 01 02 03 04 05 06 07"


def _parse_hex(text: str) -> bytes:
    raw = text.replace("\r\n", " ").replace("\n", " ").replace("\t", " ").replace("\r", " ")
    while "  " in raw:
        raw = raw.replace("  ", " ")
    raw = raw.strip()
    if not raw:
        return b""
    return bytes.fromhex(raw.replace(" ", ""))


def _combo_add_enum(
    combo: QComboBox, enum_cls: type, labels: dict[int, str] | None = None
) -> None:
    for item in enum_cls:
        label = labels.get(int(item), item.name) if labels else item.name
        combo.addItem(label, userData=int(item))


def _combo_int(combo: QComboBox) -> int:
    data = combo.currentData()
    return int(data) if data is not None else 0


def _h_spacer() -> QSpacerItem:
    return QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)


class _RecvWorker(QThread):
    """后台持续调用 SDK recv。

    与本通道发送共用 ``io_mutex``，避免同通道并发 send/recv。
    跨通道 recv 串行由厂家 SDK（如 V502）内部处理，Demo 不再跨页签加锁/暂停。
    """

    received = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, io_mutex: QMutex) -> None:
        super().__init__()
        self._client: CanSdkClient | None = None
        self._running = False
        self._client_mutex = QMutex()
        self._io_mutex = io_mutex

    def set_client(self, client: CanSdkClient | None) -> None:
        with QMutexLocker(self._client_mutex):
            self._client = client

    def stop(self) -> None:
        self._running = False
        self.wait(2000)

    def run(self) -> None:
        self._running = True
        while self._running:
            with QMutexLocker(self._client_mutex):
                client = self._client
            if client is None:
                self.msleep(50)
                continue
            try:
                with QMutexLocker(self._io_mutex):
                    frames = client.recv(64)
                for frame in frames:
                    if not self._running:
                        break
                    self.received.emit(frame)
            except Exception as exc:
                self.failed.emit(str(exc))
                self.msleep(100)
                continue
            if not frames:
                self.msleep(10)


class ConnParamDialog(QDialog):
    """连接参数弹窗。"""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("打开 CAN 通道")
        self.setModal(True)
        self.resize(520, 220)

        grid = QGridLayout()

        self._combo_vendor = QComboBox()
        _combo_add_enum(
            self._combo_vendor,
            CanVendorType,
            {
                int(CanVendorType.CAN_VENDOR_DEMO): "Demo 演示",
                int(CanVendorType.CAN_VENDOR_USB_V502): "USB-CAN V502",
                int(CanVendorType.CAN_VENDOR_USB_ALYST_PRO): "USB-CAN Alyst Pro",
                int(CanVendorType.CAN_VENDOR_ZLG): "PCIE ZLG CANFD",
            },
        )
        self._combo_vendor.setCurrentIndex(2)

        self._spin_can_index = QSpinBox()
        self._spin_can_index.setRange(0, 3)

        self._combo_baudrate = QComboBox()
        for rate in (125, 250, 500, 1000):
            self._combo_baudrate.addItem(f"{rate} Kbps", userData=rate)
        self._combo_baudrate.setCurrentIndex(2)

        self._spin_dev_type = QSpinBox()
        self._spin_dev_type.setRange(-1, 9999)
        self._spin_dev_type.setValue(-1)

        self._spin_dev_index = QSpinBox()
        self._spin_dev_index.setRange(0, 99)

        self._spin_read_timeout = QSpinBox()
        self._spin_read_timeout.setRange(0, 60000)
        self._spin_read_timeout.setValue(10)
        self._spin_read_timeout.setSuffix(" ms")

        self._spin_send_sleep = QSpinBox()
        self._spin_send_sleep.setRange(-1, 60000)
        self._spin_send_sleep.setValue(-1)
        self._spin_send_sleep.setSuffix(" ms")

        grid.addWidget(QLabel("厂家"), 0, 0)
        grid.addWidget(self._combo_vendor, 0, 1)
        grid.addWidget(QLabel("通道"), 0, 2)
        grid.addWidget(self._spin_can_index, 0, 3)
        grid.addWidget(QLabel("波特率"), 1, 0)
        grid.addWidget(self._combo_baudrate, 1, 1)
        grid.addWidget(QLabel("设备类型"), 1, 2)
        grid.addWidget(self._spin_dev_type, 1, 3)
        grid.addWidget(QLabel("设备序号"), 2, 0)
        grid.addWidget(self._spin_dev_index, 2, 1)
        grid.addWidget(QLabel("读超时"), 2, 2)
        grid.addWidget(self._spin_read_timeout, 2, 3)
        grid.addWidget(QLabel("发送间隔"), 3, 0)
        grid.addWidget(self._spin_send_sleep, 3, 1)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("打开")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        root = QVBoxLayout(self)
        root.addLayout(grid)
        root.addWidget(buttons)

    def vendor(self) -> int:
        return _combo_int(self._combo_vendor)

    def card_param(self) -> CanCardParam:
        return CanCardParam(
            n_can_index=int(self._spin_can_index.value()),
            n_baud_rate=int(self._combo_baudrate.currentData()),
            n_dev_type=int(self._spin_dev_type.value()),
            n_dev_index=int(self._spin_dev_index.value()),
            n_can_timeout_read_ms=int(self._spin_read_timeout.value()),
            n_can_send_sleep_ms=int(self._spin_send_sleep.value()),
        )

    def tab_title(self) -> str:
        p = self.card_param()
        return f"设备{p.n_dev_index} 通道{p.n_can_index}"


class ChannelPanel(QWidget):
    """单通道：接收数据区 + 基本操作区。"""

    closed = pyqtSignal()

    def __init__(
        self,
        vendor: int,
        card_param: CanCardParam,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._vendor = int(vendor)
        self._card_param = card_param
        self._client: CanSdkClient | None = None
        self._seq = 0
        self._stop_requested = False
        self._sending = False
        self._io_mutex = QMutex()
        self._worker = _RecvWorker(self._io_mutex)
        self._worker.received.connect(self._on_recv_frame)
        self._worker.failed.connect(self._on_recv_failed)
        self._worker.start()

        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(8)
        root.addWidget(self._build_recv_group(), stretch=1)
        root.addWidget(self._build_ops_group())

    @property
    def tab_title(self) -> str:
        p = self._card_param
        return f"设备{p.n_dev_index} 通道{p.n_can_index}"

    @property
    def channel_key(self) -> tuple[int, int, int]:
        """(vendor, dev_index, can_index) 用于判重。"""
        p = self._card_param
        return (self._vendor, int(p.n_dev_index), int(p.n_can_index))

    def open_channel(self) -> None:
        if self._client is not None:
            return
        client = CanSdkClient(self._vendor, self._card_param)
        if client.init_can() != int(CanRetCode.CAN_RET_CODE_OK):
            raise RuntimeError(client.get_last_error() or "init_can 失败")
        if client.open_can() != int(CanRetCode.CAN_RET_CODE_OK):
            client.deinit_can()
            raise RuntimeError(client.get_last_error() or "open_can 失败")
        self._client = client
        self._worker.set_client(client)
        self._set_connected(True)

    def close_channel(self) -> None:
        self._stop_requested = True
        self._worker.set_client(None)
        if self._client is not None:
            self._client.close_can()
            self._client.deinit_can()
            self._client = None
        self._set_connected(False)

    def shutdown(self) -> None:
        self.close_channel()
        self._worker.stop()

    def _build_recv_group(self) -> QGroupBox:
        box = QGroupBox() # "接收数据"
        layout = QVBoxLayout(box)

        bar = QHBoxLayout()
        btn_clear = QPushButton("清空")
        btn_clear.clicked.connect(self._clear_table)
        bar.addWidget(btn_clear)
        bar.addItem(_h_spacer())
        layout.addLayout(bar)

        self._table = QTableWidget(0, 8)
        self._table.setHorizontalHeaderLabels(
            [
                "序号",
                "传输方向",
                "时间标识",
                "帧ID",
                "帧格式",
                "帧类型",
                "数据长度",
                "数据(HEX)",
            ]
        )
        self._table.horizontalHeader().setSectionResizeMode(
            7, QHeaderView.ResizeMode.Stretch
        )
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._table.verticalHeader().setVisible(False)
        mono = QFont("Consolas")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        self._table.setFont(mono)
        layout.addWidget(self._table)
        return box

    def _build_ops_group(self) -> QGroupBox:
        box = QGroupBox("基本操作")
        root = QVBoxLayout(box)

        row0 = QHBoxLayout()
        self._combo_send_type = QComboBox()
        _combo_add_enum(
            self._combo_send_type,
            CanSendType,
            {
                int(CanSendType.CAN_SEND_TYPE_NORMAL): "正常发送",
                int(CanSendType.CAN_SEND_TYPE_SINGLE_SEND): "单次发送",
                int(CanSendType.CAN_SEND_TYPE_SEND_RECV): "自发自收",
                int(CanSendType.CAN_SEND_TYPE_SINGLE_SEND_RECV): "单次自发自收",
            },
        )
        self._combo_extern_flag = QComboBox()
        self._combo_extern_flag.addItem(
            "标准帧", userData=int(CanExternFlag.CAN_EXTERN_FLAG_STANDARD)
        )
        self._combo_extern_flag.addItem(
            "扩展帧", userData=int(CanExternFlag.CAN_EXTERN_FLAG_EXTENDED)
        )
        self._combo_remote_flag = QComboBox()
        self._combo_remote_flag.addItem(
            "数据帧", userData=int(CanRemoteFlag.CAN_REMOTE_FLAG_DATA)
        )
        self._combo_remote_flag.addItem(
            "远程帧", userData=int(CanRemoteFlag.CAN_REMOTE_FLAG_REMOTE)
        )
        row0.addWidget(QLabel("发送方式"))
        row0.addWidget(self._combo_send_type)
        row0.addWidget(QLabel("帧类型"))
        row0.addWidget(self._combo_extern_flag)
        row0.addWidget(QLabel("帧格式"))
        row0.addWidget(self._combo_remote_flag)
        row0.addItem(_h_spacer())
        root.addLayout(row0)

        row1 = QHBoxLayout()
        self._spin_multi_count = QSpinBox()
        self._spin_multi_count.setRange(1, 1000)
        self._spin_multi_count.setValue(1)

        self._spin_send_times = QSpinBox()
        self._spin_send_times.setRange(1, 100000)
        self._spin_send_times.setValue(1)

        self._spin_interval = QSpinBox()
        self._spin_interval.setRange(0, 60000)
        self._spin_interval.setValue(0)
        self._spin_interval.setSuffix(" ms")

        self._chk_id_inc = QCheckBox("帧ID每发送一帧递增")

        row1.addWidget(QLabel("每次发送"))
        row1.addWidget(self._spin_multi_count)
        row1.addWidget(QLabel("帧"))
        row1.addWidget(QLabel("发送次数"))
        row1.addWidget(self._spin_send_times)
        row1.addWidget(QLabel("发送间隔"))
        row1.addWidget(self._spin_interval)
        row1.addWidget(self._chk_id_inc)
        row1.addItem(_h_spacer())
        root.addLayout(row1)

        row2 = QHBoxLayout()
        self._edit_can_id = QLineEdit("00000000")
        self._edit_can_id.setFixedWidth(100)
        self._edit_data = QLineEdit(_DEFAULT_HEX)
        self._edit_data.setMinimumWidth(220)

        self._btn_send = QPushButton("发送")
        self._btn_send.setEnabled(False)
        self._btn_send.setMinimumWidth(80)
        self._btn_send.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self._btn_send.clicked.connect(self._on_send)

        self._btn_stop = QPushButton("停止")
        self._btn_stop.setEnabled(False)
        self._btn_stop.setMinimumWidth(80)
        self._btn_stop.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self._btn_stop.clicked.connect(self._on_stop)

        row2.addWidget(QLabel("帧ID(HEX)"))
        row2.addWidget(self._edit_can_id)
        row2.addWidget(QLabel("数据(HEX)"))
        row2.addWidget(self._edit_data, stretch=1)
        row2.addWidget(self._btn_send)
        row2.addWidget(self._btn_stop)
        row2.addItem(_h_spacer())
        root.addLayout(row2)
        return box

    def _set_connected(self, connected: bool) -> None:
        if not self._sending:
            self._btn_send.setEnabled(connected)
            self._btn_stop.setEnabled(False)

    def _set_sending(self, sending: bool) -> None:
        self._sending = sending
        connected = self._client is not None
        self._btn_send.setEnabled(connected and not sending)
        self._btn_stop.setEnabled(sending)

    def _on_stop(self) -> None:
        self._stop_requested = True

    def _wait_interval(self, interval_ms: int) -> bool:
        left = int(interval_ms)
        while left > 0:
            if self._stop_requested:
                return False
            step = min(50, left)
            QThread.msleep(step)
            left -= step
            QApplication.processEvents()
        return not self._stop_requested

    def _clear_table(self) -> None:
        self._table.setRowCount(0)
        self._seq = 0

    def _append_row(
        self,
        *,
        direction: str,
        can_id: int,
        extern: int,
        remote: int,
        data: bytes,
        time_stamp: int = 0,
    ) -> None:
        row = self._table.rowCount()
        self._table.insertRow(row)
        ts = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
        frame_type = "扩展帧" if extern else "标准帧"
        frame_fmt = "远程帧" if remote else "数据帧"
        values = [
            str(self._seq),
            direction,
            f"{ts}/{time_stamp}" if time_stamp else ts,
            f"{can_id:08X}",
            frame_fmt,
            frame_type,
            str(len(data)),
            data.hex(" ").upper(),
        ]
        self._seq += 1
        for col, text in enumerate(values):
            item = QTableWidgetItem(text)
            if col != 7:
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._table.setItem(row, col, item)
        self._table.scrollToBottom()

    def _on_recv_frame(self, frame: Any) -> None:
        self._append_row(
            direction="接收",
            can_id=int(frame.un_id),
            extern=int(frame.un_extern_flag),
            remote=int(frame.un_remote_flag),
            data=frame.str_data or b"",
            time_stamp=int(getattr(frame, "un_time_stamp", 0) or 0),
        )

    def _on_recv_failed(self, err: str) -> None:
        QMessageBox.warning(self, "接收", err)

    def _on_send(self) -> None:
        if self._client is None or self._sending:
            return
        self._stop_requested = False
        self._set_sending(True)
        try:
            data = _parse_hex(self._edit_data.text())
            can_id = int(self._edit_can_id.text().strip() or "0", 16)
            send_type = _combo_int(self._combo_send_type)
            remote = _combo_int(self._combo_remote_flag)
            extern = _combo_int(self._combo_extern_flag)

            frames_per_burst = int(self._spin_multi_count.value())
            times = int(self._spin_send_times.value())
            interval_ms = int(self._spin_interval.value())
            id_inc = self._chk_id_inc.isChecked()
            id_mask = 0x1FFFFFFF if extern else 0x7FF

            for i in range(times):
                if self._stop_requested:
                    break
                objs: list[CanSendObj] = []
                for _i in range(frames_per_burst):
                    objs.append(
                        CanSendObj(
                            un_send_type=send_type,
                            un_remote_flag=remote,
                            un_extern_flag=extern,
                            un_data_len=len(data),
                            str_data=data,
                            un_id=can_id & id_mask,
                        )
                    )
                    if id_inc:
                        can_id = (can_id + 1) & id_mask

                with QMutexLocker(self._io_mutex):
                    if frames_per_burst == 1:
                        ret = self._client.send_obj(objs[0])
                    else:
                        ret = self._client.send_obj_list(objs)
                if ret != int(CanRetCode.CAN_RET_CODE_OK):
                    raise RuntimeError(self._client.get_last_error() or "发送失败")
                for obj in objs:
                    self._append_row(
                        direction="发送",
                        can_id=obj.un_id,
                        extern=obj.un_extern_flag,
                        remote=obj.un_remote_flag,
                        data=obj.str_data or b"",
                    )
                if id_inc:
                    self._edit_can_id.setText(f"{can_id:08X}")
                QApplication.processEvents()
                if self._stop_requested:
                    break
                if interval_ms > 0 and i + 1 < times:
                    if not self._wait_interval(interval_ms):
                        break
        except Exception as exc:
            QMessageBox.warning(self, "发送", str(exc))
        finally:
            self._set_sending(False)


class DemoSdkWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("DemoSDK")
        self.resize(1000, 720)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        bar = QHBoxLayout()
        self._btn_open = QPushButton("打开通道")
        self._btn_open.clicked.connect(self._on_open_channel)
        self._btn_close = QPushButton("关闭当前通道")
        self._btn_close.setEnabled(False)
        self._btn_close.clicked.connect(self._on_close_current)
        self._lbl_status = QLabel("未打开通道")
        self._lbl_status.setStyleSheet("color:#888;")
        bar.addWidget(self._btn_open)
        bar.addWidget(self._btn_close)
        bar.addWidget(self._lbl_status)
        bar.addItem(_h_spacer())
        root.addLayout(bar)

        self._tabs = QTabWidget()
        self._tabs.setTabsClosable(True)
        self._tabs.tabCloseRequested.connect(self._on_tab_close_requested)
        self._tabs.currentChanged.connect(self._update_status)
        root.addWidget(self._tabs, stretch=1)

        self._update_status()

    def _panels(self) -> list[ChannelPanel]:
        out: list[ChannelPanel] = []
        for i in range(self._tabs.count()):
            w = self._tabs.widget(i)
            if isinstance(w, ChannelPanel):
                out.append(w)
        return out

    def _current_panel(self) -> ChannelPanel | None:
        w = self._tabs.currentWidget()
        return w if isinstance(w, ChannelPanel) else None

    def _update_status(self, *_args: Any) -> None:
        n = self._tabs.count()
        self._btn_close.setEnabled(n > 0)
        if n == 0:
            self._lbl_status.setText("未打开通道")
            self._lbl_status.setStyleSheet("color:#888;")
            return
        panel = self._current_panel()
        title = panel.tab_title if panel is not None else ""
        self._lbl_status.setText(f"已打开 {n} 个通道" + (f"，当前 {title}" if title else ""))
        self._lbl_status.setStyleSheet("color:#2E7D32;")

    def _on_open_channel(self) -> None:
        dlg = ConnParamDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        vendor = dlg.vendor()
        card = dlg.card_param()
        key = (vendor, int(card.n_dev_index), int(card.n_can_index))
        for panel in self._panels():
            if panel.channel_key == key:
                QMessageBox.information(
                    self,
                    "打开通道",
                    f"{dlg.tab_title()} 已打开，切换到已有页签。",
                )
                self._tabs.setCurrentWidget(panel)
                return

        panel = ChannelPanel(vendor, card, parent=self._tabs)
        try:
            panel.open_channel()
        except Exception as exc:
            panel.shutdown()
            QMessageBox.critical(self, "打开失败", str(exc))
            return

        idx = self._tabs.addTab(panel, panel.tab_title)
        self._tabs.setCurrentIndex(idx)
        self._update_status()

    def _close_panel_at(self, index: int) -> None:
        w = self._tabs.widget(index)
        if not isinstance(w, ChannelPanel):
            return
        w.shutdown()
        self._tabs.removeTab(index)
        w.deleteLater()
        self._update_status()

    def _on_tab_close_requested(self, index: int) -> None:
        self._close_panel_at(index)

    def _on_close_current(self) -> None:
        idx = self._tabs.currentIndex()
        if idx >= 0:
            self._close_panel_at(idx)

    def closeEvent(self, event: Any) -> None:
        while self._tabs.count() > 0:
            self._close_panel_at(0)
        super().closeEvent(event)


def main() -> None:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = DemoSdkWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
