"""DemoXL：仅 XL 协议收发界面。

运行（仓库根目录）::

    python -m gpcan.demo.DemoXL
"""

from __future__ import annotations

import datetime
import sys
from typing import Any

from PyQt6.QtCore import (
    QDateTime,
    QMutex,
    Qt,
    QThread,
    QTimer,
    QTime,
    QTimeZone,
    QWaitCondition,
    pyqtSignal,
)
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from gpcan import (
    CanCableParam,
    CanCardParam,
    CanProtocolClient,
    CanProtocolParam,
    CanProtocolType,
    CanRetCode,
    CanSendParam,
    CanVendorType,
    TimeSyncManager,
    ProtocolParseResult,
    ProtocolBuildResult
)
from gpcan.protocol.xl import (
    SystemSecHead,
    XlBroadcastKind,
    XlTmSecHeader,
)
from gpcan.protocol.biu import CanCableFlag

_DEFAULT_HEX = "01 02 03 04 05 06 07 08"
_XL_SEND_PARAM = CanSendParam(un_send_type=0, un_remote_flag=0, un_extern_flag=0)
_CTRL_W = 140
_LABEL_W = 80
_TM_W = _CTRL_W + 20
_TIME_BROADCAST_INTERVAL_MS = 1000
_ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
_DT_FMT = "yyyy-MM-dd HH:mm:ss"
_CHK_GRAY_STYLE = """
QCheckBox::indicator:unchecked {
    background: #5a5a5a;
    border: 1px solid #8a8a8a;
}
"""


def _ts():
    return TimeSyncManager.find(CanProtocolType.XL)


def _parse_hex(text: str) -> bytes:
    raw = text.replace("\r\n", " ").replace("\n", " ").replace("\t", " ").replace("\r", " ")
    while "  " in raw:
        raw = raw.replace("  ", " ")
    raw = raw.strip()
    if not raw:
        return b""
    return bytes.fromhex(raw.replace(" ", ""))


def _combo_add_enum(combo: QComboBox, enum_cls: type, labels: dict[int, str] | None = None) -> None:
    for item in enum_cls:
        label = labels.get(int(item), item.name) if labels else item.name
        combo.addItem(label, userData=int(item))


def _h_spacer() -> QSpacerItem:
    return QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)


def _r_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setAlignment(_ALIGN_RIGHT)
    lbl.setMinimumWidth(_LABEL_W)
    lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
    return lbl


def _add_r_label(grid: QGridLayout, text: str, row: int, col: int) -> None:
    grid.addWidget(_r_label(text), row, col, alignment=_ALIGN_RIGHT)


def _form_ctrl(w: QWidget) -> QWidget:
    w.setFixedWidth(_CTRL_W)
    w.setMinimumHeight(26)
    return w


def _make_utc_datetime_edit() -> QDateTimeEdit:
    edit = QDateTimeEdit()
    edit.setTimeSpec(Qt.TimeSpec.UTC)
    edit.setTimeZone(QTimeZone.utc())
    edit.setCalendarPopup(True)
    edit.setDisplayFormat(_DT_FMT)
    edit.setDateTime(QDateTime.currentDateTimeUtc())
    edit.setFixedWidth(200)
    edit.setMinimumHeight(26)
    return edit


def _datetime_epoch_ms_floor_sec(edit: QDateTimeEdit) -> int:
    dt = edit.dateTime().toUTC()
    t = dt.time()
    dt = QDateTime(dt.date(), QTime(t.hour(), t.minute(), t.second(), 0), QTimeZone.utc())
    return int(dt.toSecsSinceEpoch()) * 1000


class _RecvWorker(QThread):
    received = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self) -> None:
        super().__init__()
        self._client: CanProtocolClient | None = None
        self._running = False
        self._mutex = QMutex()
        self._wake = QWaitCondition()

    def set_client(self, client: CanProtocolClient | None) -> None:
        self._mutex.lock()
        self._client = client
        self._mutex.unlock()

    def stop(self) -> None:
        self._running = False
        self._wake.wakeAll()
        self.wait(2000)

    def run(self) -> None:
        self._running = True
        while self._running:
            self._mutex.lock()
            client = self._client
            self._mutex.unlock()
            if client is None:
                self.msleep(50)
                continue
            try:
                msg = client.recv_msg(64)
                if msg is not None:
                    self.received.emit(msg)
            except Exception as exc:
                self.failed.emit(str(exc))
                self.msleep(100)
                continue
            self.msleep(10)


class DemoXlWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("DemoXL")
        self.resize(980, 760)

        self._client: CanProtocolClient | None = None
        self._worker = _RecvWorker()
        self._worker.received.connect(self._on_recv_msg)
        self._worker.failed.connect(self._on_recv_failed)
        self._worker.start()

        self._broadcast_timer = QTimer(self)
        self._broadcast_timer.setInterval(_TIME_BROADCAST_INTERVAL_MS)
        self._broadcast_timer.timeout.connect(self._on_time_broadcast_tick)

        self._build_ui()
        self._set_connected(False)

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        root.addWidget(self._build_conn_group())
        root.addWidget(self._build_xl_group())
        root.addWidget(self._build_time_sync_group())
        root.addWidget(self._build_payload_group())
        root.addWidget(self._build_recv_group(), stretch=1)

    def _build_conn_group(self) -> QGroupBox:
        box = QGroupBox("连接参数")
        grid = QGridLayout(box)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(6)

        self._combo_vendor = QComboBox()
        _combo_add_enum(
            self._combo_vendor,
            CanVendorType,
            {
                int(CanVendorType.CAN_VENDOR_DEMO): "Demo 演示",
                int(CanVendorType.CAN_VENDOR_USB_V502): "USB-CAN V502",
                int(CanVendorType.CAN_VENDOR_USB_ALYST_PRO): "USB-CAN Alyst Pro",
                int(CanVendorType.CAN_VENDOR_ZLG): "PCIE ZLG CANFD",
            },
        )
        self._combo_vendor.setCurrentIndex(
            max(0, self._combo_vendor.findData(int(CanVendorType.CAN_VENDOR_USB_V502)))
        )
        _form_ctrl(self._combo_vendor)

        self._spin_dev_index = QSpinBox()
        self._spin_dev_index.setRange(0, 99)
        _form_ctrl(self._spin_dev_index)

        self._spin_can_index = QSpinBox()
        self._spin_can_index.setRange(0, 3)
        _form_ctrl(self._spin_can_index)

        self._combo_baudrate = QComboBox()
        for rate in (125, 250, 500, 1000):
            self._combo_baudrate.addItem(f"{rate} Kbps", userData=rate)
        self._combo_baudrate.setCurrentIndex(2)
        _form_ctrl(self._combo_baudrate)

        self._spin_dev_type = QSpinBox()
        self._spin_dev_type.setRange(-1, 9999)
        self._spin_dev_type.setValue(-1)
        _form_ctrl(self._spin_dev_type)

        self._spin_read_timeout = QSpinBox()
        self._spin_read_timeout.setRange(0, 60000)
        self._spin_read_timeout.setValue(10)
        self._spin_read_timeout.setSuffix(" ms")
        _form_ctrl(self._spin_read_timeout)

        self._spin_send_sleep = QSpinBox()
        self._spin_send_sleep.setRange(-1, 60000)
        self._spin_send_sleep.setValue(-1)
        self._spin_send_sleep.setSuffix(" ms")
        _form_ctrl(self._spin_send_sleep)

        self._btn_open = QPushButton("打开 CAN")
        self._btn_open.setFixedWidth(_CTRL_W)
        self._btn_open.clicked.connect(self._on_open)
        self._btn_close = QPushButton("关闭 CAN")
        self._btn_close.setFixedWidth(_CTRL_W)
        self._btn_close.clicked.connect(self._on_close)
        self._lbl_status = QLabel("未连接")
        self._lbl_status.setStyleSheet("color:#888;")

        _add_r_label(grid, "厂家", 0, 0)
        grid.addWidget(self._combo_vendor, 0, 1)
        _add_r_label(grid, "设备序号", 0, 2)
        grid.addWidget(self._spin_dev_index, 0, 3)
        _add_r_label(grid, "通道", 0, 4)
        grid.addWidget(self._spin_can_index, 0, 5)
        _add_r_label(grid, "波特率", 0, 6)
        grid.addWidget(self._combo_baudrate, 0, 7)

        _add_r_label(grid, "设备类型", 1, 0)
        grid.addWidget(self._spin_dev_type, 1, 1)
        _add_r_label(grid, "读超时", 1, 2)
        grid.addWidget(self._spin_read_timeout, 1, 3)
        _add_r_label(grid, "发送间隔", 1, 4)
        grid.addWidget(self._spin_send_sleep, 1, 5)
        grid.addWidget(self._btn_open, 1, 6)
        grid.addWidget(self._btn_close, 1, 7)
        grid.addWidget(self._lbl_status, 1, 8)
        grid.setColumnStretch(9, 1)
        return box

    def _build_xl_group(self) -> QGroupBox:
        box = QGroupBox("XL 业务参数")
        grid = QGridLayout(box)
        grid.setHorizontalSpacing(6)

        self._combo_cable_flag = QComboBox()
        _combo_add_enum(
            self._combo_cable_flag,
            CanCableFlag,
            {
                int(CanCableFlag.CAN_CABLE_FLAG_A): "0 A 线",
                int(CanCableFlag.CAN_CABLE_FLAG_B): "1 B 线",
            },
        )
        _form_ctrl(self._combo_cable_flag)

        grid.addWidget(_r_label("线缆"), 0, 0, alignment=_ALIGN_RIGHT)
        grid.addWidget(self._combo_cable_flag, 0, 1)
        grid.setColumnStretch(2, 1)
        return box

    def _build_time_sync_group(self) -> QGroupBox:
        box = QGroupBox("时间同步")
        layout = QVBoxLayout(box)
        layout.setSpacing(6)

        self._edit_payload_time = _make_utc_datetime_edit()
        self._chk_use_system_time = QCheckBox("使用系统当前时间")
        self._chk_use_system_time.setStyleSheet(_CHK_GRAY_STYLE)
        self._chk_use_system_time.toggled.connect(self._on_use_system_time_toggled)

        self._btn_set_payload_time = QPushButton("设置载荷时间")
        self._btn_set_payload_time.setFixedWidth(_CTRL_W)
        self._btn_set_payload_time.clicked.connect(self._on_set_payload_time)


        hint_payload = QLabel("不受起始时间和时间偏差影响")
        hint_payload.setStyleSheet("color:#666;")

        row1 = QHBoxLayout()
        row1.setSpacing(6)
        row1.addWidget(_r_label("载荷时间(UTC0时区)"))
        row1.addWidget(self._edit_payload_time)
        row1.addWidget(self._chk_use_system_time)
        row1.addWidget(self._btn_set_payload_time)
        row1.addWidget(hint_payload)
        row1.addItem(_h_spacer())
        layout.addLayout(row1)

        self._edit_start_time = _make_utc_datetime_edit()
        self._btn_set_start_time = QPushButton("设置")
        self._btn_set_start_time.setFixedWidth(72)
        self._btn_set_start_time.clicked.connect(self._on_set_start_time)

        self._btn_reset_offset = QPushButton("重置")
        self._btn_reset_offset.setFixedWidth(72)
        self._btn_reset_offset.clicked.connect(self._on_reset_offset)

        self._edit_offset_ms = QLineEdit("0")
        self._edit_offset_ms.setFixedWidth(120)
        self._edit_offset_ms.setMinimumHeight(26)
        self._edit_offset_ms.setPlaceholderText("毫秒")

        self._btn_set_offset = QPushButton("设置")
        self._btn_set_offset.setFixedWidth(72)
        self._btn_set_offset.clicked.connect(self._on_set_offset)

        row2 = QHBoxLayout()
        row2.setSpacing(6)
        row2.addWidget(_r_label("时间同步的起始时间(UTC0时区)"))
        row2.addWidget(self._edit_start_time)
        row2.addWidget(self._btn_set_start_time)
        row2.addWidget(self._btn_reset_offset)
        row2.addWidget(_r_label("系统时间偏差"))
        row2.addWidget(self._edit_offset_ms)
        row2.addWidget(QLabel("ms"))
        row2.addWidget(self._btn_set_offset)
        row2.addItem(_h_spacer())
        layout.addLayout(row2)

        hint = QLabel(
            "提示：设置起始时间后会计算偏差并显示。定时广播使用「系统时间 + 偏差」。"
            "XL 时间帧为星务对时广播（EPOCH 2015）。"
        )
        hint.setStyleSheet("color:#666;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self._btn_broadcast_open = QPushButton("打开")
        self._btn_broadcast_open.setFixedWidth(72)
        self._btn_broadcast_open.clicked.connect(self._on_broadcast_start)

        self._btn_broadcast_close = QPushButton("关闭")
        self._btn_broadcast_close.setFixedWidth(72)
        self._btn_broadcast_close.clicked.connect(self._on_broadcast_stop)

        row3 = QHBoxLayout()
        row3.setSpacing(6)
        row3.addWidget(_r_label("定时同步广播"))
        row3.addWidget(self._btn_broadcast_open)
        row3.addWidget(self._btn_broadcast_close)
        row3.addItem(_h_spacer())
        layout.addLayout(row3)

        self._chk_gnss_valid = QCheckBox("时间同步 GNSS 有效")
        self._chk_gnss_valid.setStyleSheet(_CHK_GRAY_STYLE)
        self._chk_gnss_valid.setChecked(True)
        row0 = QHBoxLayout()
        row0.setSpacing(6)
        row0.addWidget(self._chk_gnss_valid)
        row0.addItem(_h_spacer())
        layout.addLayout(row0)
        return box

    def _build_payload_group(self) -> QGroupBox:
        box = QGroupBox("发送数据")
        layout = QVBoxLayout(box)

        self._hex_edit = QPlainTextEdit()
        self._hex_edit.setPlaceholderText("十六进制 payload，如: 01 02 03 04 05 06 07 08")
        self._hex_edit.setPlainText(_DEFAULT_HEX)
        self._hex_edit.setFixedHeight(72)
        layout.addWidget(self._hex_edit)

        btn_w = 160
        self._btn_send_tc = QPushButton("发送遥控指令")
        self._btn_send_tc.setFixedWidth(btn_w)
        self._btn_send_tc.clicked.connect(self._on_send_telecommand)

        self._btn_send_bc_att = QPushButton("发送姿控广播数据")
        self._btn_send_bc_att.setFixedWidth(btn_w)
        self._btn_send_bc_att.clicked.connect(
            lambda: self._on_send_broadcast(int(XlBroadcastKind.ATTITUDE))
        )

        self._btn_send_bc_gnss = QPushButton("发送GNSS广播数据")
        self._btn_send_bc_gnss.setFixedWidth(btn_w)
        self._btn_send_bc_gnss.clicked.connect(
            lambda: self._on_send_broadcast(int(XlBroadcastKind.GNSS))
        )

        row_send = QHBoxLayout()
        row_send.setSpacing(6)
        row_send.addWidget(self._btn_send_tc)
        row_send.addWidget(self._btn_send_bc_att)
        row_send.addWidget(self._btn_send_bc_gnss)
        row_send.addItem(_h_spacer())
        layout.addLayout(row_send)

        self._combo_tm_code = QComboBox()
        for code, label in (
            (int(XlTmSecHeader.POLL_CLASS_1), "0x01 一类轮询-速变遥测"),
            (int(XlTmSecHeader.POLL_CLASS_2), "0x02 二类轮询-缓变遥测"),
        ):
            self._combo_tm_code.addItem(label, userData=code)
        self._combo_tm_code.setFixedWidth(_TM_W)
        self._combo_tm_code.setMinimumHeight(26)

        self._btn_tm_send = QPushButton("发送遥测请求")
        self._btn_tm_send.setFixedWidth(btn_w)
        self._btn_tm_send.clicked.connect(self._on_send_tm)

        self._btn_send_tm_data = QPushButton("发送遥测数据")
        self._btn_send_tm_data.setFixedWidth(btn_w)
        self._btn_send_tm_data.clicked.connect(self._on_send_telemetry)

        row_tm = QHBoxLayout()
        row_tm.setSpacing(6)
        row_tm.addWidget(self._combo_tm_code)
        row_tm.addWidget(self._btn_tm_send)
        row_tm.addWidget(self._btn_send_tm_data)
        row_tm.addItem(_h_spacer())
        layout.addLayout(row_tm)

        self._combo_reset_type = QComboBox()
        for code, label in (
            (int(SystemSecHead.RESET_BUS_A), "0xFA A 总线复位"),
            (int(SystemSecHead.RESET_BUS_B), "0xFB B 总线复位"),
            (int(SystemSecHead.HEARTBEAT), "0xF1 心跳测试"),
            (int(SystemSecHead.SAFE_SHUTDOWN), "0xFF 安全关机"),
        ):
            self._combo_reset_type.addItem(label, userData=code)
        self._combo_reset_type.setFixedWidth(_TM_W)
        self._combo_reset_type.setMinimumHeight(26)

        self._btn_reset = QPushButton("系统指令")
        self._btn_reset.setFixedWidth(_TM_W)
        self._btn_reset.clicked.connect(self._on_send_reset)

        self._chk_system_broadcast = QCheckBox("系统命令广播(nid=0xFF)")
        self._chk_system_broadcast.setStyleSheet(_CHK_GRAY_STYLE)

        row_reset = QHBoxLayout()
        row_reset.setSpacing(6)
        row_reset.addWidget(self._combo_reset_type)
        row_reset.addWidget(self._btn_reset)
        row_reset.addWidget(self._chk_system_broadcast)
        row_reset.addItem(_h_spacer())
        layout.addLayout(row_reset)
        return box

    def _build_recv_group(self) -> QGroupBox:
        box = QGroupBox("XL 接收（协议组装后）")
        layout = QVBoxLayout(box)
        bar = QHBoxLayout()
        btn_clear = QPushButton("清空")
        bar.addWidget(btn_clear)
        bar.addItem(_h_spacer())
        layout.addLayout(bar)

        self._recv_log = QPlainTextEdit()
        self._recv_log.setReadOnly(True)
        mono = QFont("Consolas")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        self._recv_log.setFont(mono)
        layout.addWidget(self._recv_log)
        btn_clear.clicked.connect(self._recv_log.clear)
        return box

    def _combo_int(self, combo: QComboBox) -> int:
        data = combo.currentData()
        return int(data) if data is not None else 0

    def _apply_cable_param(self) -> None:
        assert self._client is not None
        self._client.set_cable_param(
            CanCableParam(n_cable_flag=self._combo_int(self._combo_cable_flag))
        )

    def _build_client(self) -> CanProtocolClient:
        return CanProtocolClient(
            self._combo_int(self._combo_vendor),
            CanCardParam(
                n_can_index=int(self._spin_can_index.value()),
                n_baud_rate=int(self._combo_baudrate.currentData()),
                n_dev_type=int(self._spin_dev_type.value()),
                n_dev_index=int(self._spin_dev_index.value()),
                n_can_timeout_read_ms=int(self._spin_read_timeout.value()),
                n_can_send_sleep_ms=int(self._spin_send_sleep.value()),
            ),
            cable_param=CanCableParam(
                n_cable_flag=self._combo_int(self._combo_cable_flag)
            ),
            protocol_param=CanProtocolParam(type=CanProtocolType.XL),
            send_param=_XL_SEND_PARAM,
        )

    def _set_connected(self, connected: bool) -> None:
        self._btn_open.setEnabled(not connected)
        self._btn_close.setEnabled(connected)
        for btn in (
            self._btn_send_tc,
            self._btn_send_bc_att,
            self._btn_send_bc_gnss,
            self._btn_send_tm_data,
            self._btn_tm_send,
            self._btn_reset,
        ):
            btn.setEnabled(connected)
        if not connected and self._broadcast_timer.isActive():
            self._broadcast_timer.stop()
        self._update_time_sync_buttons(connected)
        self._lbl_status.setText("已连接" if connected else "未连接")
        self._lbl_status.setStyleSheet(
            "color:#2E7D32;" if connected else "color:#888;"
        )

    def _update_time_sync_buttons(self, connected: bool | None = None) -> None:
        if connected is None:
            connected = self._client is not None
        broadcasting = self._broadcast_timer.isActive()
        self._btn_set_start_time.setEnabled(True)
        self._btn_reset_offset.setEnabled(True)
        self._btn_set_offset.setEnabled(True)
        can_oneshot = connected and not broadcasting
        self._btn_set_payload_time.setEnabled(can_oneshot)
        self._chk_use_system_time.setEnabled(can_oneshot)
        if can_oneshot:
            self._edit_payload_time.setEnabled(
                not self._chk_use_system_time.isChecked()
            )
        else:
            self._edit_payload_time.setEnabled(False)
        self._btn_broadcast_open.setEnabled(connected and not broadcasting)
        self._btn_broadcast_close.setEnabled(connected and broadcasting)

    def _send_built(self, built: ProtocolBuildResult, log_prefix: str, log_extra: str = "") -> None:
        assert self._client is not None
        if built is None:
            raise RuntimeError("组包失败")
        ret = self._client.send_msg(built)
        if ret != int(CanRetCode.CAN_RET_CODE_OK):
            raise RuntimeError(self._client.get_last_error() or "发送失败")

        log = log_prefix
        if built.packet_param is not None and built.packet_param.sec_header is not None:
            log += f" sec=0x{built.packet_param.sec_header:02X}"
        log += f"data={built.data.hex(' ').upper()}  len={len(built.data)} {log_extra}"
        self._append_log(log)

    def _on_open(self) -> None:
        if self._client is not None:
            return
        try:
            client = self._build_client()
            if client.init_can() != int(CanRetCode.CAN_RET_CODE_OK):
                raise RuntimeError("init_can 失败")
            if client.open_can() != int(CanRetCode.CAN_RET_CODE_OK):
                raise RuntimeError("open_can 失败")
            self._client = client
            self._worker.set_client(client)
            self._set_connected(True)
            self._append_log("CAN 已打开 (XL)")
        except Exception as exc:
            self._client = None
            self._worker.set_client(None)
            QMessageBox.critical(self, "打开失败", str(exc))

    def _on_close(self) -> None:
        self._broadcast_timer.stop()
        self._worker.set_client(None)
        if self._client is not None:
            self._client.close_can()
            self._client.deinit_can()
            self._client = None
        self._set_connected(False)
        self._append_log("CAN 已关闭")

    def _show_offset_ms(self) -> None:
        self._edit_offset_ms.setText(str(int(_ts().offset_ms)))

    def _on_use_system_time_toggled(self, checked: bool) -> None:
        self._edit_payload_time.setEnabled(not checked)
        self._update_time_sync_buttons()

    def _on_set_start_time(self) -> None:
        try:
            start_ms = _datetime_epoch_ms_floor_sec(self._edit_start_time)
            dt = QDateTime.fromMSecsSinceEpoch(start_ms, QTimeZone.utc())
            _ts().set_payload_time(start_ms)
            self._show_offset_ms()
            self._append_log(
                f"已设起始时间 UTC {dt.toString(_DT_FMT)} "
                f"→ offset_ms={_ts().offset_ms}"
            )
        except Exception as exc:
            QMessageBox.warning(self, "设置起始时间", str(exc))

    def _on_set_offset(self) -> None:
        try:
            text = self._edit_offset_ms.text().strip().replace(",", "")
            offset_ms = int(text, 10)
            _ts().set_offset(offset_ms)
            self._show_offset_ms()
            self._append_log(f"已设系统时间偏差 offset_ms={_ts().offset_ms}")
        except Exception as exc:
            QMessageBox.warning(self, "设置系统时间偏差", str(exc))

    def _on_reset_offset(self) -> None:
        try:
            _ts().set_offset(0)
            self._show_offset_ms()
            self._append_log("已重置系统时间偏差 offset_ms=0")
        except Exception as exc:
            QMessageBox.warning(self, "重置系统时间偏差", str(exc))

    def _send_time_sync_absolute(self, epoch_ms: int, log_prefix: str) -> None:
        assert self._client is not None
        sec = int(epoch_ms) // 1000
        built = self._client.builder.build_time_sync(
            sec,
            0,
            apply_offset=False,
            gnss_valid=self._chk_gnss_valid.isChecked(),
        )
        self._send_built(built, log_prefix)

    def _send_time_sync_with_offset(self, log_prefix: str) -> None:
        assert self._client is not None
        payload_ms = _ts().get_payload_time_ms()
        sec = int(payload_ms) // 1000
        built = self._client.builder.build_time_sync(
            sec,
            0,
            apply_offset=False,
            gnss_valid=self._chk_gnss_valid.isChecked(),
        )
        self._send_built(
            built,
            f"{log_prefix} payload_sec={sec} offset_ms={_ts().offset_ms} "
        )

    def _on_set_payload_time(self) -> None:
        if self._client is None or self._broadcast_timer.isActive():
            return
        try:
            if self._chk_use_system_time.isChecked():
                now = QDateTime.currentDateTimeUtc()
                self._edit_payload_time.setDateTime(now)
                epoch_ms = _datetime_epoch_ms_floor_sec(self._edit_payload_time)
                dt = QDateTime.fromMSecsSinceEpoch(epoch_ms, QTimeZone.utc())
                prefix = f"TX time_sync absolute now UTC {dt.toString(_DT_FMT)}"
            else:
                epoch_ms = _datetime_epoch_ms_floor_sec(self._edit_payload_time)
                dt = QDateTime.fromMSecsSinceEpoch(epoch_ms, QTimeZone.utc())
                prefix = f"TX time_sync absolute UTC {dt.toString(_DT_FMT)}"
            self._send_time_sync_absolute(epoch_ms, prefix)
        except Exception as exc:
            QMessageBox.warning(self, "设置载荷时间", str(exc))

    def _on_broadcast_start(self) -> None:
        if self._client is None:
            return
        self._broadcast_timer.start()
        self._update_time_sync_buttons()
        self._append_log("打开定时时间广播（每秒，系统时间+偏差）")
        self._on_time_broadcast_tick()

    def _on_broadcast_stop(self) -> None:
        self._broadcast_timer.stop()
        self._update_time_sync_buttons()
        self._append_log("关闭定时时间广播")

    def _on_time_broadcast_tick(self) -> None:
        if self._client is None:
            self._broadcast_timer.stop()
            self._update_time_sync_buttons()
            return
        try:
            self._send_time_sync_with_offset("TX time_broadcast")
        except Exception as exc:
            self._broadcast_timer.stop()
            self._update_time_sync_buttons()
            QMessageBox.warning(self, "定时时间广播", str(exc))

    def _send_hex_payload(self, kind: str, *, bc_kind: int | None = None) -> None:
        if self._client is None:
            return
        try:
            self._apply_cable_param()
            data = _parse_hex(self._hex_edit.toPlainText())
            if kind == "broadcast":
                assert bc_kind is not None
                built = self._client.builder.build_broadcast(data, kind=bc_kind)
                mode = f"broadcast kind={bc_kind}"
                title = "发送广播数据"
            elif kind == "telemetry":
                sh = self._combo_int(self._combo_tm_code)
                built = self._client.builder.build_telemetry_response(
                    data, sec_header=sh
                )
                mode = f"telemetry_response sec=0x{sh:02X}"
                title = "发送遥测数据"
            else:
                built = self._client.builder.build_telecommand(data)
                mode = "telecommand"
                title = "发送遥控指令"
            self._send_built(
                built, f"TX {mode}"
            )
        except Exception as exc:
            QMessageBox.warning(self, title, str(exc))

    def _on_send_telecommand(self) -> None:
        self._send_hex_payload("telecommand")

    def _on_send_broadcast(self, bc_kind: int) -> None:
        self._send_hex_payload("broadcast", bc_kind=bc_kind)

    def _on_send_telemetry(self) -> None:
        self._send_hex_payload("telemetry")

    def _on_send_tm(self) -> None:
        if self._client is None:
            return
        try:
            self._apply_cable_param()
            sec_header = self._combo_int(self._combo_tm_code)
            built = self._client.builder.build_telemetry_request(sec_header)
            self._send_built(built, f"TX telemetry_request")
        except Exception as exc:
            QMessageBox.warning(self, "遥测请求", str(exc))

    def _on_send_reset(self) -> None:
        if self._client is None:
            return
        try:
            self._apply_cable_param()
            cmd = self._combo_int(self._combo_reset_type)
            broadcast = self._chk_system_broadcast.isChecked()
            built = self._client.builder.build_system(cmd, broadcast=broadcast)
            self._send_built(
                built,
                f"TX system cmd=0x{cmd:02X} broadcast={int(broadcast)}",
            )
        except Exception as exc:
            QMessageBox.warning(self, "系统指令", str(exc))

    def _on_recv_msg(self, obj: ProtocolParseResult) -> None:
        log = f"RX id=0x{obj.un_id:X} src={len(obj.src)}"
        if obj.packet_param is not None and "sec_header" in obj.packet_param:
            log += f" sec=0x{obj.packet_param['sec_header']:02X}"
        log += f" data={obj.data.hex(' ')} payload={obj.payload.hex(' ')}"
        self._append_log(log)

    def _on_recv_failed(self, err: str) -> None:
        self._append_log(f"RECV error: {err}")

    def _append_log(self, text: str) -> None:
        ts = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
        self._recv_log.appendPlainText(f"[{ts}] {text}")

    def closeEvent(self, event: Any) -> None:
        self._broadcast_timer.stop()
        self._worker.set_client(None)
        self._worker.stop()
        if self._client is not None:
            self._client.close_can()
            self._client.deinit_can()
            self._client = None
        super().closeEvent(event)


def main() -> None:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = DemoXlWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
