"""GUI 演示：``DemoSDK`` / ``DemoBIU`` / ``DemoXL``。

在仓库根目录::

    python -m gpcan.demo.DemoSDK
    python -m gpcan.demo.DemoBIU
    python -m gpcan.demo.DemoXL
"""
