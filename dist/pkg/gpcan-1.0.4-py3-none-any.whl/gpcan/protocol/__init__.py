"""协议层：组包 / 分片 / Builder / Parser / 业务客户端。

对外常用：``CanProtocolType`` / ``CanSendParam`` / ``CanCableParam`` /
``CanProtocolParam`` / ``CanProtocolClient``。BIU / XL / NONE 从对应子包导入。
"""

from .can_protocol_base import (
    PacketDecoder,
    PacketEncoder,
    ProtocolBuilderBase,
    ProtocolBuildResult,
    ProtocolParseResult,
    ProtocolParserBase,
    Segmenter,
)
from .can_protocol_client import CanProtocolClient
from .can_protocol_def import (
    CanCableParam,
    CanProtocolParam,
    CanProtocolType,
    CanSendParam,
)
from .fixed_segment import FixedLengthSegmenter
from .identity_packet import IdentityPacketDecoder, IdentityPacketEncoder
from .time_sync import TimeSync, TimeSyncManager

__all__ = [
    "CanCableParam",
    "CanProtocolClient",
    "CanProtocolParam",
    "CanProtocolType",
    "CanSendParam",
    "FixedLengthSegmenter",
    "IdentityPacketDecoder",
    "IdentityPacketEncoder",
    "PacketDecoder",
    "PacketEncoder",
    "ProtocolBuildResult",
    "ProtocolBuilderBase",
    "ProtocolParseResult",
    "ProtocolParserBase",
    "Segmenter",
    "TimeSync",
    "TimeSyncManager",
]
