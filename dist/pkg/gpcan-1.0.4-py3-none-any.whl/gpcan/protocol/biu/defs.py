"""BIU 项目协议定义（枚举与业务参数）。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class CanNodeType(IntEnum):
    """节点类型（ID 第 10 位）。"""

    CAN_NODE_TYPE_MASTER = 0  # 主节点, 如上位机
    CAN_NODE_TYPE_SLAVE = 1   # 从节点，如激光终端


class CanFrameType(IntEnum):
    """帧类型（ID 第 9~8 位）。需由 通信方式 与 数据类型 两部分按位组合。"""

    CAN_FRAME_TYPE_POINT_TO_POINT = 0x2        # 点对点通信
    CAN_FRAME_TYPE_BROADCAST = 0x0             # 广播通信
    CAN_FRAME_TYPE_APPLICATION_DATA_CMD = 0x1  # 应用相关数据与命令
    CAN_FRAME_TYPE_BUS_DATA_CMD = 0x0          # 总线相关数据与命令


class CanCableFlag(IntEnum):
    """AB 总线标志（ID 第 2 位）。"""

    CAN_CABLE_FLAG_A = 0  # A 总线
    CAN_CABLE_FLAG_B = 1  # B 总线


class CanFrameFlag(IntEnum):
    """复合帧标志（ID 第 1~0 位）。"""

    CAN_FRAME_FLAG_SINGLE = 0x0          # 单帧
    CAN_FRAME_FLAG_COMPLEX_FIRST = 0x1   # 起始帧
    CAN_FRAME_FLAG_COMPLEX_MIDDLE = 0x2  # 中间帧
    CAN_FRAME_FLAG_COMPLEX_LAST = 0x3    # 尾帧


class CanNodeAddr(IntEnum):
    """CAN 星节点地址。"""

    CAN_NODE_ADDR_MASTER = 0x00   # 星务计算机
    CAN_NODE_ADDR_LASER_A = 0x0C  # 激光终端A
    CAN_NODE_ADDR_LASER_B = 0x0D  # 激光终端B


class BiuSystemCmd(IntEnum):
    """BIU 系统控制类型。"""

    RESET = 0  # CAN 总线恢复帧
