"""BIU 包/消息：ID 生成与分片（对齐 XL 的 packet 角色）。"""

from __future__ import annotations

from ...sdk.can_sdk_def import CanSendObj
from ..can_protocol_base import make_send_obj
from ..can_protocol_def import CanCableParam, CanSendParam
from ..fixed_segment import FixedLengthSegmenter
from .defs import (
    CanFrameFlag,
    CanFrameType,
    CanNodeAddr,
    CanNodeType,
)
from .segment import BiuSegmenter

__all__ = ["BiuPacketReq"]

_NODE_TYPE_MASTER = int(CanNodeType.CAN_NODE_TYPE_MASTER)


class BiuPacketReq:
    """BIU CAN 业务报文：透传组包 + 分片 + 按帧标志生成 ID。"""

    def __init__(
        self,
        data: bytes = b"",
        *,
        is_broadcast: bool = False,
        is_bus_data: bool = False,
        is_from_slave: bool = False,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        self._data: bytes = bytes(data)
        self._broadcast: bool = bool(is_broadcast)
        self._bus_data: bool = bool(is_bus_data)
        self._from_slave: bool = bool(is_from_slave)
        self._send_param: CanSendParam = send_param or CanSendParam()
        self._cable_param: CanCableParam = cable_param or CanCableParam()

    @staticmethod
    def generate_id(
        node_type: int,
        frame_type: int,
        node_addr: int,
        cable_flag: int,
        frame_flag: int,
    ) -> int:
        """生成 CAN ID。"""
        node_addr &= 0x1F
        can_id = 0
        can_id |= int(node_type) << 10
        can_id |= int(frame_type) << 8
        can_id |= int(node_addr) << 3
        can_id |= int(cable_flag) << 2
        can_id |= int(frame_flag)
        return can_id

    def build(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
        *,
        segmenter: BiuSegmenter | FixedLengthSegmenter | None = None,
    ) -> list[CanSendObj]:
        """透传组包后分片，并为每片生成带帧标志的 CanSendObj。"""
        sp = send_param if send_param is not None else self._send_param
        cp = cable_param if cable_param is not None else self._cable_param
        seg = segmenter or BiuSegmenter()

        if self._broadcast:
            node_addr = int(CanNodeAddr.CAN_NODE_ADDR_MASTER)
            frame_type = int(CanFrameType.CAN_FRAME_TYPE_BROADCAST)
        else:
            node_addr = cp.n_node_addr_to
            frame_type = int(CanFrameType.CAN_FRAME_TYPE_POINT_TO_POINT)

        if self._bus_data:
            frame_type |= int(CanFrameType.CAN_FRAME_TYPE_BUS_DATA_CMD)
        else:
            frame_type |= int(CanFrameType.CAN_FRAME_TYPE_APPLICATION_DATA_CMD)

        node_type = (
            int(CanNodeType.CAN_NODE_TYPE_SLAVE)
            if self._from_slave
            else _NODE_TYPE_MASTER
        )
        cable_flag = cp.n_cable_flag
        chunks = seg.split(self._data or b"")
        send_count = len(chunks)
        ret_list: list[CanSendObj] = []

        for i, chunk in enumerate(chunks):
            if send_count == 1:
                part_flag = int(CanFrameFlag.CAN_FRAME_FLAG_SINGLE)
            elif i == 0:
                part_flag = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_FIRST)
            elif i < send_count - 1:
                part_flag = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_MIDDLE)
            else:
                part_flag = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_LAST)

            frame = make_send_obj(
                sp,
                chunk,
                self.generate_id(node_type, frame_type, node_addr, cable_flag, part_flag),
            )
            ret_list.append(frame)
        return ret_list
