"""BIU 协议解析：帧标志重组 + 透传解包。"""

from __future__ import annotations

from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..identity_packet import IdentityPacketDecoder
from ..can_protocol_base import ProtocolParseResult, ProtocolParserBase
from ..can_protocol_def import CanProtocolType
from .segment import BiuSegmenter

__all__ = ["ProtocolParser"]


class ProtocolParser(ProtocolParserBase):
    PROTOCOL = CanProtocolType.BIU

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        super().__init__(params)
        self._segmenter = BiuSegmenter()
        self._packet_dec = IdentityPacketDecoder()

    def feed(self, frames: list[CanRecvObj]) -> None:
        if not frames:
            return
        self._segmenter.feed_many(frames)
        for msg in self._segmenter.drain_assembled():
            logical = bytes(msg.data or b"")
            payload = self._packet_dec.unwrap(logical)
            self._ready.append(
                ProtocolParseResult(
                    src=list(msg.src),
                    data=logical,
                    payload=payload,
                    packet_param={
                        "un_id": msg.un_id,
                        "n_frame_flag": msg.n_frame_flag,
                    },
                )
            )

    def reset(self) -> None:
        self._segmenter.reset()
        super().reset()
