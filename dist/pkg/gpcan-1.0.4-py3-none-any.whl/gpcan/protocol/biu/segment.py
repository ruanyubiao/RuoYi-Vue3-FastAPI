"""BIU 传输分片：直接按 8 字节拆分；重组依赖 CAN ID 帧标志。"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import Segmenter
from .defs import CanFrameFlag

__all__ = ["BiuSegmenter", "BiuAssembled"]

_FRAME_DATA_LEN = 8


@dataclass
class BiuAssembled:
    """分片重组中间结果。"""

    data: bytes
    src: list[CanRecvObj] = field(default_factory=list)
    un_id: int = 0
    n_frame_flag: int = 0


def _frame_flag(obj: CanRecvObj) -> int:
    """BIU 帧标志取自 CAN ID 低 2 位。"""
    return int(obj.un_id) & 0x3


class BiuSegmenter(Segmenter):
    """BIU：TX 纯 8 字节切分；RX 通过 ``feed_frame`` 按帧标志拼接。"""

    def __init__(self, frame_size: int = _FRAME_DATA_LEN) -> None:
        self._frame_size = frame_size
        self._src: list[CanRecvObj] = []
        self._ready: list[BiuAssembled] = []
        self._byte_ready: list[bytes] = []

    def split(self, logical: bytes) -> list[bytes]:
        data = bytes(logical)
        if not data:
            return [b""]
        size = self._frame_size
        return [data[i : i + size] for i in range(0, len(data), size)]

    def feed(self, data: bytes) -> None:
        """仅字节喂入时按单片完整报文处理（无帧标志场景）。"""
        self._byte_ready.append(bytes(data))

    def feed_frame(self, obj: CanRecvObj) -> None:
        completed = self._feed_one(obj)
        if completed is not None:
            self._ready.append(completed)

    def feed_many(self, items: Sequence[Any]) -> None:
        for item in items:
            if isinstance(item, CanRecvObj):
                self.feed_frame(item)
            elif isinstance(item, (bytes, bytearray, memoryview)):
                self.feed(bytes(item))
            else:
                raise TypeError(
                    f"BiuSegmenter.feed_many expects CanRecvObj or bytes, got {type(item)!r}"
                )

    def drain(self) -> list[bytes]:
        out = self._byte_ready
        self._byte_ready = []
        return out

    def drain_assembled(self) -> list[BiuAssembled]:
        out = self._ready
        self._ready = []
        return out

    def assemble(self, recv_list: list[CanRecvObj]) -> list[BiuAssembled]:
        for obj in recv_list:
            self.feed_frame(obj)
        return self.drain_assembled()

    def reset(self) -> None:
        self._src = []
        self._ready.clear()
        self._byte_ready.clear()

    def _make_result(self, src: list[CanRecvObj]) -> BiuAssembled:
        first = src[0]
        data = b"".join(f.str_data or b"" for f in src)
        return BiuAssembled(
            data=data,
            src=list(src),
            un_id=(int(first.un_id) & ~0x3) | int(CanFrameFlag.CAN_FRAME_FLAG_SINGLE),
            n_frame_flag=int(CanFrameFlag.CAN_FRAME_FLAG_SINGLE),
        )

    def _feed_one(self, obj: CanRecvObj) -> BiuAssembled | None:
        flag = _frame_flag(obj)
        first = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_FIRST)
        middle = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_MIDDLE)
        last = int(CanFrameFlag.CAN_FRAME_FLAG_COMPLEX_LAST)
        single = int(CanFrameFlag.CAN_FRAME_FLAG_SINGLE)

        if flag == single:
            self._src = []
            return self._make_result([obj])

        if flag == first:
            self._src = [obj]
            return None

        if flag == middle:
            if self._src and _frame_flag(self._src[-1]) in (first, middle):
                self._src.append(obj)
                return None
            self._src = []
            return None

        if flag == last:
            if self._src and _frame_flag(self._src[-1]) in (first, middle):
                self._src.append(obj)
                merged = self._make_result(self._src)
                self._src = []
                return merged
            self._src = []
            return None

        self._src = []
        return None
