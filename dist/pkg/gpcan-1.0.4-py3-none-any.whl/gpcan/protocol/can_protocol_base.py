"""协议层公共基类：Builder / Parser / Segmenter / Packet。

合并原 ``protocol_builder`` / ``protocol_parser`` / ``segment_base`` / ``packet_base``。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, ClassVar

from ..sdk.can_sdk_def import CanRecvObj, CanSendObj
from .can_protocol_def import CanCableParam, CanProtocolType, CanSendParam

__all__ = [
    "ProtocolBuildResult",
    "ProtocolBuilderBase",
    "ProtocolParseResult",
    "ProtocolParserBase",
    "Segmenter",
    "PacketEncoder",
    "PacketDecoder",
]


def make_send_obj(sp: CanSendParam, data: bytes, can_id: int) -> CanSendObj:
    """用发送默认帧属性 + 数据 + CAN ID 构造一个 :class:`CanSendObj`。"""
    return CanSendObj(
        un_send_type=sp.un_send_type,
        un_remote_flag=sp.un_remote_flag,
        un_extern_flag=sp.un_extern_flag,
        un_data_len=len(data),
        str_data=data,
        un_id=int(can_id),
    )


# ---------------------------------------------------------------------------
# Packet：载荷 ↔ 完整逻辑包
# ---------------------------------------------------------------------------


class PacketEncoder(ABC):
    """把有效载荷封装为协议包字节。"""

    @abstractmethod
    def wrap(self, payload: bytes) -> bytes:
        """加包头/副导头/校验等，返回完整包。"""


class PacketDecoder(ABC):
    """把协议包字节还原为有效载荷。"""

    @abstractmethod
    def unwrap(self, packet: bytes) -> bytes:
        """校验并剥离封装，返回有效载荷。"""

    def reset(self) -> None:
        """清空内部状态（默认无状态）。"""


# ---------------------------------------------------------------------------
# Segmenter：逻辑字节 ↔ 介质分片
# ---------------------------------------------------------------------------


class Segmenter(ABC):
    """逻辑字节 ↔ 分片单元。"""

    @abstractmethod
    def split(self, logical: bytes) -> list[bytes]:
        """一条逻辑报文 → 多个介质单元。"""

    @abstractmethod
    def feed(self, data: bytes) -> None:
        """喂入一个介质单元（或原始字节），尝试拼出逻辑报文。"""

    @abstractmethod
    def drain(self) -> list[bytes]:
        """取出本轮已拼完的全部逻辑报文。"""

    @abstractmethod
    def reset(self) -> None:
        """清空半包状态。"""

    def feed_many(self, items: Sequence[Any]) -> None:
        """批量喂入：默认逐项调用 ``feed``（字节）。

        子类可覆盖以接受 ``CanRecvObj`` 列表等。
        """
        for item in items:
            if isinstance(item, (bytes, bytearray, memoryview)):
                self.feed(bytes(item))
            else:
                data = getattr(item, "str_data", None)
                if data is None:
                    raise TypeError(
                        f"feed_many item must be bytes or have str_data, got {type(item)!r}"
                    )
                self.feed(bytes(data or b""))


# ---------------------------------------------------------------------------
# Builder：离线生成
# ---------------------------------------------------------------------------


@dataclass
class ProtocolBuildResult:
    """离线协议生成结果。

    - ``data``：协议层完整内容（包/非包逻辑载荷）
    - ``frames``：已分片、可直接 ``send_obj_list``；CAN ID 仅在各 frame.un_id
    """

    data: bytes
    frames: list[CanSendObj] = field(default_factory=list)
    packet_param: Any = None


class ProtocolBuilderBase(ABC):
    """各项目协议 Builder 的公共接口。

    构造统一：``send_param`` + ``cable_param``。
    子类用类属性 ``PROTOCOL`` 标识协议（BIU/XL 写死，不经构造函数传入）。
    """

    PROTOCOL: ClassVar[CanProtocolType] = CanProtocolType.NONE

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        self._send_param = send_param or CanSendParam()
        self._cable_param = cable_param or CanCableParam()

    def get_protocol(self) -> CanProtocolType:
        return self.PROTOCOL

    @property
    def send_param(self) -> CanSendParam:
        return self._send_param

    def set_send_param(self, send_param: CanSendParam) -> None:
        self._send_param = send_param

    @property
    def cable_param(self) -> CanCableParam:
        return self._cable_param

    def set_cable_param(self, cable_param: CanCableParam) -> None:
        self._cable_param = cable_param

    @abstractmethod
    def build_time_sync(
        self, sec: int, ms: int = 0, **kwargs: Any
    ) -> ProtocolBuildResult | None:
        """时间同步 / 时间广播。``sec`` 为 UTC Unix 秒；偏差见 :class:`TimeSyncManager`。"""

    @abstractmethod
    def build_broadcast(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult | None:
        """通用广播（载荷 bytes，其余内部写死）。"""

    @abstractmethod
    def build_telecommand(
        self, data: bytes, **kwargs: Any
    ) -> ProtocolBuildResult | None:
        """遥控指令。"""

    @abstractmethod
    def build_telemetry_request(
        self, *args: Any, **kwargs: Any
    ) -> ProtocolBuildResult | None:
        """遥测请求。"""

    @abstractmethod
    def build_telemetry_response(
        self, data: bytes, **kwargs: Any
    ) -> ProtocolBuildResult | None:
        """遥测数据（发送方：激光；目的地：星务）。"""

    @abstractmethod
    def build_refactor(self, *args: Any, **kwargs: Any) -> ProtocolBuildResult | None:
        """重构（占位）。"""

    @abstractmethod
    def build_system(
        self,
        cmd_type: Any,
        *,
        broadcast: bool = False,
        **kwargs: Any,
    ) -> ProtocolBuildResult | None:
        """系统控制（复位等）。"""


# ---------------------------------------------------------------------------
# Parser：接收解析
# ---------------------------------------------------------------------------


@dataclass
class ProtocolParseResult:
    """协议解析结果（不继承 CanRecvObj：那是单帧硬件对象）。

    - ``src``：参与本条逻辑报文的原始 CAN 帧列表
    - ``data``：segment 重组后的逻辑字节（unpack 前）
    - ``payload``：unpack 后的有效数据
    - ``packet_param``：解包后的包参数 / 协议元数据（不含有效数据）
    """

    src: list[CanRecvObj] = field(default_factory=list)
    data: bytes = b""
    payload: bytes = b""
    packet_param: dict[str, Any] = field(default_factory=dict)

    @property
    def un_id(self) -> int:
        return int(self.src[0].un_id) if self.src else 0


class ProtocolParserBase(ABC):
    """各项目协议 Parser：``feed`` 喂入，``get_msg`` 取出一条完整解析结果。"""

    PROTOCOL: ClassVar[CanProtocolType] = CanProtocolType.NONE

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        self._params: dict[str, Any] = dict(params or {})
        self._ready: deque[ProtocolParseResult] = deque()

    def get_protocol(self) -> CanProtocolType:
        return self.PROTOCOL

    @property
    def params(self) -> dict[str, Any]:
        return self._params

    def set_params(self, params: dict[str, Any]) -> None:
        self._params = dict(params or {})

    @abstractmethod
    def feed(self, frames: list[CanRecvObj]) -> None:
        """插入一批硬件接收帧，内部重组；完整报文进入队列。"""

    def get_msg(self) -> ProtocolParseResult | None:
        """获取一条已完整解析的报文；队列为空则返回 ``None``。"""
        if not self._ready:
            return None
        return self._ready.popleft()

    def reset(self) -> None:
        """清空半包与结果队列。"""
        self._ready.clear()
