"""业务层 CAN 协议客户端：持有 Builder（发）与 Parser（收）。

典型用法::

    built = client.builder.build_telecommand(payload)
    client.send_msg(built)
    msg = client.recv_msg()
"""

from __future__ import annotations

from ..sdk.can_sdk_client import CanSdkClient
from ..sdk.can_sdk_def import CanCardParam
from .can_protocol_base import (
    ProtocolBuilderBase,
    ProtocolBuildResult,
    ProtocolParseResult,
    ProtocolParserBase,
)
from .time_sync import TimeSync, TimeSyncManager
from .can_protocol_def import (
    CanCableParam,
    CanProtocolParam,
    CanProtocolType,
    CanSendParam,
    normalize_protocol,
)

__all__ = ["CanProtocolClient"]


class CanProtocolClient(CanSdkClient):
    """业务层 CAN 协议客户端。

    参数顺序：``card_param`` → ``cable_param`` / ``protocol_param``（常改）
    → ``send_param``（少改）。
    """

    def __init__(
        self,
        vendor: int,
        card_param: CanCardParam,
        cable_param: CanCableParam | None = None,
        protocol_param: CanProtocolParam | None = None,
        send_param: CanSendParam | None = None,
    ):
        super().__init__(vendor, card_param)
        self._cable_param = cable_param or CanCableParam()
        self._protocol_param = protocol_param or CanProtocolParam()
        self._send_param = send_param or CanSendParam()
        self._builder: ProtocolBuilderBase | None = None
        self._parser: ProtocolParserBase | None = None
        self._create_protocol_stack()

    def get_send_param(self) -> CanSendParam:
        return self._send_param

    def set_send_param(self, send_param: CanSendParam) -> None:
        self._send_param = send_param
        if self._builder is not None:
            self._builder.set_send_param(send_param)

    def get_cable_param(self) -> CanCableParam:
        return self._cable_param

    def set_cable_param(self, cable_param: CanCableParam) -> None:
        """透传到 Builder，不重建协议栈。"""
        self._cable_param = cable_param or CanCableParam()
        if self._builder is not None:
            self._builder.set_cable_param(self._cable_param)

    def get_protocol_param(self) -> CanProtocolParam:
        return self._protocol_param

    def set_protocol_param(self, protocol_param: CanProtocolParam) -> None:
        self._protocol_param = protocol_param or CanProtocolParam()
        self._create_protocol_stack()

    def get_protocol(self) -> CanProtocolType:
        return normalize_protocol(self._protocol_param.type)

    def get_time_sync(self) -> TimeSync:
        """当前协议对应的 ``TimeSync``（没有则由 Manager 新建）。"""
        return TimeSyncManager.find(self.get_protocol())

    @property
    def builder(self) -> ProtocolBuilderBase:
        assert self._builder is not None
        return self._builder

    @property
    def parser(self) -> ProtocolParserBase:
        assert self._parser is not None
        return self._parser

    def _create_protocol_stack(self) -> None:
        """按 ``CanProtocolParam`` 创建 Builder + Parser。"""
        protocol = normalize_protocol(self._protocol_param.type)
        sp = self._send_param
        cp = self._cable_param
        extra = dict(self._protocol_param.param or {})

        if protocol == CanProtocolType.NONE:
            from .none import ProtocolBuilder, ProtocolParser

            self._builder = ProtocolBuilder(sp, cp)
            self._parser = ProtocolParser(extra)
            return

        if protocol == CanProtocolType.BIU:
            from .biu import ProtocolBuilder, ProtocolParser

            self._builder = ProtocolBuilder(sp, cp)
            self._parser = ProtocolParser(extra)
            return

        if protocol == CanProtocolType.XL:
            from .xl import ProtocolBuilder, ProtocolParser

            self._builder = ProtocolBuilder(sp, cp)
            self._parser = ProtocolParser(extra)
            return

        raise ValueError(f"unknown protocol: {protocol!r}")

    def send_msg(self, built: ProtocolBuildResult | None) -> int:
        if built is None:
            raise ValueError("send_msg requires a ProtocolBuildResult")
        return self.send_obj_list(built.frames)

    def recv_msg(self, n_receive_size: int = 64) -> ProtocolParseResult | None:
        """SDK recv → feed → ``get_msg`` 取一条完整解析结果。"""
        assert self._parser is not None
        frames = self.recv(n_receive_size)
        if frames:
            self._parser.feed(frames)
        return self._parser.get_msg()
