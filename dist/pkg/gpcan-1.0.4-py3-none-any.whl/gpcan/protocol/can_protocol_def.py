"""协议层公共定义（与硬件厂家无关）。"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any


@dataclass
class CanSendParam:
    """发送默认帧属性（组包/分片时写入 CanSendObj，非 SDK 硬件参数）。"""

    un_send_type: int = 0  # CanSendType：0正常 1单次 2自发自收 3单次自发自收
    un_remote_flag: int = 0  # CanRemoteFlag:0:数据帧  1:远程帧
    un_extern_flag: int = 0  # CanExternFlag:0:标准帧  1:扩展帧


@dataclass
class CanCableParam:
    """CAN 电缆参数（参与 CAN ID 生成，收发两端约定一致）。"""

    n_node_addr_to: int = 0  # 目标节点地址 CanNodeAddr
    n_cable_flag: int = 0  # AB 线标志 CanCableFlag，默认 A 线


@dataclass
class CanProtocolParam:
    """业务协议选择及扩展参数。"""

    type: CanProtocolType | int | str | None = 0  # CanProtocolType / 整型 / 字符串
    param: dict[str, Any] = field(default_factory=dict)


class CanProtocolType(IntEnum):
    """业务协议类型（与硬件厂家无关）。"""

    NONE = 0  # 无项目协议，仅硬件 API
    BIU = 1  # BIU 项目
    XL = 2  # XL 项目


def normalize_protocol(protocol: CanProtocolType | int | str | None) -> CanProtocolType:
    """把协议标识规范化为 :class:`CanProtocolType`。

    支持：枚举、整型、字符串（``"none"``/``"biu"``/``"xl"`` 及 ``"0"``/``"1"``/``"2"``）、
    ``None``（→ :attr:`CanProtocolType.NONE`）。未知字符串抛 ``ValueError``。
    """
    if protocol is None:
        return CanProtocolType.NONE
    if isinstance(protocol, str):
        key = protocol.strip().lower()
        if key in ("", "none", "0"):
            return CanProtocolType.NONE
        if key in ("biu", "1"):
            return CanProtocolType.BIU
        if key in ("xl", "2"):
            return CanProtocolType.XL
        raise ValueError(f"unknown protocol: {protocol!r}")
    if isinstance(protocol, int) and not isinstance(protocol, CanProtocolType):
        return CanProtocolType(protocol)
    return protocol
