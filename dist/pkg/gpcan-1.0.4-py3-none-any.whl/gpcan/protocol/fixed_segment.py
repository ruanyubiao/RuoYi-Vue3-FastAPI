"""默认分片：固定长度直接拆分（默认 8 字节，无附加控制字节）。"""

from __future__ import annotations

from .can_protocol_base import Segmenter

__all__ = ["FixedLengthSegmenter"]


class FixedLengthSegmenter(Segmenter):
    """按固定长度切分；重组时由调用方保证帧序完整（本类不做帧标志解析）。

    对无端标志的协议，``feed`` 每次喂入一片即视为一条完整逻辑（适用于 none 收包）。
    若需要跨帧拼接，请使用带控制头的 Segmenter（如 XL）或 BIU 的帧标志 Segmenter。
    """

    def __init__(self, frame_size: int = 8, *, join_on_feed: bool = False) -> None:
        if frame_size < 1:
            raise ValueError("frame_size must be >= 1")
        self._frame_size = frame_size
        self._join_on_feed = join_on_feed
        self._buf = bytearray()
        self._ready: list[bytes] = []

    @property
    def frame_size(self) -> int:
        return self._frame_size

    def split(self, logical: bytes) -> list[bytes]:
        data = bytes(logical)
        if not data:
            return [b""]
        size = self._frame_size
        return [data[i : i + size] for i in range(0, len(data), size)]

    def feed(self, data: bytes) -> None:
        if not self._join_on_feed:
            self._ready.append(bytes(data))
            return
        self._buf.extend(data)

    def drain(self) -> list[bytes]:
        if self._join_on_feed:
            if not self._buf:
                return []
            out = [bytes(self._buf)]
            self._buf.clear()
            return out
        out = self._ready
        self._ready = []
        return out

    def reset(self) -> None:
        self._buf.clear()
        self._ready.clear()
