"""透传组包：不做任何封装（Identity）。

``bytes(x)`` 的行为：
- 入参已是 ``bytes``：CPython 通常**直接返回同一对象**（不可变，无拷贝）
- 入参是 ``bytearray`` / ``memoryview`` 等：会**生成新的** ``bytes`` 对象

因此 Identity 不是“换类型包装器”，而是把输入规范成 ``bytes``；对已是
``bytes`` 的载荷，往返开销接近零。
"""

from __future__ import annotations

from .can_protocol_base import PacketDecoder, PacketEncoder

__all__ = ["IdentityPacketEncoder", "IdentityPacketDecoder"]


class IdentityPacketEncoder(PacketEncoder):
    def wrap(self, payload: bytes) -> bytes:
        return bytes(payload)


class IdentityPacketDecoder(PacketDecoder):
    def unwrap(self, packet: bytes) -> bytes:
        return bytes(packet)
