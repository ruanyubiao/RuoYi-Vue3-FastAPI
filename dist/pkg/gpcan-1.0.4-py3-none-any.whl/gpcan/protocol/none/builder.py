"""NONE 协议离线生成（透传 + 定长分片）。"""

from __future__ import annotations

from typing import Any

from ..can_protocol_def import CanCableParam, CanSendParam
from ..fixed_segment import FixedLengthSegmenter
from ..identity_packet import IdentityPacketEncoder
from ..can_protocol_base import ProtocolBuilderBase, ProtocolBuildResult, make_send_obj

__all__ = ["ProtocolBuilder"]


class ProtocolBuilder(ProtocolBuilderBase):
    """无项目协议：``build_raw`` 生成可发送帧列表。"""

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        super().__init__(send_param, cable_param)
        self._packet_enc = IdentityPacketEncoder()
        self._segmenter = FixedLengthSegmenter(8)

    def build_raw(self, data: bytes, can_id: int) -> ProtocolBuildResult:
        wrapped = self._packet_enc.wrap(bytes(data or b""))
        chunks = self._segmenter.split(wrapped)
        sp = self._send_param
        frames = [make_send_obj(sp, chunk, can_id) for chunk in chunks]
        return ProtocolBuildResult(data=wrapped, frames=frames)

    def build_time_sync(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_broadcast(self, data: bytes, **kwargs: Any) -> None:
        return None

    def build_telecommand(self, data: bytes, **kwargs: Any) -> None:
        return None

    def build_telemetry_request(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_telemetry_response(self, data: bytes, **kwargs: Any) -> None:
        return None

    def build_refactor(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_system(self, cmd_type: Any, *, broadcast: bool = False, **kwargs: Any) -> None:
        return None
