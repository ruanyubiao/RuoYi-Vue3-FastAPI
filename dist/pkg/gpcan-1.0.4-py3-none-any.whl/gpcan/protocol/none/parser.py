"""NONE 协议解析（每帧独立）。"""

from __future__ import annotations

from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..fixed_segment import FixedLengthSegmenter
from ..identity_packet import IdentityPacketDecoder
from ..can_protocol_base import ProtocolParseResult, ProtocolParserBase

__all__ = ["ProtocolParser"]


class ProtocolParser(ProtocolParserBase):
    def __init__(self, params: dict[str, Any] | None = None) -> None:
        super().__init__(params)
        self._segmenter = FixedLengthSegmenter(8)
        self._packet_dec = IdentityPacketDecoder()

    def feed(self, frames: list[CanRecvObj]) -> None:
        for frame in frames or []:
            self._segmenter.feed(frame.str_data or b"")
            for logical in self._segmenter.drain():
                payload = self._packet_dec.unwrap(logical)
                self._ready.append(
                    ProtocolParseResult(
                        src=[frame],
                        data=logical,
                        payload=payload,
                        packet_param={},
                    )
                )

    def reset(self) -> None:
        self._segmenter.reset()
        super().reset()
