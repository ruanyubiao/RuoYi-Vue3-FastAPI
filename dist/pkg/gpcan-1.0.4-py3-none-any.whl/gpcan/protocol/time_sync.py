"""时间同步：按协议隔离的实例，由 ``TimeSyncManager`` 管理。

概念
----
- **系统时间**：主机时间轴（默认墙钟；可用 ``set_system_time`` 外部校正）。
- **载荷时间**：下发给激光/星上的时间 = 系统时间 + ``offset_ms``。
- **offset**：载荷相对系统时间的固定偏差（毫秒）。

多协议
------
BIU / XL 等各自一份 ``TimeSync``，互不影响::

    TimeSyncManager.find("biu").get_system_time_ms()
    TimeSyncManager.find(CanProtocolType.XL).get_offset_parts()

``find`` 的 key 可以是 ``CanProtocolType``、其整数值，或 ``"biu"`` / ``"xl"`` / ``"none"``。
字典中没有则新建。

两处外部时间入口
----------------
1. ``set_system_time(ms)``：外部系统时间更新（可反复调用）。
   保持**当前载荷时间不变**，重绑系统时间轴并反算 offset。
2. ``set_payload_time(ms)`` / 原子钟等「载荷真实时刻」：认为**此刻载荷时间就是 ms**，
   立即 ``offset = ms - 系统时间``。之后载荷时间随系统时间推进。

``set_offset`` 则直接写偏差，不做换算。
"""

from __future__ import annotations

import threading
import time

from .can_protocol_def import CanProtocolType, normalize_protocol

__all__ = ["TimeSync", "TimeSyncManager"]


def _wall_ms() -> int:
    """本机墙钟毫秒。"""
    return time.time_ns() // 1_000_000


class TimeSync:
    """单协议时间同步状态（实例，无类方法）。"""

    def __init__(self) -> None:
        #: 载荷时间 = 系统时间 + offset_ms
        self.offset_ms: int = 0
        #: 外部系统时间锚点；``None`` 表示直接用墙钟。
        self._system_base_ms: int | None = None
        #: 设置 ``_system_base_ms`` 时的墙钟，用于外推。
        self._system_base_at_ms: int = 0

    def reset(self) -> None:
        """清空偏差与外部系统时间锚点。"""
        self.offset_ms = 0
        self._system_base_ms = None
        self._system_base_at_ms = 0

    # ------------------------------------------------------------------ 读取

    def get_system_time_ms(self) -> int:
        """当前系统时间（毫秒）。

        未调用过 ``set_system_time`` 时等于墙钟；
        校正后为 ``锚点 + (墙钟 - 锚点设置时刻)``，随墙钟推进。
        """
        now = _wall_ms()
        if self._system_base_ms is None:
            return now
        return int(self._system_base_ms) + (now - self._system_base_at_ms)

    def get_payload_time_ms(self) -> int:
        """当前载荷时间（毫秒）= 系统时间 + offset。"""
        return self.get_system_time_ms() + int(self.offset_ms)

    def get_offset_parts(self) -> tuple[int, int]:
        """将 ``offset_ms`` 拆成 ``(offset_sec, offset_ms_rem)``，供组时间帧使用。

        负偏差按 floor 语义：``offset_ms_rem`` 始终落在 ``0..999``，如 -1500 → (-2, 500)。
        """
        off = int(self.offset_ms)
        return off // 1000, off % 1000

    # ------------------------------------------------------------------ 设置

    def set_offset(self, offset_ms: int) -> None:
        """直接设置偏差（毫秒）。载荷时间 = 系统时间 + offset。"""
        self.offset_ms = int(offset_ms)

    def set_payload_time(self, payload_time_ms: int) -> None:
        """用载荷真实时刻做标定（如原子钟），**立即**计算 offset。

        ``payload_time_ms`` 表示「此刻」载荷钟面应为该固定值：

            offset = payload_time_ms - get_system_time_ms()

        之后不必再延迟到组帧时换算；系统时间推进时，载荷时间同步推进。
        可反复调用：每次都以新的载荷真实时刻重算 offset。
        """
        self.offset_ms = int(payload_time_ms) - self.get_system_time_ms()

    def set_system_time(self, system_time_ms: int) -> None:
        """外部系统时间更新（可反复调用）。

        保持**当前载荷时间不变**，把系统时间轴重绑到 ``system_time_ms``，并反算::

            offset = get_payload_time_ms() - system_time_ms

        适用于上位机/外部时钟源校正系统时间后，载荷钟面不跳变的场景。
        """
        payload = self.get_payload_time_ms()
        now = _wall_ms()
        self._system_base_ms = int(system_time_ms)
        self._system_base_at_ms = now
        self.offset_ms = payload - int(system_time_ms)


class TimeSyncManager:
    """按协议 key 持有 ``TimeSync`` 实例。"""

    _instances: dict[CanProtocolType, TimeSync] = {}
    _lock = threading.Lock()

    @classmethod
    def find(cls, key: CanProtocolType | int | str) -> TimeSync:
        """查找（没有则新建）指定协议的时间同步对象。"""
        proto = normalize_protocol(key)
        with cls._lock:
            inst = cls._instances.get(proto)
            if inst is None:
                inst = TimeSync()
                cls._instances[proto] = inst
            return inst

    @classmethod
    def reset(cls, key: CanProtocolType | int | str | None = None) -> None:
        """重置一份或全部时间同步状态。

        ``key is None`` 时清空字典（测试隔离）。
        """
        with cls._lock:
            if key is None:
                for inst in cls._instances.values():
                    inst.reset()
                cls._instances.clear()
                return
            inst = cls._instances.get(normalize_protocol(key))
            if inst is not None:
                inst.reset()
