"""XL 协议离线生成。"""

from __future__ import annotations

from typing import Any

from ...sdk.can_sdk_def import CanSendObj
from ..can_protocol_def import CanCableParam, CanProtocolType, CanSendParam
from ..can_protocol_base import ProtocolBuilderBase, ProtocolBuildResult, make_send_obj
from ..time_sync import TimeSyncManager
from .checksum import sum8
from .defs import (
    SystemSecHead,
    XlAddr,
    XlBroadcastKind,
    XlNId,
    XlPacketApidTid,
    XlPacketSeqFlag,
    XlPacketType,
    XlPri,
    XlTcSecHeader,
    XlTmSecHeader,
    XlTypeDir,
    XlTypeFormat,
    XlTypeKind,
    compose_xl_type,
)
from .id_codec import build_apid, generate_can_id
from .packet import XlPacketEncoder, XlPacketParam
from .segment import XlSegmenter

__all__ = ["ProtocolBuilder", "EPOCH_UTC_2015", "sum8"]

EPOCH_UTC_2015 = 1420070400

_TM_SEQ_FLAG = int(XlPacketSeqFlag.STANDALONE)
_LASER_ADDR = int(XlAddr.LASER_COMM)
_LASER_NID = int(XlNId.LASER_COMM)

_BROADCAST_MAP: dict[int, tuple[int, int]] = {
    int(XlBroadcastKind.ATTITUDE): (
        int(XlAddr.ATTITUDE_BROADCAST),
        int(XlNId.ATTITUDE),
    ),
    int(XlBroadcastKind.GNSS): (
        int(XlAddr.GNSS_BROADCAST),
        int(XlNId.GNSS),
    ),
}


class ProtocolBuilder(ProtocolBuilderBase):
    """XL 协议内容生成。各 ``build_*`` 内写死 ADDR / nid。"""

    PROTOCOL = CanProtocolType.XL

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        super().__init__(send_param, cable_param)
        self._segmenter = XlSegmenter()

    def _make_frames(self, can_id: int, chunks: list[bytes]) -> list[CanSendObj]:
        sp = self._send_param
        return [make_send_obj(sp, chunk, can_id) for chunk in chunks]

    def _packet_result(
        self,
        can_id: int,
        packet: bytes,
        packet_param: XlPacketParam | None = None,
    ) -> ProtocolBuildResult:
        # 空用户数据：主导头6 + 副导头1 + SUM1 = 8，单帧直发，不走传输分片格式
        if len(packet) <= 8:
            chunks = [bytes(packet)]
        else:
            chunks = self._segmenter.split(packet)
        return ProtocolBuildResult(
            data=packet,
            frames=self._make_frames(can_id, chunks),
            packet_param=packet_param,
        )

    @staticmethod
    def _packet_type_kind(packet: bytes) -> int:
        return (
            int(XlTypeKind.SINGLE_FRAME)
            if len(packet) <= 8
            else int(XlTypeKind.MULTI_FRAME)
        )

    def build_time_sync(
        self,
        sec: int,
        ms: int = 0,
        *,
        apply_offset: bool = True,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """星务时间广播（非包）。``apply_offset=False`` 时不叠加本协议 TimeSync 偏差。

        数据域 8 字节：``0x80 | onboard_sec BE | ms_word BE | sum8``。
        """
        offset_sec = offset_ms = 0
        if apply_offset:
            offset_sec, offset_ms = TimeSyncManager.find(self.PROTOCOL).get_offset_parts()
        onboard = int(sec) - EPOCH_UTC_2015 + int(offset_sec)
        if onboard < 0 or onboard > 0xFFFFFFFF:
            raise ValueError(f"onboard seconds out of range: {onboard}")
        ms_val = int(ms) + int(offset_ms)
        if ms_val < 0 or ms_val > 0x3FFF:
            raise ValueError(f"milliseconds out of range 0..0x3FFF: {ms_val}")

        gnss_valid = bool(kwargs.get("gnss_valid", True))
        invalid_bit = 0 if gnss_valid else 1
        ms_word = ((invalid_bit & 1) << 15) | (ms_val & 0x3FFF)
        # 8 字节：0x80 | onboard_sec BE | ms_word BE | sum8
        body = (
            bytes([0x80])
            + onboard.to_bytes(4, "big")
            + ms_word.to_bytes(2, "big")
        )
        data = body + bytes([sum8(body)])
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            int(XlAddr.TIME_SYNC_BROADCAST),
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.NON_PACKET),
                int(XlTypeKind.SINGLE_FRAME),
            ),
        )
        return ProtocolBuildResult(
            data=data,
            frames=self._make_frames(can_id, [data]),
        )

    def build_broadcast(
        self,
        data: bytes,
        kind: int = int(XlBroadcastKind.ATTITUDE),
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        key = int(kind)
        if key not in _BROADCAST_MAP:
            raise ValueError(f"unknown broadcast kind: {kind!r}")
        addr, nid = _BROADCAST_MAP[key]
        apid = build_apid(int(XlPacketApidTid.REALTIME), nid)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=int(XlTmSecHeader.POLL_CLASS_7_BROADCAST),
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        # 广播由姿控/GNSS 等设备发出（星务仅模拟），TYPE 方向为 NODE
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            addr,
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_telecommand(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        apid = build_apid(int(XlPacketApidTid.REALTIME), _LASER_NID)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELECOMMAND),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=int(XlTcSecHeader.NODE_DATA),
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            _LASER_ADDR,
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_telemetry_request(
        self,
        sec_header: int = int(XlTmSecHeader.POLL_CLASS_1),
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        sh = int(sec_header) & 0xFF
        if sh not in (
            int(XlTmSecHeader.POLL_CLASS_1),
            int(XlTmSecHeader.POLL_CLASS_2),
        ):
            raise ValueError(
                f"sec_header must be 0x01(速变) or 0x02(缓变), got 0x{sh:02X}"
            )
        apid = build_apid(int(XlPacketApidTid.REALTIME), _LASER_NID)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=_TM_SEQ_FLAG,
            seq_count=0,
            sec_header=sh,
        )
        packet = XlPacketEncoder(packet_param).wrap(b"")
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            _LASER_ADDR,
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_telemetry_response(
        self,
        data: bytes,
        sec_header: int = int(XlTmSecHeader.POLL_CLASS_1),
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """遥测数据：激光（下位机）→ 星务；TYPE 方向为 NODE。"""
        del kwargs
        sh = int(sec_header) & 0xFF
        apid = build_apid(int(XlPacketApidTid.REALTIME), _LASER_NID)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=_TM_SEQ_FLAG,
            seq_count=0,
            sec_header=sh,
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            _LASER_ADDR,
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_refactor(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_system(
        self,
        cmd_type: Any,
        *,
        broadcast: bool = False,
        **kwargs: Any,
    ) -> ProtocolBuildResult | None:
        try:
            sec = int(cmd_type) & 0xFF
        except (TypeError, ValueError):
            return None
        if sec not in {int(x) for x in SystemSecHead}:
            return None

        nid = 0xFF if broadcast else _LASER_NID
        apid = build_apid(int(XlPacketApidTid.REALTIME), nid)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELECOMMAND),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=sec,
        )
        packet = XlPacketEncoder(packet_param).wrap(b"")
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            _LASER_ADDR,
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)
