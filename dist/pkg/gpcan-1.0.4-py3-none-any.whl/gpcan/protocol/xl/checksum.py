"""XL 校验和：8-bit 累加和（SUM）。"""

from __future__ import annotations

__all__ = ["sum8"]


def sum8(data: bytes) -> int:
    """整包累加和，取低 8 位（``sum(data) & 0xFF``）。"""
    return sum(data) & 0xFF
