"""XL 项目协议定义（CAN ID / 包头 / APID / 副导头枚举）。

依据《包协议》文档：
- 数据帧标识符：ID10~ID9=PRI，ID8~ID3=ADDR，ID2~ID0=TYPE
- 包主导头与 APID（应用过程识别符）
"""

from __future__ import annotations

from enum import IntEnum

# ---------------------------------------------------------------------------
# 5.2 数据帧标识符（11-bit CAN ID）
# ---------------------------------------------------------------------------


class XlPri(IntEnum):
    """数据优先级 PRI（ID10~ID9，2bit）。"""

    RESERVED_0 = 0b00          # 保留
    SELECT_PROCESS = 0b01      # 选择过程：间接指令/数据及应答、星务时间广播
    POLL_BROADCAST = 0b10      # 轮询和广播过程（除星务时间广播外）
    RESERVED_3 = 0b11          # 保留


class XlAddr(IntEnum):
    """站地址 ADDR（ID8~ID3，6bit）。节点标识 nID 见备注。
    星务中心计算机模块发送时表示目的地。
    未完整列入的地址请对照表 站地址ADDR说明 补齐。
    """

    MASTER = 0x00                            # 星务中心计算机模块，nID=0x00，主节点
    LASER_COMM = 0x1F                        # 激光通信载荷，1FH（011111b）
    TIME_SYNC_BROADCAST = 0x0F               # 星务对时广播，0FH（001111b）
    GNSS_BROADCAST = 0x0E                    # GNSS定位广播，0EH（001110b）
    ATTITUDE_BROADCAST = 0x2F                # 姿控姿态/电推力广播，2FH（101111b）


class XlTypeDir(IntEnum):
    """帧方向（ID2，1bit）：标识发送方。"""

    MASTER = 0                 # 主节点发送（星务发数据）
    NODE = 1                   # 下位机发送（下位机发数据）


class XlTypeFormat(IntEnum):
    """数据帧格式（ID1，1bit）。"""

    NON_PACKET = 0             # 非包格式
    PACKET = 1                 # 包格式


class XlTypeKind(IntEnum):
    """单帧/多帧标志（ID0，1bit）。"""

    SINGLE_FRAME = 0           # 单帧
    MULTI_FRAME = 1            # 多帧


class XlType(IntEnum):
    """TYPE 全组合（ID2~ID0，3bit）= Dir | Format | Kind。"""

    MASTER_NON_PACKET_SINGLE = 0b000  # 主节点 + 非包 + 单帧
    MASTER_NON_PACKET_MULTI = 0b001   # 主节点 + 非包 + 多帧
    MASTER_PACKET_SINGLE = 0b010      # 主节点 + 包 + 单帧
    MASTER_PACKET_MULTI = 0b011       # 主节点 + 包 + 多帧
    NODE_NON_PACKET_SINGLE = 0b100    # 下位机 + 非包 + 单帧
    NODE_NON_PACKET_MULTI = 0b101     # 下位机 + 非包 + 多帧
    NODE_PACKET_SINGLE = 0b110        # 下位机 + 包 + 单帧
    NODE_PACKET_MULTI = 0b111         # 下位机 + 包 + 多帧


def compose_xl_type(dir_: int, format_: int, kind: int) -> int:
    """组合 TYPE 三字段为 3bit 值。"""
    return ((int(dir_) & 1) << 2) | ((int(format_) & 1) << 1) | (int(kind) & 1)


def parse_xl_type(type_: int) -> tuple[int, int, int]:
    """解析 TYPE，返回 ``(dir, format, kind)``。"""
    type_ = int(type_) & 0x7
    return (type_ >> 2) & 1, (type_ >> 1) & 1, type_ & 1


# ---------------------------------------------------------------------------
# 包主导头 / APID（包层，非 CAN ID）
#
# 数据包整体结构：【包主导头(6字节)】 + 【包数据域(可变长)】
# 包数据域 = 副导头 + 有效数据域 + 校验域 SUM
#
# 1. 包主导头 6 字节
#    WOW1(2B): 版本(3)=010 | 类型(1) | 副导头标识(1)=1 | APID(11)
#    W2W3(2B): 序列标志(2) | 包序列计数(14)
#    W4W5(2B): 包长(16) = 包数据域字节数 - 1
#              （包长为 1 时，包数据域仅有副导头 + SUM；有副导头时即 用户数据长度 + 1）
# 2. 包数据域
#    副导头(1B) + 有效数据 + SUM(1B，整包累加和，不含 SUM 自身)
# ---------------------------------------------------------------------------

XL_PRIMARY_HEADER_LEN = 6      # 包主导头长度（字节）
XL_SEC_HEADER_LEN = 1          # 副导头长度（字节）
XL_SUM_LEN = 1                 # 校验域 SUM 长度（字节）

# 包主导头.包识别.版本号（3bit）
XL_PACKET_VERSION = 0b010      # 包主导头版本号，固定 010

class XlPacketType(IntEnum):
    """包主导头.包识别.类型（1bit）。"""

    TELEMETRY = 0              # 遥测包
    TELECOMMAND = 1            # 遥控包


class XlPacketSecHeader(IntEnum):
    """包主导头.包识别.副导头标识（1bit）。本协议固定有副导头，组包默认 YES。"""

    NO = 0                     # 无副导头
    YES = 1                    # 有副导头（本协议默认）


class XlPacketSeqFlag(IntEnum):
    """包主导头.包顺序控制.序列标志（2bit）。"""

    MIDDLE = 0b00              # 中间包
    FIRST = 0b01               # 首包
    LAST = 0b10                # 末包
    STANDALONE = 0b11          # 独立包


class XlPacketApidTid(IntEnum):
    """
    包主导头.包识别.APID.类型标识 TID（b10）。
    下位机用该比特判断是否应答本包数据，
    当下位机收到实时遥控包后，需按规定格式做出应答；
    当下位机收到延时遥控包后，则无需做出应答。
    """

    REALTIME = 0               # 实时遥测包
    DELAYED = 1                # 延时遥测包


class XlNId(IntEnum):
    """
    包主导头.包识别.APID.设备节点标识 nID（APID 低 8 位，广播 0xFF）。
    遥控包：目的标识
    遥测包：源标识
    """

    MASTER = 0x00                # 星务中心计算机，对应 ADDR.MASTER
    LASER_COMM = 0x14            # 激光通信载荷模块的nID
    GNSS = 0x0A                  # GNSS模块的nID
    ATTITUDE = 0x04              # 姿控中心单元的nID


class XlTmSecHeader(IntEnum):
    """遥测/广播类副导头低 4 位（高四位保留为 0）。"""

    RESERVED_0 = 0b0000
    POLL_CLASS_1 = 0b0001              # 一类数据轮询-速变遥测
    POLL_CLASS_2 = 0b0010              # 二类数据轮询-缓变遥测
    POLL_CLASS_3 = 0b0011
    POLL_CLASS_4 = 0b0100
    POLL_CLASS_5 = 0b0101
    POLL_CLASS_6 = 0b0110              # 保留
    POLL_CLASS_7_BROADCAST = 0b0111    # 广播类，姿控，GNSS
    POLL_CLASS_8_BROADCAST = 0b1000    # 广播类
    POLL_CLASS_9_BROADCAST = 0b1001    # 广播类
    POLL_CLASS_10 = 0b1010             # 保留
    POLL_CLASS_11 = 0b1011             # 保留
    POLL_CLASS_12 = 0b1100             # 保留
    POLL_CLASS_13 = 0b1101             # 保留
    POLL_CLASS_14_ATTITUDE = 0b1110    # 姿控重要数据
    POLL_CLASS_15_SAVE = 0b1111        # 星务重要保存数据轮询


class XlTcSecHeader(IntEnum):
    """遥控/程控类副导头低 4 位。"""

    RESERVED_0 = 0b0000
    NODE_DATA = 0b0001                 # 下位机数据
    INDIRECT_CMD = 0b0010              # 包格式间接指令（本型号可保留）
    RESERVED_3 = 0b0011
    RESERVED_4 = 0b0100
    RESERVED_5 = 0b0101
    RESERVED_6 = 0b0110
    RESERVED_7 = 0b0111
    SOFTWARE_UPLOAD = 0b1000           # 软件上注重构数据
    RESERVED_9 = 0b1001
    RESERVED_10 = 0b1010
    RESERVED_11 = 0b1011
    RESERVED_12 = 0b1100
    RESERVED_13 = 0b1101
    NODE_SAVE_RETURN = 0b1110          # 下位机重要保存数据返回
    MASTER_SAVE_STORE = 0b1111         # 星务重要保存数据存储


class SystemSecHead(IntEnum):
    """系统控制副导头。"""

    HEARTBEAT = 0xF1       # 心跳测试，目标设备无动作只需应答
    RESET_BUS_A = 0xFA     # 目标设备 A 总线复位
    RESET_BUS_B = 0xFB     # 目标设备 B 总线复位
    SAFE_SHUTDOWN = 0xFF   # 分系统全部安全关机或进入最小能源模式


class XlBroadcastKind(IntEnum):
    """星务模拟他机广播类型（决定 ADDR / nid 写死值）。"""

    ATTITUDE = 1  # 姿控广播
    GNSS = 2      # GNSS 广播

