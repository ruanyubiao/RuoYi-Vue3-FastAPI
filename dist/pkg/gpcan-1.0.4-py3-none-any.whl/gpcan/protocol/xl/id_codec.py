"""XL CAN ID / APID / 包识别字 编解码工具。"""

from __future__ import annotations

from .defs import (
    XL_PACKET_VERSION,
    XlPacketApidTid,
    XlPacketSecHeader,
    XlPacketType,
)

__all__ = [
    "generate_can_id",
    "parse_can_id",
    "build_apid",
    "parse_apid",
    "build_packet_id_word",
    "parse_packet_id_word",
    "build_tm_apid",
    "build_tc_apid",
    "build_tm_packet_id",
    "build_tc_packet_id",
]


def generate_can_id(pri: int, addr: int, type_: int) -> int:
    """生成 11-bit CAN ID：PRI(2) | ADDR(6) | TYPE(3)。"""
    pri &= 0x3
    addr &= 0x3F
    type_ &= 0x7
    return (pri << 9) | (addr << 3) | type_


def parse_can_id(un_id: int) -> tuple[int, int, int]:
    """解析 CAN ID，返回 ``(pri, addr, type_)``。"""
    un_id = int(un_id) & 0x7FF
    pri = (un_id >> 9) & 0x3
    addr = (un_id >> 3) & 0x3F
    type_ = un_id & 0x7
    return pri, addr, type_


def build_apid(tid: int, nid: int) -> int:
    """组装 11-bit APID：b10=TID，b9~b8=0，b7~b0=nid。"""
    tid &= 0x1
    nid &= 0xFF
    return (tid << 10) | nid


def parse_apid(apid: int) -> tuple[int, int]:
    """解析 APID，返回 ``(tid, nid)``。"""
    apid = int(apid) & 0x7FF
    tid = (apid >> 10) & 0x1
    nid = apid & 0xFF
    return tid, nid


def build_packet_id_word(
    packet_type: int,
    apid: int,
    *,
    version: int = XL_PACKET_VERSION,
    sec_header_flag: int = int(XlPacketSecHeader.YES),
) -> int:
    """组装包主导头识别字（16bit）：版本(3)|类型(1)|副导头标识(1)|APID(11)。"""
    version &= 0x7
    packet_type &= 0x1
    sec_header_flag &= 0x1
    apid &= 0x7FF
    return (version << 13) | (packet_type << 12) | (sec_header_flag << 11) | apid


def parse_packet_id_word(word: int) -> tuple[int, int, int, int]:
    """解析包识别字，返回 ``(version, packet_type, sec_header_flag, apid)``。"""
    word = int(word) & 0xFFFF
    version = (word >> 13) & 0x7
    packet_type = (word >> 12) & 0x1
    sec_header_flag = (word >> 11) & 0x1
    apid = word & 0x7FF
    return version, packet_type, sec_header_flag, apid


def build_tm_apid(nid: int, tid: int = int(XlPacketApidTid.REALTIME)) -> int:
    """遥测包 APID 便捷构造。"""
    return build_apid(tid, nid)


def build_tc_apid(nid: int, tid: int = int(XlPacketApidTid.REALTIME)) -> int:
    """遥控包 APID 便捷构造（本型号 TID 常固定为实时）。"""
    return build_apid(tid, nid)


def build_tm_packet_id(nid: int, tid: int = int(XlPacketApidTid.REALTIME)) -> int:
    return build_packet_id_word(int(XlPacketType.TELEMETRY), build_tm_apid(nid, tid))


def build_tc_packet_id(nid: int, tid: int = int(XlPacketApidTid.REALTIME)) -> int:
    return build_packet_id_word(int(XlPacketType.TELECOMMAND), build_tc_apid(nid, tid))
