"""XL 包封装：主导头 + 副导头 + 载荷 + SUM。"""

from __future__ import annotations

from dataclasses import dataclass

from ..can_protocol_base import PacketDecoder, PacketEncoder
from .checksum import sum8
from .defs import (
    XL_PACKET_VERSION,
    XL_PRIMARY_HEADER_LEN,
    XL_SEC_HEADER_LEN,
    XL_SUM_LEN,
    XlPacketSecHeader,
    XlPacketType,
    XlPacketSeqFlag,
)
from .id_codec import build_packet_id_word, parse_packet_id_word

__all__ = ["XlPacketEncoder", "XlPacketDecoder", "XlPacketParam"]


@dataclass
class XlPacketParam:
    """组包参数（非载荷部分）。"""

    packet_type: int = int(XlPacketType.TELECOMMAND)
    apid: int = 0
    seq_flag: int = int(XlPacketSeqFlag.STANDALONE)
    seq_count: int = 0
    sec_header: int = 0
    version: int = XL_PACKET_VERSION
    sec_header_flag: int = int(XlPacketSecHeader.YES)


class XlPacketEncoder(PacketEncoder):
    """按 defs 注释封装 XL 包。"""

    def __init__(self, param: XlPacketParam | None = None) -> None:
        self._param = param or XlPacketParam()

    @property
    def param(self) -> XlPacketParam:
        return self._param

    def set_param(self, param: XlPacketParam) -> None:
        self._param = param

    def wrap(self, payload: bytes) -> bytes:
        p = self._param
        payload = bytes(payload)
        # 包长 = 包数据域字节数 - 1 = 副导头 + 有效数据 + SUM - 1
        # 有副导头时等价于 用户数据长度 + 1
        data_field_len = XL_SEC_HEADER_LEN + len(payload) + XL_SUM_LEN
        pkt_len = data_field_len - 1
        if pkt_len < 0 or pkt_len > 0xFFFF:
            raise ValueError(f"packet length out of range: {pkt_len}")

        id_word = build_packet_id_word(
            p.packet_type,
            p.apid,
            version=p.version,
            sec_header_flag=p.sec_header_flag,
        )
        seq_word = ((int(p.seq_flag) & 0x3) << 14) | (int(p.seq_count) & 0x3FFF)

        primary = (
            id_word.to_bytes(2, "big")
            + seq_word.to_bytes(2, "big")
            + pkt_len.to_bytes(2, "big")
        )
        body = bytes([int(p.sec_header) & 0xFF]) + payload
        without_sum = primary + body
        return without_sum + bytes([sum8(without_sum)])


class XlPacketDecoder(PacketDecoder):
    """解析 XL 包，校验 SUM / 长度后返回有效载荷。"""

    def __init__(self) -> None:
        self.last_param: XlPacketParam | None = None

    def unwrap(self, packet: bytes) -> bytes:
        data = bytes(packet)
        min_len = XL_PRIMARY_HEADER_LEN + XL_SEC_HEADER_LEN + XL_SUM_LEN
        if len(data) < min_len:
            raise ValueError(f"packet too short: {len(data)}")

        pkt_len = int.from_bytes(data[4:6], "big")
        data_field_len = len(data) - XL_PRIMARY_HEADER_LEN
        if data_field_len < XL_SEC_HEADER_LEN + XL_SUM_LEN:
            raise ValueError(f"packet too short: {len(data)}")
        if pkt_len != data_field_len - 1:
            raise ValueError(
                f"length mismatch: header={pkt_len} data_field={data_field_len}"
            )

        body = data[:-1]
        checksum = data[-1]
        if sum8(body) != checksum:
            raise ValueError("checksum error")

        version, packet_type, sec_flag, apid = parse_packet_id_word(
            int.from_bytes(data[0:2], "big")
        )
        # 本协议固定有副导头（组包默认 YES），无副导头暂不支持，直接拒绝避免错位解析。
        if sec_flag != int(XlPacketSecHeader.YES):
            raise ValueError(f"unsupported sec_header_flag={sec_flag} (only YES supported)")
        seq_word = int.from_bytes(data[2:4], "big")
        seq_flag = (seq_word >> 14) & 0x3
        seq_count = seq_word & 0x3FFF
        sec_header = data[6]
        payload = data[7:-1]

        self.last_param = XlPacketParam(
            packet_type=packet_type,
            apid=apid,
            seq_flag=seq_flag,
            seq_count=seq_count,
            sec_header=sec_header,
            version=version,
            sec_header_flag=sec_flag,
        )
        return payload
