"""XL 协议解析：按 CAN ID 的 XlTypeFormat 决定是否解包。"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import ProtocolParseResult, ProtocolParserBase
from ..can_protocol_def import CanProtocolType
from .defs import XlTypeFormat, XlTypeKind, parse_xl_type
from .id_codec import parse_can_id
from .packet import XlPacketDecoder
from .segment import XlSegmenter

__all__ = ["ProtocolParser"]


class ProtocolParser(ProtocolParserBase):
    """XL 接收解析。

    - ``XlTypeFormat.PACKET``：分片重组后解包
    - ``XlTypeFormat.NON_PACKET``：不解包，整段为 payload
    """

    PROTOCOL = CanProtocolType.XL

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        super().__init__(params)
        self._segmenter = XlSegmenter()
        self._packet_dec = XlPacketDecoder()
        self._pending: list[CanRecvObj] = []
        self._pending_is_packet: bool | None = None

    def feed(self, frames: list[CanRecvObj]) -> None:
        if not frames:
            return
        for frame in frames:
            _pri, _addr, type_ = parse_can_id(frame.un_id)
            _dir, format_, kind = parse_xl_type(type_)
            is_packet = format_ == int(XlTypeFormat.PACKET)

            # 单帧：数据域即完整逻辑数据，不走传输分片格式
            if kind == int(XlTypeKind.SINGLE_FRAME):
                data = bytes(frame.str_data or b"")
                if is_packet:
                    try:
                        payload = self._packet_dec.unwrap(data)
                    except ValueError:
                        continue
                    packet_param: dict[str, Any] = {"packet": True}
                    if self._packet_dec.last_param is not None:
                        packet_param.update(asdict(self._packet_dec.last_param))
                else:
                    payload = data
                    packet_param = {"packet": False}
                packet_param.update({"pri": _pri, "addr": _addr, "type": type_})
                self._ready.append(
                    ProtocolParseResult(
                        src=[frame],
                        data=data,
                        payload=payload,
                        packet_param=packet_param,
                    )
                )
                continue

            if self._pending_is_packet is None:
                self._pending_is_packet = is_packet
            self._pending.append(frame)
            if self._segmenter.feed(frame.str_data or b""):
                # 坏控制字导致 segmenter 内部 reset：丢弃半包并清掉已缓存的陈旧帧
                self._pending = []
                self._pending_is_packet = None
                continue
            for logical in self._segmenter.drain():
                packet_mode = bool(self._pending_is_packet)
                if packet_mode:
                    try:
                        payload = self._packet_dec.unwrap(logical)
                    except ValueError:
                        self._pending = []
                        self._pending_is_packet = None
                        continue
                    packet_param = {"packet": True}
                    if self._packet_dec.last_param is not None:
                        packet_param.update(asdict(self._packet_dec.last_param))
                else:
                    payload = logical
                    packet_param = {"packet": False}
                self._ready.append(
                    ProtocolParseResult(
                        src=list(self._pending),
                        data=logical,
                        payload=payload,
                        packet_param=packet_param,
                    )
                )
                self._pending = []
                self._pending_is_packet = None

    def reset(self) -> None:
        self._segmenter.reset()
        self._pending = []
        self._pending_is_packet = None
        super().reset()
