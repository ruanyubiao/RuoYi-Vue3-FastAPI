"""XL 传输分片：多帧时每帧 1 字节控制 + 最多 7 字节载荷。

线格式（每 CAN 帧数据域，多帧）::

    [ctrl:1][payload:0~7]

- 首帧 ``ctrl`` = 总片数 N
- 续帧 ``ctrl`` = 序号 1 .. N-1

空用户数据时整包恰好 8 字节：按单帧直接发送整包，不加传输控制字
（见 :meth:`ProtocolBuilder._packet_result` / parser 的 SINGLE 分支）。
"""

from __future__ import annotations

from ..can_protocol_base import Segmenter

__all__ = ["XlSegmenter"]

_MAX_PAYLOAD = 7


class XlSegmenter(Segmenter):
    def __init__(self, max_payload: int = _MAX_PAYLOAD) -> None:
        if max_payload < 1 or max_payload > 7:
            raise ValueError("max_payload must be in 1..7")
        self._max_payload = max_payload
        self._expected: int | None = None
        self._parts: dict[int, bytes] = {}
        self._ready: list[bytes] = []

    def split(self, logical: bytes) -> list[bytes]:
        data = bytes(logical)
        if not data:
            return [bytes([1])]

        n = (len(data) + self._max_payload - 1) // self._max_payload
        if n > 255:
            raise ValueError(f"too many fragments: {n}")
        out: list[bytes] = []
        offset = 0
        for i in range(n):
            chunk = data[offset : offset + self._max_payload]
            offset += len(chunk)
            ctrl = n if i == 0 else i
            out.append(bytes([ctrl]) + chunk)
        return out

    def feed(self, data: bytes) -> bool:
        """喂入一个介质单元；内部因坏控制字而 ``reset`` 时返回 ``True``。"""
        if not data:
            return False
        ctrl = data[0]
        payload = data[1:]
        if self._expected is None:
            if ctrl < 1:
                self.reset()
                return True
            self._expected = ctrl
            self._parts = {0: payload}
        else:
            if ctrl < 1 or ctrl >= self._expected:
                self.reset()
                return True
            if ctrl in self._parts:
                self.reset()
                return True
            self._parts[ctrl] = payload

        assert self._expected is not None
        if len(self._parts) < self._expected:
            return False
        ordered = [self._parts[i] for i in range(self._expected)]
        self._ready.append(b"".join(ordered))
        self._expected = None
        self._parts.clear()
        return False

    def drain(self) -> list[bytes]:
        out = self._ready
        self._ready = []
        return out

    def reset(self) -> None:
        self._expected = None
        self._parts.clear()
        self._ready.clear()
