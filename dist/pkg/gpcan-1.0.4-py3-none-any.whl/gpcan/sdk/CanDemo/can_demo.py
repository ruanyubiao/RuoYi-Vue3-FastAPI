from __future__ import annotations

import struct
import threading

from ..can_sdk_def import CanRetCode, CanCardParam, CanRecvObj, CanSendObj
from ..i_can_base import DeviceRefTable, ICanBase
from .virtual_hardware import (
    SendWouldBlockError,
    VirtualHardware,
    VirtualHardwareError,
)


# DEMO_CAN_OBJ 线格式：ID(4) + SendType(1) + RemoteFlag(1) + ExternFlag(1) + DataLen(1) + 保留(1) + Data(DataLen)
_FRAME_FMT = "!IBBBBB"
_FRAME_HDR_LEN = struct.calcsize(_FRAME_FMT)
_MAX_DATA_LEN = 8


class DEMO_CAN_OBJ:
    """演示 CAN 帧对象，用于虚拟硬件字节流传输。

    字段与线格式 ``_FRAME_FMT`` 对应（ID / SendType / RemoteFlag / ExternFlag /
    DataLen / Data），不含时间戳等未上线的字段。

    用法示例::

        frame = DEMO_CAN_OBJ()
        frame.ID = un_id
        frame.SendType = un_send_type
        frame.RemoteFlag = un_remote_flag
        frame.ExternFlag = un_extern_flag
        frame.DataLen = un_data_len
        for i, b in enumerate(buffer):
            frame.Data[i] = b
    """

    def __init__(self):
        self.ID: int = 0
        self.SendType: int = 0
        self.RemoteFlag: int = 0
        self.ExternFlag: int = 0
        self.DataLen: int = 0
        self.Data: bytearray = bytearray(8)

    def to_bytes(self) -> bytes:
        """序列化为可写入 ``VirtualHardware`` 的字节流。"""
        data_len = max(0, min(int(self.DataLen), _MAX_DATA_LEN))
        header = struct.pack(
            _FRAME_FMT,
            int(self.ID),
            int(self.SendType),
            int(self.RemoteFlag),
            int(self.ExternFlag),
            data_len,
            0,
        )
        return header + bytes(self.Data[:data_len])

    @classmethod
    def from_bytes(cls, data: bytes) -> DEMO_CAN_OBJ:
        """从 ``VirtualHardware`` 读取的字节流还原为帧对象。"""
        if len(data) < _FRAME_HDR_LEN:
            raise ValueError(f"DEMO_CAN_OBJ 帧头过短: {len(data)} < {_FRAME_HDR_LEN}")
        obj = cls()
        id_, send_type, remote, extern, data_len, _ = struct.unpack(
            _FRAME_FMT, data[:_FRAME_HDR_LEN]
        )
        obj.ID = id_
        obj.SendType = send_type
        obj.RemoteFlag = remote
        obj.ExternFlag = extern
        # 帧头里的 data_len 是单字节（0~255），截断到最大数据长度，避免异常帧导致越界。
        data_len = min(data_len, _MAX_DATA_LEN)
        obj.DataLen = data_len
        payload = data[_FRAME_HDR_LEN : _FRAME_HDR_LEN + data_len]
        obj.Data[: len(payload)] = payload
        return obj


def _send_obj_to_demo(frame: CanSendObj) -> DEMO_CAN_OBJ:
    """把业务层 :class:`CanSendObj` 转换为演示帧对象。"""
    obj = DEMO_CAN_OBJ()
    obj.ID = int(frame.un_id)
    obj.SendType = int(frame.un_send_type)
    obj.RemoteFlag = int(frame.un_remote_flag)
    obj.ExternFlag = int(frame.un_extern_flag)
    payload = bytes(frame.str_data)[:_MAX_DATA_LEN]
    obj.DataLen = min(int(frame.un_data_len), len(payload))
    obj.Data[: obj.DataLen] = payload[: obj.DataLen]
    return obj


def _demo_to_recv_obj(frame: DEMO_CAN_OBJ) -> CanRecvObj:
    """把演示帧对象转换为业务层 :class:`CanRecvObj`。"""
    data_len = max(0, min(int(frame.DataLen), _MAX_DATA_LEN))
    return CanRecvObj(
        un_remote_flag=int(frame.RemoteFlag),
        un_extern_flag=int(frame.ExternFlag),
        un_data_len=data_len,
        str_data=bytes(frame.Data[:data_len]),
        un_id=int(frame.ID),
        un_time_stamp=0,
    )


class CanDemo(ICanBase):
    """演示设备：``_devices`` 键为 ``(0, n_dev_index)``。

    通过 :class:`VirtualHardware` 实现跨进程虚拟 CAN 收发：

    · 设备唯一 key（``channel``）``vcan:{n_dev_index}:{n_can_index}`` —— 锁定设备
    · 通讯唯一 key 附加波特率（``link``），即 ``vcan:{n_dev_index}:{n_can_index}:{n_baud_rate}``

    两端使用相同的设备 key + 波特率即可配对通信。
    """

    _devices = DeviceRefTable()

    @classmethod
    def get_channel_count(cls) -> int:
        return 4

    def __init__(self, param: CanCardParam):
        super().__init__(param)
        self._device_key: tuple[int, int] | None = None
        self._vhw: VirtualHardware | None = None
        self._recv_cache: list[CanRecvObj] = []
        self._vhw_lock = threading.Lock()

    def __del__(self):
        try:
            self.deinit_can()
        except Exception:
            pass

    def _key(self) -> tuple[int, int]:
        # 物理卡键：(占位类型 0, 设备序号 n_dev_index)。
        # Demo 无真实 OpenDevice；同一 n_dev_index 上的多通道共用此键。
        return (0, int(self._param.n_dev_index))

    def _vhw_channel(self) -> str:
        # 设备唯一 key（VirtualHardware.channel）：vcan:{n_dev_index}:{n_can_index}，
        # 设备索引 + 通道索引即可锁定设备，与波特率无关。
        # VirtualHardware.channel 仅允许字母/数字/下划线/连字符，因此用 '-' 替换 ':'。
        return f"vcan-{self._param.n_dev_index}-{self._param.n_can_index}"

    def init_can(self) -> int:
        key = self._key()
        if self._devices.acquire(key) is None:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._dev_open = True
        self._device_key = key
        return int(CanRetCode.CAN_RET_CODE_OK)

    def deinit_can(self) -> int:
        self.close_can()
        if not self._dev_open or self._device_key is None:
            self._dev_open = False
            self._device_key = None
            return int(CanRetCode.CAN_RET_CODE_OK)
        key = self._device_key
        self._dev_open = False
        self._device_key = None
        self._devices.release(key)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def open_can(self) -> int:
        if self._can_open:
            return int(CanRetCode.CAN_RET_CODE_OK)
        try:
            # channel 锁定设备；link（波特率）决定实际通讯链路（IPC 地址）
            self._vhw = VirtualHardware(
                channel=self._vhw_channel(),
                link=str(self._param.n_baud_rate),
            )
            self._vhw.connect()
        except VirtualHardwareError:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._devices.add_opened_channel(self._key(), int(self._param.n_can_index))
        self._can_open = True
        return int(CanRetCode.CAN_RET_CODE_OK)

    def close_can(self) -> int:
        if self._can_open:
            self._can_open = False
            self._devices.remove_opened_channel(self._key(), int(self._param.n_can_index))
            with self._vhw_lock:
                if self._vhw is not None:
                    self._vhw.close()
                    self._vhw = None
                self._recv_cache.clear()
        return int(CanRetCode.CAN_RET_CODE_OK)

    def clear_buffer(self) -> int:
        with self._vhw_lock:
            self._recv_cache.clear()
        return int(CanRetCode.CAN_RET_CODE_OK)

    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        frame = CanSendObj(
            un_id=un_id,
            str_data=bytes(data),
            un_data_len=un_data_len,
            un_send_type=un_send_type,
            un_remote_flag=un_remote_flag,
            un_extern_flag=un_extern_flag,
        )
        return self.send_list([frame])

    def send_list(self, send_list: list[CanSendObj]) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if not send_list:
            return int(CanRetCode.CAN_RET_CODE_OK)
        if self._vhw is None:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        demo_list = [_send_obj_to_demo(obj) for obj in send_list]
        try:
            with self._vhw_lock:
                for frame in demo_list:
                    try:
                        self._vhw.sendall(frame.to_bytes(), timeout=0)
                    except SendWouldBlockError:
                        # 总线上暂无对端（接收者）：帧上总线后即被丢弃，仍视为发送成功。
                        pass
            return int(CanRetCode.CAN_RET_CODE_OK)
        except VirtualHardwareError:
            return int(CanRetCode.CAN_RET_CODE_ERR)

    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]:
        if not self._can_open or self._vhw is None:
            return []
        n_receive_size = max(0, int(n_receive_size))

        with self._vhw_lock:
            # 把 vhw 当前可读的消息全部收上来，还原为 CanRecvObj 后追加到本地缓存。
            while True:
                try:
                    payload = self._vhw.recv(timeout=0)
                except VirtualHardwareError:
                    break
                if not payload:
                    break
                try:
                    demo_frame = DEMO_CAN_OBJ.from_bytes(payload)
                    self._recv_cache.append(_demo_to_recv_obj(demo_frame))
                except Exception:
                    # 异常帧跳过，继续处理后续帧
                    continue

            # 按 n_receive_size 从本地缓存取数据；超出部分继续缓存，不足则全部返回并清空缓存。
            # 缓存操作与上面的排空同在一个锁内，避免与 clear_buffer / close_can 竞态。
            if len(self._recv_cache) >= n_receive_size:
                result = self._recv_cache[:n_receive_size]
                self._recv_cache = self._recv_cache[n_receive_size:]
                return result

            result = self._recv_cache[:]
            self._recv_cache.clear()
            return result
