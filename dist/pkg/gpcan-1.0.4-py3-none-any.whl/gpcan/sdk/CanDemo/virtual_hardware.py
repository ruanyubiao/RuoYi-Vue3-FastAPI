"""虚拟硬件：跨进程原始字节通道（``commfw.hw`` 设备封装，非 Transport）。

语义对齐「打开串口」：``connect()`` 只打开**本端**设备，**不因对端未上线而失败**。

· 对端已在监听 → 本端 ``Client`` 连上，立即持有 ``Connection``
· 否则 → 本端创建 ``Listener`` 并在后台一直 ``accept``，``connect()`` 立即成功返回
· 对端稍后出现时完成配对；``recv_into`` 在尚无对端时按读超时返回 ``-1``
· ``send`` 会等到对端连上（可用 ``timeout`` 限制等待）

两端使用相同 ``channel``，无需指定 server/client；双方同时 ``connect`` 时
仅用短暂竞态重试打开本端（Client vs Listener），**不是**「等对端上线」超时。

底层为 ``multiprocessing.connection``：

· Windows：命名管道 ``\\\\.\\pipe\\vhw_<channel>``（``AF_PIPE``）
· Linux / macOS：Unix 域套接字 ``{tmpdir}/vhw_<channel>.sock``（``AF_UNIX``）

断线后再次 ``connect()`` 会重新打开本端（再选举 Client / Listener）。

对外 API：``connect`` / ``disconnect`` / ``close`` / ``send`` / ``sendall`` /
``recv_into``（及便捷 ``recv``）。不做组帧、介质分包或业务语义。
"""

from __future__ import annotations

import hashlib
import os
import random
import re
import sys
import tempfile
import threading
import time
from collections.abc import Buffer
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

from multiprocessing.connection import Client, Listener

if TYPE_CHECKING:
    from multiprocessing.connection import Connection


# ===== 自定义硬件异常（替代框架依赖） =====
class VirtualHardwareError(Exception):
    """虚拟硬件基础异常。"""

    def __init__(self, message: str, *args, **kwargs):
        self.peer = kwargs.get("peer")
        super().__init__(message, *args)


class ConfigValidationError(VirtualHardwareError):
    """配置（如 channel 格式）校验失败。"""
    pass


class ConnectFailedError(VirtualHardwareError):
    """打开本端设备失败（竞态或权限等）。"""
    pass


class ConnectionLostError(VirtualHardwareError):
    """对端已关闭连接。"""
    pass


class InvalidStateError(VirtualHardwareError):
    """非法状态操作（如已 CLOSED 再 connect）。"""
    pass


class SendError(VirtualHardwareError):
    """发送数据失败。"""
    pass


class SendWouldBlockError(VirtualHardwareError):
    """发送时等待对端配对超时，可重试。"""
    pass


class TransportClosedError(VirtualHardwareError):
    """传输层已关闭。"""
    pass


class DeviceBusyError(VirtualHardwareError):
    """设备已被其他实例占用（进程内独占）。"""
    pass


# ===== 常量与工具函数 =====

_CHANNEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,62}$")
_CHANNEL_MAX_LEN = 63
# 仅用于 Client/Listener 打开竞态，不是「等对端」
_OPEN_RACE_SLEEP = 0.05
_DEFAULT_OPEN_RACE_S = 2.0


class VirtualHardwareState(Enum):
    """虚拟硬件连接状态。

    ``CONNECTED`` 表示本端设备已打开（可能仍在监听、尚未与对端配对），
    语义同串口 ``is_open``，而非「对端一定已在线」。
    """

    DISCONNECTED = "DISCONNECTED"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    FAILED = "FAILED"
    CLOSED = "CLOSED"


def validate_channel(channel: str) -> str:
    """校验虚拟链路标识 ``channel``。

    Raises:
        ConfigValidationError: 为空、超长或含非法字符。
    """
    if not isinstance(channel, str) or not channel:
        raise ConfigValidationError(
            "VirtualHardware.channel 必须为非空字符串（字母/数字/下划线/连字符）。"
        )
    if len(channel) > _CHANNEL_MAX_LEN:
        raise ConfigValidationError(
            f"VirtualHardware.channel 长度不能超过 {_CHANNEL_MAX_LEN}，当前为 {len(channel)}。"
        )
    if not _CHANNEL_RE.match(channel):
        raise ConfigValidationError(
            f"VirtualHardware.channel={channel!r} 含非法字符。"
            f"仅允许字母、数字、下划线、连字符，且须以字母或数字开头。"
        )
    return channel


def channel_to_address(channel: str, *, base_dir: str | None = None) -> str:
    """由 ``channel`` 生成平台相关的 IPC 地址字符串。

    · Windows：``\\\\.\\pipe\\vhw_<channel>``
    · 其它：``{base_dir or tempfile.gettempdir()}/vhw_<channel>.sock``
    """
    name = validate_channel(channel)
    if sys.platform == "win32":
        return rf"\\.\pipe\vhw_{name}"
    root = base_dir if base_dir is not None else tempfile.gettempdir()
    return str(Path(root) / f"vhw_{name}.sock")


def resolve_endpoint(channel: str, *, base_dir: str | None = None) -> tuple[str, str]:
    """解析底层端点（调试 / 日志用）。

    Returns:
        ``("af_pipe", address)`` 或 ``("af_unix", path)``
    """
    address = channel_to_address(channel, base_dir=base_dir)
    family = "af_pipe" if sys.platform == "win32" else "af_unix"
    return family, address


def _ipc_family() -> str:
    return "AF_PIPE" if sys.platform == "win32" else "AF_UNIX"


def _unlink_unix_socket(address: str) -> None:
    if sys.platform == "win32":
        return
    try:
        os.unlink(address)
    except FileNotFoundError:
        pass
    except OSError:
        pass


class VirtualHardware:
    """跨进程虚拟线缆设备（原始字节，无协议）。

    两套 key 概念：

    · ``channel`` —— 设备唯一 key，作为进程内独占（``_opened_channels``）的 key。
      同一进程内相同 ``channel`` 只能被一个实例打开，否则抛 ``DeviceBusyError``。
    · ``link`` —— 可选，该设备上的一条通讯链路标识（如波特率）。与 ``channel``
      合并成通讯唯一 key，真正决定 IPC 地址（管道名 / sock 路径）。两端必须使用
      相同的 ``channel`` + ``link`` 才能配对收发；``link`` 为空时通讯 key 等同 ``channel``。

    用法::

        hw_a = VirtualHardware("device-01", link="ch0")
        hw_a.connect()  # 本端打开成功；对端未上线也 OK（本端保持监听）

        hw_b = VirtualHardware("device-01", link="ch0")  # 另一进程，稍后启动
        hw_b.connect()
        hw_a.sendall(b"ping")  # 对端连入后即可收发

    线程安全：SINGLE_WRITER —— ``recv_into`` / ``send`` 应由同一线程调用；
    后台 accept 线程仅在配对瞬间写入 ``_conn``。
    """

    # 进程内独占：channel → 占用者实例（同一 channel 只能被一个实例打开）。
    # 存实例引用以区分「自己重连」与「他人抢占」：disconnect 后本实例仍持有
    # 独占，可 reconnect；他人则抛 DeviceBusyError。
    _opened_channels: dict[str, "VirtualHardware"] = {}
    _opened_channels_lock = threading.Lock()

    def __init__(
        self,
        channel: str,
        *,
        link: str | None = None,
        connect_timeout: float = _DEFAULT_OPEN_RACE_S,
        read_timeout: float = 1.0,
        write_timeout: float = 5.0,
        base_dir: str | None = None,
        **_ignored: object,
    ) -> None:
        """构造虚拟硬件（此时不打开）。

        Args:
            channel: 设备唯一 key，作为进程内独占（``_opened_channels``）的 key。
            link: 可选，该设备上的一条通讯链路标识（如波特率），与 ``channel``
                合并成通讯唯一 key（决定 IPC 地址）。两端必须使用相同的
                ``channel`` + ``link`` 才能配对；为空时通讯 key 等同 ``channel``。
            connect_timeout: 仅用于打开本端时的 Client/Listener **竞态**窗口（秒），
                **不是**「等待对端上线」超时。成功创建 Listener 后立即返回。
            read_timeout: ``recv_into`` 默认读超时；尚无对端或无数据时返回 ``-1``。
            write_timeout: ``send`` 在 ``timeout=None`` 时等待对端配对的默认上限（秒）。
            base_dir: Unix 套接字目录；默认系统临时目录。Windows 忽略。
            **_ignored: 吸收旧版 ``role`` 等无关参数。
        """
        if channel is None:
            raise ConfigValidationError("VirtualHardware 需要 channel 参数。")
        # 设备唯一 key（进程内独占）：channel
        self._channel = validate_channel(channel)
        # 通讯链路标识（可选）：与 channel 合并成通讯唯一 key；为空时等同 channel。
        if link:
            self._link = validate_channel(link)
            self._comm_channel = validate_channel(f"{self._channel}-{self._link}")
        else:
            self._link = None
            self._comm_channel = self._channel
        self._open_race_timeout = connect_timeout
        self._read_timeout = read_timeout
        self._write_timeout = write_timeout
        self._base_dir = base_dir
        # IPC 地址与认证 key 都基于通讯唯一 key（channel + link），
        # 保证两端只要通讯 key 相同即可配对，不同通讯 key 互不串扰。
        self._address = channel_to_address(self._comm_channel, base_dir=base_dir)
        self._family = _ipc_family()
        self._authkey = hashlib.sha256(self._comm_channel.encode("utf-8")).digest()
        self._conn: Connection | None = None
        self._listener: Listener | None = None
        self._accept_thread: threading.Thread | None = None
        self._paired = threading.Event()
        # 后台 accept 线程已进入阻塞 accept（准备就绪），用于关闭时唤醒
        self._accept_ready = threading.Event()
        self._lock = threading.Lock()
        self._accept_shutdown = False
        self._state = VirtualHardwareState.DISCONNECTED

    @property
    def channel(self) -> str:
        """设备唯一 key（进程内独占 key）。"""
        return self._channel

    @property
    def link(self) -> str | None:
        """通讯链路标识（与 ``channel`` 合并成通讯唯一 key）；未提供时为 ``None``。"""
        return self._link

    @property
    def comm_channel(self) -> str:
        """通讯唯一 key（``channel + link``），决定 IPC 地址。"""
        return self._comm_channel

    @property
    def state(self) -> VirtualHardwareState:
        return self._state

    @property
    def is_connected(self) -> bool:
        """本端是否已打开（类比串口 ``is_open``；不要求对端已配对）。"""
        return self._state is VirtualHardwareState.CONNECTED

    @property
    def is_paired(self) -> bool:
        """是否已与对端完成配对（可直接收发）。"""
        return self._conn is not None and self._state is VirtualHardwareState.CONNECTED

    @property
    def is_listening(self) -> bool:
        """本端是否仍在 Listener 等待对端（已打开但尚未配对）。"""
        return (
            self._listener is not None
            and self._conn is None
            and self._state is VirtualHardwareState.CONNECTED
        )

    @property
    def peer(self) -> str:
        """对端通讯标识（基于通讯唯一 key，用于日志 / 异常信息）。"""
        family, _ = resolve_endpoint(self._comm_channel, base_dir=self._base_dir)
        return f"vhw://{self._comm_channel}?family={family}"

    @property
    def address(self) -> str:
        """底层 IPC 地址（管道名或 sock 路径）。"""
        return self._address

    def fileno(self) -> int | None:
        """命名管道 / Unix 套接字通常无统一 fd，返回 None。"""
        return None

    def connect(self, timeout: float | None = None) -> None:
        """打开本端虚拟设备；已打开则幂等返回。

        算法（**不等待对端上线**）：
        1. 尝试 ``Client`` 连接已有监听端 → 配对成功；
        2. 否则创建 ``Listener``，启动后台 ``accept``，本端立即打开成功；
        3. 若地址被占用（对端正在打开），短暂休眠后重试 1–2。

        ``timeout`` / 构造参数 ``connect_timeout`` 只约束上述打开竞态，
        成功进入监听后**立即返回**，不会因对端未启动而抛超时。

        Raises:
            InvalidStateError: 已 CLOSED。
            ConnectFailedError: 竞态窗口内既无法 Client 也无法创建 Listener。
            DeviceBusyError: 进程内已有其他实例打开了相同 ``channel``。
        """
        if self._state is VirtualHardwareState.CLOSED:
            raise InvalidStateError(
                f"虚拟硬件 {self.peer} 已关闭，不允许重新打开。建议创建新实例。",
                peer=self.peer,
            )
        if self._state is VirtualHardwareState.CONNECTED:
            return  # 幂等，不需要检查独占，因为本实例已经占用了

        # 进程内独占检查：先尝试加锁检查，若无冲突则预占位。
        # 占用者是自己（disconnect 后 reconnect）则允许；他人则抛 DeviceBusyError。
        with VirtualHardware._opened_channels_lock:
            owner = VirtualHardware._opened_channels.get(self._channel)
            if owner is not None and owner is not self:
                raise DeviceBusyError(
                    f"虚拟硬件 channel={self._channel!r} 已被当前进程中的其他实例占用。",
                    peer=self.peer,
                )
            VirtualHardware._opened_channels[self._channel] = self

        race_s = timeout if timeout is not None else self._open_race_timeout
        try:
            self._elect_open(race_s)
        except ConnectFailedError:
            # 打开失败：释放预占位，重新抛出（保留异常链）
            with VirtualHardware._opened_channels_lock:
                if VirtualHardware._opened_channels.get(self._channel) is self:
                    VirtualHardware._opened_channels.pop(self._channel, None)
            raise
        except Exception as exc:
            # 其他异常：释放占位，关闭资源，重新抛出
            with VirtualHardware._opened_channels_lock:
                if VirtualHardware._opened_channels.get(self._channel) is self:
                    VirtualHardware._opened_channels.pop(self._channel, None)
            self._close_resources()
            self._state = VirtualHardwareState.DISCONNECTED
            raise ConnectFailedError(
                f"虚拟硬件 {self.peer} 打开失败：{exc}。",
                peer=self.peer,
            ) from exc

    def _elect_open(self, race_s: float) -> None:
        """选举 Client/Listener 打开本端端点（不含进程内独占检查）。

        成功进入 CONNECTED；失败置 DISCONNECTED 并抛 ConnectFailedError。
        ``race_s`` 仅约束打开竞态，成功进入监听后立即返回。
        """
        self._close_resources()
        self._state = VirtualHardwareState.CONNECTING
        deadline = time.monotonic() + max(0.05, race_s)
        last_exc: BaseException | None = None
        while time.monotonic() < deadline:
            conn = self._try_client_once()
            if conn is not None:
                self._conn = conn
                self._paired.set()
                self._state = VirtualHardwareState.CONNECTED
                return

            listener, err = self._try_listen_once()
            if listener is not None:
                self._listener = listener
                self._state = VirtualHardwareState.CONNECTED
                self._start_accept_thread()
                return
            last_exc = err

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(_OPEN_RACE_SLEEP, remaining) * (0.5 + random.random()))

        self._state = VirtualHardwareState.DISCONNECTED
        raise ConnectFailedError(
            f"虚拟硬件 {self.peer} 无法打开本端端点（Client/Listener 竞态失败）。"
            f"请检查 channel 是否冲突或权限。最后错误：{last_exc!r}",
            peer=self.peer,
        ) from last_exc

    def disconnect(self) -> None:
        """关闭本端（Listener 与 Connection），可再次 ``connect``。幂等。"""
        self._close_resources()
        if self._state is not VirtualHardwareState.CLOSED:
            self._state = VirtualHardwareState.DISCONNECTED

    def close(self) -> None:
        """关闭并进入终态 CLOSED。幂等。"""
        self.disconnect()
        self._state = VirtualHardwareState.CLOSED
        # 终态才释放进程内独占（disconnect 非终态不释放）
        with VirtualHardware._opened_channels_lock:
            if VirtualHardware._opened_channels.get(self._channel) is self:
                VirtualHardware._opened_channels.pop(self._channel, None)

    def recv(self, timeout: float | None = None) -> bytes:
        """接收一条完整消息（``multiprocessing.connection`` 消息边界）。

        Returns:
            载荷字节；超时（含尚无对端）返回 ``b""``。

        Raises:
            ConnectionLostError: 对端关闭连接。
        """
        buf = bytearray()
        n = self.recv_into(buf, timeout=timeout)
        if n < 0:
            return b""
        if n == 0:
            raise ConnectionLostError(
                f"虚拟硬件 {self.peer} 对端已关闭。",
                peer=self.peer,
            )
        return bytes(buf)

    def recv_into(self, buf: bytearray, timeout: float | None = None) -> int:
        """读取一条消息并追加到 ``buf``。

        Returns:
            ``>0`` 字节数；``0`` 对端关闭；``-1`` 超时无数据（含尚在监听、对端未到）。
        """
        wait = self._read_timeout if timeout is None else timeout
        conn = self._ensure_peer(timeout=wait)
        if conn is None:
            return -1

        try:
            if wait is not None and wait > 0:
                if not conn.poll(wait):
                    return -1
            elif not conn.poll(0):
                return -1
            data = conn.recv_bytes()
        except EOFError:
            self._on_peer_closed()
            return 0
        except (BrokenPipeError, ConnectionResetError) as exc:
            _ = exc
            self._on_peer_closed()
            return 0
        except OSError as exc:
            self._on_peer_closed()
            if getattr(exc, "winerror", None) in (109, 232) or "pipe" in str(exc).lower():
                return 0
            raise ConnectionLostError(
                f"读取 {self.peer} 失败：{exc}。",
                peer=self.peer,
            ) from exc

        if not data:
            self._on_peer_closed()
            return 0
        buf.extend(data)
        return len(data)

    def send(self, data: Buffer, timeout: float | None = None) -> int:
        """发送一条消息（整条 ``send_bytes``，保留消息边界）。

        若本端仍在监听，会先等待对端连入。``timeout=None`` 时使用构造参数
        ``write_timeout``（默认 5s），避免 Session IO 线程永久阻塞。
        """
        wait = self._write_timeout if timeout is None else timeout
        conn = self._ensure_peer(timeout=wait)
        if conn is None:
            raise SendWouldBlockError(
                f"发送到 {self.peer} 暂时无法写入（等待对端配对）。"
                f"会话 IO 将暂停本轮排空并继续接收。",
                peer=self.peer,
            )
        payload = bytes(data)
        try:
            conn.send_bytes(payload)
        except (EOFError, OSError, BrokenPipeError) as exc:
            self._on_peer_closed()
            raise SendError(f"发送到 {self.peer} 失败：{exc}。", peer=self.peer) from exc
        return len(payload)

    def sendall(self, data: Buffer, timeout: float | None = None) -> None:
        """发送完整载荷（单条消息）。"""
        self.send(data, timeout=timeout)

    # ── 内部：打开 / 配对 ────────────────────────────────

    def _try_client_once(self) -> Connection | None:
        try:
            return Client(self._address, family=self._family, authkey=self._authkey)
        except Exception:
            return None

    def _try_listen_once(self) -> tuple[Listener | None, BaseException | None]:
        """创建 Listener 并保留（不在此 accept）。失败返回 ``(None, err)``。"""
        try:
            if self._family == "AF_UNIX":
                _unlink_unix_socket(self._address)
            listener = Listener(self._address, family=self._family, authkey=self._authkey)
            return listener, None
        except Exception as exc:
            return None, exc

    def _start_accept_thread(self) -> None:
        """后台阻塞 accept（Windows 管道无法可靠设 accept 超时）。"""
        self._accept_shutdown = False
        self._paired.clear()
        self._accept_ready.clear()

        def _accept_loop() -> None:
            listener = self._listener
            if listener is None:
                return
            self._accept_ready.set()
            try:
                conn = listener.accept()
            except Exception:
                return
            with self._lock:
                if (
                    self._accept_shutdown
                    or self._state is not VirtualHardwareState.CONNECTED
                    or self._conn is not None
                ):
                    try:
                        conn.close()
                    except OSError:
                        pass
                    return
                self._conn = conn
                # 配对完成后可关掉 Listener，Connection 已独立
                try:
                    listener.close()
                except OSError:
                    pass
                if self._listener is listener:
                    self._listener = None
            self._paired.set()

        thread = threading.Thread(
            target=_accept_loop,
            name=f"vhw-accept-{self._channel}",
            daemon=True,
        )
        self._accept_thread = thread
        thread.start()

    def _ensure_peer(self, timeout: float | None) -> Connection | None:
        """确保已与对端配对；若仍在监听则等待后台 accept。

        Returns:
            已配对的 ``Connection``；超时仍无对端则 ``None``。
        """
        if self._state is VirtualHardwareState.CLOSED:
            raise TransportClosedError(
                f"虚拟硬件 {self.peer} 已关闭。",
                peer=self.peer,
            )
        if self._state is not VirtualHardwareState.CONNECTED:
            raise TransportClosedError(
                f"虚拟硬件 {self.peer} 未打开。建议先调用 connect()。",
                peer=self.peer,
            )
        if self._conn is not None:
            return self._conn

        # timeout is None → 一直等到对端（仅内部显式调用；send 已改为有默认上限）
        if timeout is None:
            self._paired.wait()
        else:
            self._paired.wait(timeout=max(0.0, timeout))

        return self._conn

    def _on_peer_closed(self) -> None:
        """对端断开：释放资源；本端仍保持打开时自动重选，等待对端重连。"""
        if self._state is VirtualHardwareState.CLOSED:
            self._close_resources()
            return
        # 本端仍未 close/disconnect：重新选举 Client/Listener，使对端稍后
        # reconnect 时能重新配对；失败（如地址被抢占）则保持 DISCONNECTED。
        try:
            self._elect_open(self._open_race_timeout)
        except ConnectFailedError:
            pass

    def _close_resources(self) -> None:
        """关闭 Listener / Connection，并尽量唤醒后台 accept。

        顺序有意：锁内先置 ``_accept_shutdown`` 并摘掉 listener/conn 引用，
        使在途 accept 无法再安装连接；再关底层；最后 ``_paired.set()``
        唤醒 ``_ensure_peer``（此时 ``_conn`` 已为 None），并 join accept 线程。

        Windows 下 ``PipeListener.accept()`` 阻塞在已从队列弹出的句柄上，
        仅 ``listener.close()``（只关闭仍在队列中的句柄）无法唤醒它。这里先
        连一个本端 dummy client 完成握手，让 accept 线程返回并因 shutdown 关闭连接，
        避免句柄泄漏导致后续同 channel 的 ``Client`` 卡在握手上。
        """
        with self._lock:
            self._accept_shutdown = True
            listener = self._listener
            self._listener = None
            conn = self._conn
            self._conn = None

        if listener is not None:
            # 等 accept 线程进入阻塞 accept 后再连 dummy，避免竞态
            self._accept_ready.wait(timeout=0.5)
            try:
                dummy = Client(self._address, family=self._family, authkey=self._authkey)
            except Exception:
                pass
            else:
                try:
                    dummy.close()
                except OSError:
                    pass
            try:
                listener.close()
            except OSError:
                pass

        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass

        # 唤醒可能卡在 wait 上的收发方；accept 线程因 listener.close / shutdown 退出
        self._paired.set()

        thread = self._accept_thread
        self._accept_thread = None
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

        if self._family == "AF_UNIX":
            _unlink_unix_socket(self._address)