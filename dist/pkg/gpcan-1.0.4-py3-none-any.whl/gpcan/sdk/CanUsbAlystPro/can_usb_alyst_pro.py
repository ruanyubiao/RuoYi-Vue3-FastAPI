from __future__ import annotations

import threading
from ctypes import POINTER, Structure, WinDLL, byref, c_int, c_uint, c_ubyte
from pathlib import Path

from ..can_sdk_def import CanRetCode, CanCardParam, CanRecvObj, CanSendObj
from ..i_can_base import DeviceRefTable, ICanBase


STATUS_OK = 1


class VCI_INIT_CONFIG(Structure):
    _fields_ = [
        ("AccCode", c_uint),
        ("AccMask", c_uint),
        ("Reserved", c_uint),
        ("Filter", c_ubyte),
        ("Timing0", c_ubyte),
        ("Timing1", c_ubyte),
        ("Mode", c_ubyte),
    ]


class VCI_CAN_OBJ(Structure):
    _fields_ = [
        ("ID", c_uint),
        ("TimeStamp", c_uint),
        ("TimeFlag", c_ubyte),
        ("SendType", c_ubyte),
        ("RemoteFlag", c_ubyte),
        ("ExternFlag", c_ubyte),
        ("DataLen", c_ubyte),
        ("Data", c_ubyte * 8),
        ("Reserved", c_ubyte * 3),
    ]


def _convert_baud_rate(baudrate_kbps: int) -> tuple[int, int] | None:
    # Matches C++ convertBaudRate in `cpp/Can/CanUsbAlystPro.cpp`
    table = {
        5: (0xBF, 0xFF),
        10: (0x31, 0x1C),
        20: (0x18, 0x1C),
        40: (0x87, 0xFF),
        50: (0x09, 0x1C),
        80: (0x83, 0xFF),
        100: (0x04, 0x1C),
        125: (0x03, 0x1C),
        200: (0x81, 0xFA),
        250: (0x01, 0x1C),
        400: (0x80, 0xFA),
        500: (0x00, 0x1C),
        666: (0x80, 0xB6),
        800: (0x00, 0x16),
        1000: (0x00, 0x14),
    }
    return table.get(int(baudrate_kbps))


class _ControlCanDll:
    def __init__(self) -> None:
        dll_path = Path(__file__).resolve().parent / "lib" / "ControlCAN.dll"
        self._dll = WinDLL(str(dll_path))

        self._dll.VCI_OpenDevice.argtypes = [c_int, c_int, c_int]
        self._dll.VCI_OpenDevice.restype = c_int

        self._dll.VCI_CloseDevice.argtypes = [c_int, c_int]
        self._dll.VCI_CloseDevice.restype = c_int

        self._dll.VCI_InitCAN.argtypes = [c_int, c_int, c_int, POINTER(VCI_INIT_CONFIG)]
        self._dll.VCI_InitCAN.restype = c_int

        self._dll.VCI_StartCAN.argtypes = [c_int, c_int, c_int]
        self._dll.VCI_StartCAN.restype = c_int

        self._dll.VCI_ResetCAN.argtypes = [c_int, c_int, c_int]
        self._dll.VCI_ResetCAN.restype = c_int

        self._dll.VCI_ClearBuffer.argtypes = [c_int, c_int, c_int]
        self._dll.VCI_ClearBuffer.restype = c_int

        self._dll.VCI_Transmit.argtypes = [c_int, c_int, c_int, POINTER(VCI_CAN_OBJ), c_int]
        self._dll.VCI_Transmit.restype = c_int

        self._dll.VCI_Receive.argtypes = [c_int, c_int, c_int, POINTER(VCI_CAN_OBJ), c_int, c_int]
        self._dll.VCI_Receive.restype = c_int

    def open_device(self, dev_type: int, dev_index: int) -> int:
        return int(self._dll.VCI_OpenDevice(int(dev_type), int(dev_index), 0))

    def close_device(self, dev_type: int, dev_index: int) -> int:
        return int(self._dll.VCI_CloseDevice(int(dev_type), int(dev_index)))

    def init_can(self, dev_type: int, dev_index: int, can_index: int, cfg: VCI_INIT_CONFIG) -> int:
        return int(self._dll.VCI_InitCAN(int(dev_type), int(dev_index), int(can_index), byref(cfg)))

    def start_can(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.VCI_StartCAN(int(dev_type), int(dev_index), int(can_index)))

    def reset_can(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.VCI_ResetCAN(int(dev_type), int(dev_index), int(can_index)))

    def clear_buffer(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.VCI_ClearBuffer(int(dev_type), int(dev_index), int(can_index)))

    def transmit(self, dev_type: int, dev_index: int, can_index: int, frames, size: int) -> int:
        return int(self._dll.VCI_Transmit(int(dev_type), int(dev_index), int(can_index), frames, int(size)))

    def receive(self, dev_type: int, dev_index: int, can_index: int, frames, size: int, timeout: int) -> int:
        return int(self._dll.VCI_Receive(int(dev_type), int(dev_index), int(can_index), frames, int(size), int(timeout)))


_dll_singleton: _ControlCanDll | None = None
_dll_lock = threading.Lock()


def _get_dll() -> _ControlCanDll:
    global _dll_singleton
    with _dll_lock:
        if _dll_singleton is None:
            _dll_singleton = _ControlCanDll()
        return _dll_singleton


class CanUsbAlystPro(ICanBase):
    """同一物理设备只 VCI_OpenDevice 一次，多通道共享。

    ``_devices`` 键为 ``(n_dev_type, n_dev_index)``：一张物理卡一条记录。
    """

    _devices = DeviceRefTable()

    @classmethod
    def get_channel_count(cls) -> int:
        return 2

    def __init__(self, param: CanCardParam):
        if param.n_dev_type < 0:
            param.n_dev_type = 4  # VCI_USBCAN2
        super().__init__(param)
        self._device_key: tuple[int, int] | None = None

    def __del__(self):
        try:
            self.deinit_can()
        except Exception:
            pass

    def init_can(self) -> int:
        dll = _get_dll()
        key = self._key()
        timing = _convert_baud_rate(self._param.n_baud_rate)
        if timing is None:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        timing0, timing1 = timing

        cfg = VCI_INIT_CONFIG()
        cfg.AccCode = 0
        cfg.AccMask = 0xFFFFFFFF
        cfg.Reserved = 0
        cfg.Filter = 1
        cfg.Timing0 = timing0
        cfg.Timing1 = timing1
        cfg.Mode = 0

        def _open(_st) -> bool:
            return dll.open_device(key[0], key[1]) == STATUS_OK

        if self._devices.acquire(key, on_create=_open) is None:
            self._dev_open = False
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._dev_open = True
        self._device_key = key

        if dll.init_can(key[0], key[1], self._param.n_can_index, cfg) != STATUS_OK:
            self._release_device_ref()
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def _release_device_ref(self) -> int:
        if not self._dev_open or self._device_key is None:
            self._dev_open = False
            self._device_key = None
            return int(CanRetCode.CAN_RET_CODE_OK)

        key = self._device_key
        self._dev_open = False
        self._device_key = None
        last = self._devices.release(key)
        if last is None:
            return int(CanRetCode.CAN_RET_CODE_OK)

        dll = _get_dll()
        if dll.close_device(key[0], key[1]) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def deinit_can(self) -> int:
        self.close_can()
        return self._release_device_ref()

    def open_can(self) -> int:
        dll = _get_dll()
        if dll.start_can(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._devices.add_opened_channel(self._key(), int(self._param.n_can_index))
        self._can_open = True
        return int(CanRetCode.CAN_RET_CODE_OK)

    def close_can(self) -> int:
        if self._can_open:
            self._can_open = False
            self._devices.remove_opened_channel(self._key(), int(self._param.n_can_index))
            dll = _get_dll()
            if dll.reset_can(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index) != STATUS_OK:
                return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def clear_buffer(self) -> int:
        dll = _get_dll()
        if dll.clear_buffer(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if un_data_len < 0 or un_data_len > 8:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        self._apply_send_sleep()
        frame = VCI_CAN_OBJ()
        frame.ID = int(un_id)
        frame.SendType = int(un_send_type)
        frame.RemoteFlag = int(un_remote_flag)
        frame.ExternFlag = int(un_extern_flag)
        frame.DataLen = int(un_data_len)
        for i in range(min(int(un_data_len), len(data))):
            frame.Data[i] = data[i]

        dll = _get_dll()
        ret = dll.transmit(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index, frame, 1)
        return int(CanRetCode.CAN_RET_CODE_OK) if ret > 0 else int(CanRetCode.CAN_RET_CODE_ERR)

    def send_list(self, send_list: list[CanSendObj]) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if not send_list:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        frames = (VCI_CAN_OBJ * len(send_list))()
        for idx, obj in enumerate(send_list):
            if obj.un_data_len < 0 or obj.un_data_len > 8:
                return int(CanRetCode.CAN_RET_CODE_ERR)
            frames[idx].ID = int(obj.un_id)
            frames[idx].SendType = int(obj.un_send_type)
            frames[idx].RemoteFlag = int(obj.un_remote_flag)
            frames[idx].ExternFlag = int(obj.un_extern_flag)
            frames[idx].DataLen = int(obj.un_data_len)
            payload = obj.str_data or b""
            for j in range(min(int(obj.un_data_len), len(payload))):
                frames[idx].Data[j] = payload[j]

        self._apply_send_sleep()
        dll = _get_dll()
        ret = dll.transmit(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index, frames, len(send_list))
        return int(CanRetCode.CAN_RET_CODE_OK) if ret > 0 else int(CanRetCode.CAN_RET_CODE_ERR)

    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]:
        if not self._can_open:
            return []
        dll = _get_dll()
        frames = (VCI_CAN_OBJ * int(n_receive_size))()
        ret = dll.receive(
            self._param.n_dev_type,
            self._param.n_dev_index,
            self._param.n_can_index,
            frames,
            int(n_receive_size),
            int(self._param.n_can_timeout_read_ms),
        )
        if ret <= 0:
            return []
        out: list[CanRecvObj] = []
        for i in range(int(ret)):
            frm = frames[i]
            data = bytes(frm.Data[: frm.DataLen])
            out.append(
                CanRecvObj(
                    un_id=int(frm.ID),
                    un_remote_flag=int(frm.RemoteFlag),
                    un_extern_flag=int(frm.ExternFlag),
                    str_data=data,
                    un_data_len=len(data),
                    un_time_stamp=int(frm.TimeStamp),
                )
            )
        return out

