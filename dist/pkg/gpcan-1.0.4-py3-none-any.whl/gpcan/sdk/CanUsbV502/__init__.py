from .can_usb_v502 import CanUsbV502

__all__ = ["CanUsbV502"]

