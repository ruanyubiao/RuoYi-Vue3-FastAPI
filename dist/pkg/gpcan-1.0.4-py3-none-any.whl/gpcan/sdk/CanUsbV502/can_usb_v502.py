from __future__ import annotations

import threading
import time
from ctypes import POINTER, Structure, cdll, byref, c_byte, c_uint, c_uint32, c_ubyte, c_ushort, c_int
from pathlib import Path

from ..can_sdk_def import CanRetCode, CanCardParam, CanRecvObj, CanSendObj
from ..i_can_base import DeviceRefTable, ICanBase


STATUS_OK = 1
# StartCAN 后短暂等待再允许 Transmit（双通道连开后立刻发送会卡死）
_START_SETTLE_S = 0.01
_CLOSE_SETTLE_S = 0.01
# 开通道后短时内 Transmit 常假失败（帧已上总线）；此窗口内对外一律视为发送成功
_SEND_OK_GRACE_S = 30.0


class INIT_CONFIG(Structure):
    _fields_ = [
        ("AccCode", c_uint32),
        ("AccMask", c_uint32),
        ("Reserved", c_uint32),
        ("Filter", c_byte),
        ("Timing0", c_byte),
        ("Timing1", c_byte),
        ("Mode", c_byte),
    ]


class CAN_OBJ(Structure):
    _fields_ = [
        ("ID", c_uint),
        ("TimeStamp", c_uint),
        ("TimeFlag", c_byte),
        ("SendType", c_byte),
        ("RemoteFlag", c_byte),
        ("ExternFlag", c_byte),
        ("DataLen", c_byte),
        ("Data", c_ubyte * 8),
        ("Reserved", c_byte * 3),
    ]


def _convert_baud_rate(baudrate_kbps: int) -> tuple[int, int] | None:
    # Matches C++ convertBaudRate in `cpp/Can/CanUsbV502.cpp`
    table = {
        5: (0xBF, 0xFF),
        10: (0x31, 0x1C),
        20: (0x18, 0x1C),
        40: (0x87, 0xFF),
        50: (0x09, 0x1C),
        80: (0x83, 0xFF),
        100: (0x04, 0x1C),
        125: (0x03, 0x1C),
        200: (0x81, 0xFA),
        250: (0x01, 0x1C),
        400: (0x80, 0xFA),
        500: (0x00, 0x1C),
        666: (0x80, 0xB6),
        800: (0x00, 0x16),
        1000: (0x00, 0x14),
    }
    return table.get(int(baudrate_kbps))


class _ECanDll:
    def __init__(self) -> None:
        dll_path = Path(__file__).resolve().parent / "lib" / "ECanVci64.dll"
        self._dll = cdll.LoadLibrary(str(dll_path))

        self._dll.OpenDevice.argtypes = [c_uint, c_uint, c_uint]
        self._dll.OpenDevice.restype = c_uint

        self._dll.CloseDevice.argtypes = [c_uint, c_uint, c_uint]
        self._dll.CloseDevice.restype = c_uint

        self._dll.InitCAN.argtypes = [c_uint, c_uint, c_uint, POINTER(INIT_CONFIG)]
        self._dll.InitCAN.restype = c_uint

        self._dll.StartCAN.argtypes = [c_uint, c_uint, c_uint]
        self._dll.StartCAN.restype = c_uint

        # These exist in the vendor API (used in C++ wrapper), even if demo.py doesn't show them.
        self._dll.ResetCAN.argtypes = [c_uint, c_uint, c_uint]
        self._dll.ResetCAN.restype = c_uint

        self._dll.ClearBuffer.argtypes = [c_uint, c_uint, c_uint]
        self._dll.ClearBuffer.restype = c_uint

        self._dll.Transmit.argtypes = [c_uint, c_uint, c_uint, POINTER(CAN_OBJ), c_ushort]
        self._dll.Transmit.restype = c_uint

        self._dll.Receive.argtypes = [c_uint, c_uint, c_uint, POINTER(CAN_OBJ), c_ushort, c_int]
        self._dll.Receive.restype = c_uint

    def open_device(self, dev_type: int, dev_index: int) -> int:
        return int(self._dll.OpenDevice(int(dev_type), int(dev_index), 0))

    def close_device(self, dev_type: int, dev_index: int) -> int:
        return int(self._dll.CloseDevice(int(dev_type), int(dev_index), 0))

    def init_can(self, dev_type: int, dev_index: int, can_index: int, cfg: INIT_CONFIG) -> int:
        return int(self._dll.InitCAN(int(dev_type), int(dev_index), int(can_index), byref(cfg)))

    def start_can(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.StartCAN(int(dev_type), int(dev_index), int(can_index)))

    def reset_can(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.ResetCAN(int(dev_type), int(dev_index), int(can_index)))

    def clear_buffer(self, dev_type: int, dev_index: int, can_index: int) -> int:
        return int(self._dll.ClearBuffer(int(dev_type), int(dev_index), int(can_index)))

    def transmit(self, dev_type: int, dev_index: int, can_index: int, frames, size: int) -> int:
        return int(self._dll.Transmit(int(dev_type), int(dev_index), int(can_index), frames, c_ushort(int(size))))

    def receive(self, dev_type: int, dev_index: int, can_index: int, frames, size: int, timeout_ms: int) -> int:
        return int(
            self._dll.Receive(int(dev_type), int(dev_index), int(can_index), frames, c_ushort(int(size)), int(timeout_ms))
        )


_dll_singleton: _ECanDll | None = None
_dll_lock = threading.Lock()
# ECanVci 同一张卡多通道并发 Receive/Transmit 不安全（与 demo_qt 主线程串行 IO 一致）。
# 任一通道 recv/send 占用 DLL 时，其它通道的 recv/send 在此锁上阻塞等待。
_io_lock = threading.Lock()


def _get_dll() -> _ECanDll:
    global _dll_singleton
    with _dll_lock:
        if _dll_singleton is None:
            _dll_singleton = _ECanDll()
        return _dll_singleton


class CanUsbV502(ICanBase):
    """同一物理设备只 OpenDevice 一次，多通道各自 InitCAN/StartCAN。

    ``_devices`` 键为 ``(n_dev_type, n_dev_index)``：一张物理卡一条记录。
    """

    _devices = DeviceRefTable()

    @classmethod
    def get_channel_count(cls) -> int:
        return 2

    def __init__(self, param: CanCardParam):
        if param.n_dev_type < 0:
            param.n_dev_type = 4  # USBCAN2
        super().__init__(param)
        self._device_key: tuple[int, int] | None = None
        self._open_mono: float | None = None

    def __del__(self):
        try:
            self.deinit_can()
        except Exception:
            pass

    def init_can(self) -> int:
        dll = _get_dll()
        key = self._key()
        timing = _convert_baud_rate(self._param.n_baud_rate)
        if timing is None:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        timing0, timing1 = timing

        cfg = INIT_CONFIG()
        cfg.AccCode = 0
        cfg.AccMask = 0xFFFFFFFF
        cfg.Reserved = 0
        cfg.Filter = 1
        cfg.Timing0 = timing0
        cfg.Timing1 = timing1
        cfg.Mode = 0

        def _open(_st) -> bool:
            return dll.open_device(key[0], key[1]) == STATUS_OK

        if self._devices.acquire(key, on_create=_open) is None:
            self._dev_open = False
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._dev_open = True
        self._device_key = key

        if dll.init_can(key[0], key[1], self._param.n_can_index, cfg) != STATUS_OK:
            self._release_device_ref()
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def _release_device_ref(self) -> int:
        if not self._dev_open or self._device_key is None:
            self._dev_open = False
            self._device_key = None
            return int(CanRetCode.CAN_RET_CODE_OK)

        key = self._device_key
        self._dev_open = False
        self._device_key = None
        last = self._devices.release(key)
        if last is None:
            return int(CanRetCode.CAN_RET_CODE_OK)

        dll = _get_dll()
        if dll.close_device(key[0], key[1]) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        time.sleep(_CLOSE_SETTLE_S)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def deinit_can(self) -> int:
        self.close_can()
        return self._release_device_ref()

    def open_can(self) -> int:
        dll = _get_dll()
        if dll.start_can(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        # 清掉关开残留，避免随后批量 Transmit 假失败
        self._devices.add_opened_channel(self._key(), int(self._param.n_can_index))
        self._can_open = True
        self._open_mono = time.monotonic()
        self.clear_buffer()
        time.sleep(_START_SETTLE_S)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def close_can(self) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_OK)

        # 先置位，让并发 recv 尽快退出，避免 CloseDevice 与 Receive 重叠
        self._can_open = False
        self._open_mono = None
        key = self._key()
        ch = int(self._param.n_can_index)
        self._devices.remove_opened_channel(key, ch)

        # 清 RX/TX 软缓冲（厂商手册：缓冲满时 Transmit 返回 0）
        self.clear_buffer()

        # 厂商 demo 关设备只调 CloseDevice，不调 ResetCAN。
        # 最后一路若先 ResetCAN 再 CloseDevice，随后换开另一通道时批量 Transmit
        # 常返回 0（帧已发出）。其它通道仍开着时才 ResetCAN。
        if self._devices.opened_channel_list(key):
            dll = _get_dll()
            if dll.reset_can(key[0], key[1], ch) != STATUS_OK:
                return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def clear_buffer(self) -> int:
        dll = _get_dll()
        if dll.clear_buffer(self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index) != STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def _map_transmit_ret(self, ret: int, expect: int) -> int:
        """开通道后 ``_SEND_OK_GRACE_S`` 内忽略 Transmit 假失败，一律返回成功。"""
        if ret == expect:
            return int(CanRetCode.CAN_RET_CODE_OK)

        # SDK返回有问题，切换通道返回的ret都是0，需要过一段时间才返回正常。
        return int(CanRetCode.CAN_RET_CODE_OK)

        # 不要删除，暂时sdk有问题
        # if self._open_mono is not None and (time.monotonic() - self._open_mono) < _SEND_OK_GRACE_S:
        #     return int(CanRetCode.CAN_RET_CODE_OK)
        # if expect <= 1 and ret > 0:
        #     return int(CanRetCode.CAN_RET_CODE_OK)

        # return int(CanRetCode.CAN_RET_CODE_ERR)

    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if un_data_len < 0 or un_data_len > 8:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        self._apply_send_sleep()
        frame = CAN_OBJ()
        frame.ID = int(un_id)
        frame.SendType = int(un_send_type)
        frame.RemoteFlag = int(un_remote_flag)
        frame.ExternFlag = int(un_extern_flag)
        frame.DataLen = int(un_data_len)
        for i in range(min(int(un_data_len), len(data))):
            frame.Data[i] = data[i]

        with _io_lock:
            dll = _get_dll()
            ret = dll.transmit(
                self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index, frame, 1
            )
        return self._map_transmit_ret(ret, 1)

    def send_list(self, send_list: list[CanSendObj]) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if not send_list:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        frames = (CAN_OBJ * len(send_list))()
        for idx, obj in enumerate(send_list):
            if obj.un_data_len < 0 or obj.un_data_len > 8:
                return int(CanRetCode.CAN_RET_CODE_ERR)
            frames[idx].ID = int(obj.un_id)
            frames[idx].SendType = int(obj.un_send_type)
            frames[idx].RemoteFlag = int(obj.un_remote_flag)
            frames[idx].ExternFlag = int(obj.un_extern_flag)
            frames[idx].DataLen = int(obj.un_data_len)
            payload = obj.str_data or b""
            for j in range(min(int(obj.un_data_len), len(payload))):
                frames[idx].Data[j] = payload[j]

        self._apply_send_sleep()
        n = len(send_list)
        with _io_lock:
            dll = _get_dll()
            ret = dll.transmit(
                self._param.n_dev_type, self._param.n_dev_index, self._param.n_can_index, frames, n
            )
        return self._map_transmit_ret(ret, n)

    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]:
        if not self._can_open:
            return []
        # 跨通道串行 IO：其它通道的 recv/send 未返回时，在此阻塞等待
        with _io_lock:
            dll = _get_dll()
            frames = (CAN_OBJ * int(n_receive_size))()
            ret = dll.receive(
                self._param.n_dev_type,
                self._param.n_dev_index,
                self._param.n_can_index,
                frames,
                int(n_receive_size),
                int(self._param.n_can_timeout_read_ms),
            )
            if ret <= 0:
                return []
            out: list[CanRecvObj] = []
            for i in range(int(ret)):
                frm = frames[i]
                data = bytes(frm.Data[: frm.DataLen])
                out.append(
                    CanRecvObj(
                        un_id=int(frm.ID),
                        un_remote_flag=int(frm.RemoteFlag),
                        un_extern_flag=int(frm.ExternFlag),
                        str_data=data,
                        un_data_len=len(data),
                        un_time_stamp=int(frm.TimeStamp),
                    )
                )
            return out
