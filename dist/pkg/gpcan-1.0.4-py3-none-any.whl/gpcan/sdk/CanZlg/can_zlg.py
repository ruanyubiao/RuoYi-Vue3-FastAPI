from __future__ import annotations

import threading

from ..can_sdk_def import CanRetCode, CanCardParam, CanRecvObj, CanSendObj
from ..i_can_base import DeviceRefTable, ICanBase

# Use vendor-provided python wrapper shipped in `lib/`
from .lib.zlgcan import (  # type: ignore
    INVALID_CHANNEL_HANDLE,
    INVALID_DEVICE_HANDLE,
    ZCAN,
    ZCAN_CHANNEL_INIT_CONFIG,
    ZCAN_STATUS_OK,
    ZCAN_Receive_Data,
    ZCAN_Transmit_Data,
    ZCAN_TYPE_CANFD,
)


def _make_can_id(un_id: int, extern_flag: int, remote_flag: int) -> int:
    can_id = int(un_id) & 0x1FFFFFFF
    if int(extern_flag):
        can_id |= 1 << 31
    if int(remote_flag):
        can_id |= 1 << 30
    return can_id


_zcan_singleton: ZCAN | None = None
_zcan_lock = threading.Lock()


def _get_zcan() -> ZCAN:
    global _zcan_singleton
    with _zcan_lock:
        if _zcan_singleton is None:
            _zcan_singleton = ZCAN()
        return _zcan_singleton


class CanZlg(ICanBase):
    """同一物理设备只 OpenDevice 一次，多通道共享 device_handle，各自 InitCAN/StartCAN。

    ``_devices`` 键为 ``(n_dev_type, n_dev_index)``：一张物理卡一条记录。
    """

    _devices = DeviceRefTable()

    @classmethod
    def get_channel_count(cls) -> int:
        return 2

    def __init__(self, param: CanCardParam):
        if param.n_dev_type < 0:
            param.n_dev_type = 62  # ZCAN_PCIE_CANFD_200U_EX
        super().__init__(param)
        self._zcan = _get_zcan()
        self._device_handle = INVALID_DEVICE_HANDLE
        self._channel_handle = INVALID_CHANNEL_HANDLE
        self._device_key: tuple[int, int] | None = None

    def __del__(self):
        try:
            self.deinit_can()
        except Exception:
            pass

    def init_can(self) -> int:
        zcan = _get_zcan()
        self._zcan = zcan
        key = self._key()

        def _open(st) -> bool:
            handle = zcan.OpenDevice(key[0], key[1], 0)
            if handle == INVALID_DEVICE_HANDLE:
                return False
            st.handle = handle
            return True

        st = self._devices.acquire(key, on_create=_open)
        if st is None:
            self._dev_open = False
            return int(CanRetCode.CAN_RET_CODE_ERR)
        handle = st.handle
        self._device_handle = handle
        self._dev_open = True
        self._device_key = key

        baud = int(self._param.n_baud_rate) * 1000
        # Set CANFD arbitration/data baud rate (C++ sets both)
        if zcan.ZCAN_SetValue(handle, f"{self._param.n_can_index}/canfd_abit_baud_rate", str(baud).encode("utf-8")) != ZCAN_STATUS_OK:
            self._release_device_ref()
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if zcan.ZCAN_SetValue(handle, f"{self._param.n_can_index}/canfd_dbit_baud_rate", str(baud).encode("utf-8")) != ZCAN_STATUS_OK:
            self._release_device_ref()
            return int(CanRetCode.CAN_RET_CODE_ERR)

        init_cfg = ZCAN_CHANNEL_INIT_CONFIG()
        init_cfg.can_type = ZCAN_TYPE_CANFD.value  # Must be CANFD for these devices
        init_cfg.config.canfd.mode = 0
        init_cfg.config.canfd.filter = 1
        init_cfg.config.canfd.acc_code = 0
        init_cfg.config.canfd.acc_mask = 0xFFFFFFFF

        chn_handle = zcan.InitCAN(handle, self._param.n_can_index, init_cfg)
        if chn_handle == INVALID_CHANNEL_HANDLE:
            self._release_device_ref()
            return int(CanRetCode.CAN_RET_CODE_ERR)
        self._channel_handle = chn_handle

        return int(CanRetCode.CAN_RET_CODE_OK)

    def _release_device_ref(self) -> int:
        if not self._dev_open or self._device_key is None:
            self._dev_open = False
            self._device_key = None
            self._device_handle = INVALID_DEVICE_HANDLE
            self._channel_handle = INVALID_CHANNEL_HANDLE
            return int(CanRetCode.CAN_RET_CODE_OK)

        key = self._device_key
        handle = self._device_handle
        self._dev_open = False
        self._device_key = None
        self._device_handle = INVALID_DEVICE_HANDLE
        self._channel_handle = INVALID_CHANNEL_HANDLE
        last = self._devices.release(key)
        if last is None:
            return int(CanRetCode.CAN_RET_CODE_OK)

        close_handle = last.handle if last.handle is not None else handle
        zcan = _get_zcan()
        if close_handle != INVALID_DEVICE_HANDLE and zcan.CloseDevice(close_handle) != ZCAN_STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def deinit_can(self) -> int:
        self.close_can()
        return self._release_device_ref()

    def open_can(self) -> int:
        if self._zcan.StartCAN(self._channel_handle) != ZCAN_STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        # Match C++: disable receive merge (set_device_recv_merge = 0)
        if (
            self._zcan.ZCAN_SetValue(
                self._device_handle,
                f"{self._param.n_can_index}/set_device_recv_merge",
                b"0",
            )
            != ZCAN_STATUS_OK
        ):
            return int(CanRetCode.CAN_RET_CODE_ERR)

        self._devices.add_opened_channel(self._key(), int(self._param.n_can_index))
        self._can_open = True
        return int(CanRetCode.CAN_RET_CODE_OK)

    def close_can(self) -> int:
        if self._can_open:
            self._can_open = False
            self._devices.remove_opened_channel(self._key(), int(self._param.n_can_index))
            if self._zcan.ResetCAN(self._channel_handle) != ZCAN_STATUS_OK:
                return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def clear_buffer(self) -> int:
        if self._zcan.ClearBuffer(self._channel_handle) != ZCAN_STATUS_OK:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        return int(CanRetCode.CAN_RET_CODE_OK)

    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if un_data_len < 0 or un_data_len > 8:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        self._apply_send_sleep()
        msg = ZCAN_Transmit_Data()
        msg.transmit_type = int(un_send_type)
        msg.frame.can_id = _make_can_id(un_id, un_extern_flag, un_remote_flag)
        msg.frame.can_dlc = int(un_data_len)
        for i in range(min(int(un_data_len), len(data))):
            msg.frame.data[i] = data[i]

        ret = self._zcan.Transmit(self._channel_handle, msg, 1)
        return int(CanRetCode.CAN_RET_CODE_OK) if ret > 0 else int(CanRetCode.CAN_RET_CODE_ERR)

    def send_list(self, send_list: list[CanSendObj]) -> int:
        if not self._can_open:
            return int(CanRetCode.CAN_RET_CODE_ERR)
        if not send_list:
            return int(CanRetCode.CAN_RET_CODE_ERR)

        msgs = (ZCAN_Transmit_Data * len(send_list))()
        for i, obj in enumerate(send_list):
            if obj.un_data_len < 0 or obj.un_data_len > 8:
                return int(CanRetCode.CAN_RET_CODE_ERR)
            msgs[i].transmit_type = int(obj.un_send_type)
            msgs[i].frame.can_id = _make_can_id(obj.un_id, obj.un_extern_flag, obj.un_remote_flag)
            msgs[i].frame.can_dlc = int(obj.un_data_len)
            payload = obj.str_data or b""
            for j in range(min(int(obj.un_data_len), len(payload))):
                msgs[i].frame.data[j] = payload[j]

        self._apply_send_sleep()
        ret = self._zcan.Transmit(self._channel_handle, msgs, len(send_list))
        return int(CanRetCode.CAN_RET_CODE_OK) if ret > 0 else int(CanRetCode.CAN_RET_CODE_ERR)

    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]:
        if not self._can_open:
            return []

        rcv, ret = self._zcan.Receive(self._channel_handle, int(n_receive_size), int(self._param.n_can_timeout_read_ms))
        if ret <= 0:
            return []

        out: list[CanRecvObj] = []
        for i in range(int(ret)):
            msg: ZCAN_Receive_Data = rcv[i]
            can_id = int(msg.frame.can_id)
            un_id = can_id & 0x1FFFFFFF
            extern_flag = 1 if (can_id & (1 << 31)) else 0
            remote_flag = 1 if (can_id & (1 << 30)) else 0
            dlc = int(msg.frame.can_dlc)
            data = bytes(msg.frame.data[:dlc])
            out.append(
                CanRecvObj(
                    un_id=un_id,
                    un_remote_flag=remote_flag,
                    un_extern_flag=extern_flag,
                    str_data=data,
                    un_data_len=len(data),
                    un_time_stamp=int(msg.timestamp),
                )
            )
        return out
