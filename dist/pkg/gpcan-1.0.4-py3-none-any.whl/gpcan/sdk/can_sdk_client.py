from __future__ import annotations

from .can_sdk_def import (
    CAN_VENDOR_DISPLAY_NAMES,
    CanCardParam,
    CanRecvObj,
    CanRetCode,
    CanSendObj,
    CanVendorInfo,
    CanVendorType,
)
from .i_can_base import ICanBase

_MAX_DATA_LEN = 8
_MAX_ID_STD = 0x7FF
_MAX_ID_EXT = 0x1FFFFFFF


def _vendor_impl_class(vendor: int) -> type[ICanBase] | None:
    """返回厂家驱动类（不实例化），用于创建实例与查询静态属性。"""
    vendor = int(vendor)
    if vendor == int(CanVendorType.CAN_VENDOR_DEMO):
        from .CanDemo.can_demo import CanDemo

        return CanDemo
    if vendor == int(CanVendorType.CAN_VENDOR_USB_V502):
        from .CanUsbV502.can_usb_v502 import CanUsbV502

        return CanUsbV502
    if vendor == int(CanVendorType.CAN_VENDOR_USB_ALYST_PRO):
        from .CanUsbAlystPro.can_usb_alyst_pro import CanUsbAlystPro

        return CanUsbAlystPro
    if vendor == int(CanVendorType.CAN_VENDOR_ZLG):
        from .CanZlg.can_zlg import CanZlg

        return CanZlg
    return None


def create_vendor_client(vendor: int, param: CanCardParam) -> ICanBase | None:
    """按厂家类型创建硬件驱动实例。默认 n_dev_type 由各 SDK 构造函数补齐。"""
    cls = _vendor_impl_class(vendor)
    return cls(param) if cls is not None else None


class CanSdkClient:
    """硬件层 CAN 客户端（与项目协议无关）。单帧数据最长 8 字节。"""

    def __init__(self, vendor: int, param: CanCardParam):
        self._vendor = int(vendor)
        self._param = param
        self._client: ICanBase | None = create_vendor_client(self._vendor, self._param)
        self._last_error = ""

    def get_last_error(self) -> str:
        return self._last_error

    def _fail(self, msg: str) -> int:
        self._last_error = msg
        return int(CanRetCode.CAN_RET_CODE_ERR)

    def _check_frame(self, can_id: int, un_data_len: int, un_extern_flag: int) -> str:
        """校验通过返回空串，否则返回错误信息。"""
        cid = int(can_id)
        if cid < 0:
            return f"invalid can_id={cid}"
        if int(un_extern_flag):
            if cid > _MAX_ID_EXT:
                return f"id=0x{cid:X} exceeds extended limit 0x{_MAX_ID_EXT:X}"
        elif cid > _MAX_ID_STD:
            return f"id=0x{cid:X} exceeds standard limit 0x{_MAX_ID_STD:X}"
        if un_data_len < 0 or un_data_len > _MAX_DATA_LEN:
            return f"un_data_len={un_data_len} out of range 0..{_MAX_DATA_LEN}"
        return ""

    def init_can(self) -> int:
        if not self._client:
            return self._fail("unknown vendor")
        return self._client.init_can()

    def deinit_can(self) -> int:
        if not self._client:
            return self._fail("unknown vendor")
        return self._client.deinit_can()

    def open_can(self) -> int:
        if not self._client:
            return self._fail("unknown vendor")
        return self._client.open_can()

    def close_can(self) -> int:
        if not self._client:
            return self._fail("unknown vendor")
        return self._client.close_can()

    def is_connected(self) -> int:
        return self._client.is_connected() if self._client else 0

    def clear_buffer(self) -> int:
        if not self._client:
            return self._fail("unknown vendor")
        return self._client.clear_buffer()

    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int:
        """发送单帧。"""
        if not self._client:
            return self._fail("unknown vendor")
        err = self._check_frame(un_id, un_data_len, un_extern_flag)
        if err:
            return self._fail(err)
        return self._client.send(
            un_id, data, un_data_len, un_send_type, un_remote_flag, un_extern_flag
        )

    def send_obj(self, obj: CanSendObj) -> int:
        """发送单个 :class:`CanSendObj`。"""
        if not self._client:
            return self._fail("unknown vendor")
        err = self._check_frame(obj.un_id, obj.un_data_len, obj.un_extern_flag)
        if err:
            return self._fail(err)
        return self._client.send(
            obj.un_id,
            obj.str_data or b"",
            obj.un_data_len,
            obj.un_send_type,
            obj.un_remote_flag,
            obj.un_extern_flag,
        )

    def send_obj_list(self, send_list: list[CanSendObj]) -> int:
        """发送 :class:`CanSendObj` 列表。"""
        if not self._client:
            return self._fail("unknown vendor")
        if not send_list:
            return self._fail("empty send list")
        for obj in send_list:
            err = self._check_frame(obj.un_id, obj.un_data_len, obj.un_extern_flag)
            if err:
                return self._fail(err)
        return self._client.send_list(send_list)

    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]:
        if not self._client:
            return []
        return self._client.recv(n_receive_size)

    def get_param(self) -> CanCardParam:
        return self._param

    def get_opened_channel_list(self) -> list[int]:
        if not self._client:
            return []
        return self._client.get_opened_channel_list()

    def get_channel_count(self) -> int:
        """当前厂家设备的物理通道数。"""
        if not self._client:
            return 0
        return int(self._client.get_channel_count())

    @staticmethod
    def get_supported_device_list() -> dict[int, CanVendorInfo]:
        """返回支持的 CAN 卡信息：``{vendor: CanVendorInfo}``。

        含显示名、物理通道数、当前已打开通道号列表。
        """
        out: dict[int, CanVendorInfo] = {}
        for vendor, name in CAN_VENDOR_DISPLAY_NAMES.items():
            cls = _vendor_impl_class(vendor)
            channels = int(cls.get_channel_count()) if cls is not None else 0
            opened = tuple(cls.get_opened_channel_list()) if cls is not None else ()
            out[int(vendor)] = CanVendorInfo(
                name=name,
                channel_count=channels,
                opened_channel=opened,
            )
        return out
