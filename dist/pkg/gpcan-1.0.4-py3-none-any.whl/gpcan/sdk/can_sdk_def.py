from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


@dataclass
class CanCardParam:
    """CAN 硬件初始化参数（仅与厂家 SDK / 物理通道相关）。"""

    n_can_index: int = 0                # CAN 通道序号（0:CAN1, 1:CAN2, 2:CAN3, 3:CAN4）
    n_baud_rate: int = 500              # 波特率，单位 Kbps（500:500Kbps, 250:250Kbps, 125:125Kbps, 1000:1Mbps）
    n_dev_type: int = -1                # 设备类型（厂家 SDK 定义，<0 表示用默认值）
    n_dev_index: int = 0                # 设备序号，主板插入多张CAN卡时，需要指定CAN卡序号
    n_can_timeout_read_ms: int = 0      # 读超时时间，单位毫秒
    n_can_send_sleep_ms: int = -1       # 写间隔时间，单位毫秒，-1 表示不等待


@dataclass
class CanSendObj:
    """最终需要发送的 CAN 消息：业务层与硬件层之间的桥梁。"""

    un_send_type: int = 0      # 发送类型 CanSendType
    un_remote_flag: int = 0    # 0:数据帧  1:远程帧
    un_extern_flag: int = 0    # 0:标准帧  1:扩展帧

    un_data_len: int = 0       # 数据长度（0~8）
    str_data: bytes = b""      # 数据内容
    un_id: int = 0             # CAN帧ID（11位）


@dataclass
class CanRecvObj:
    """硬件层接收帧（单帧，与厂家 SDK 对应，不含业务字段）。"""

    # send_type发送控制参数，不属于 CAN 帧内容，因此在接收端无法从 can_id 或接收到的数据中恢复出来。
    # un_send_type: int = 0      # 发送类型 CanSendType
    un_remote_flag: int = 0    # 0:数据帧  1:远程帧
    un_extern_flag: int = 0    # 0:标准帧  1:扩展帧

    un_data_len: int = 0       # 数据长度
    str_data: bytes = b""      # 数据内容
    un_id: int = 0             # CAN帧ID（11位）
    un_time_stamp: int = 0     # 硬件时间戳（厂家定义，未提供则为 0）


class CanSendType(IntEnum):
    """发送帧类型。"""

    CAN_SEND_TYPE_NORMAL = 0             # 正常发送
    CAN_SEND_TYPE_SINGLE_SEND = 1        # 单次发送
    CAN_SEND_TYPE_SEND_RECV = 2          # 自发自收
    CAN_SEND_TYPE_SINGLE_SEND_RECV = 3   # 单次自发自收


class CanRemoteFlag(IntEnum):
    """远程帧标志。"""

    CAN_REMOTE_FLAG_DATA = 0    # 数据帧
    CAN_REMOTE_FLAG_REMOTE = 1  # 远程帧


class CanExternFlag(IntEnum):
    """扩展帧标志。"""

    CAN_EXTERN_FLAG_STANDARD = 0  # 标准帧
    CAN_EXTERN_FLAG_EXTENDED = 1  # 扩展帧


class CanRetCode(IntEnum):
    """接口返回码。"""

    CAN_RET_CODE_ERR = 0  # 失败
    CAN_RET_CODE_OK = 1   # 成功


class CanVendorType(IntEnum):
    """CAN 设备厂家类型。"""

    CAN_VENDOR_DEMO = 0           # 演示/虚拟设备
    CAN_VENDOR_USB_V502 = 1       # USB-CAN V502
    CAN_VENDOR_USB_ALYST_PRO = 2  # USB-CAN Alyst Pro
    CAN_VENDOR_ZLG = 3            # PCIE ZLG CANFD


# vendor 枚举值 -> 显示名称
CAN_VENDOR_DISPLAY_NAMES: dict[int, str] = {
    int(CanVendorType.CAN_VENDOR_DEMO): "演示/虚拟设备",
    int(CanVendorType.CAN_VENDOR_USB_V502): "USB-CAN V502",
    int(CanVendorType.CAN_VENDOR_USB_ALYST_PRO): "USB-CAN Alyst Pro",
    int(CanVendorType.CAN_VENDOR_ZLG): "PCIE ZLG CANFD",
}


@dataclass(frozen=True)
class CanVendorInfo:
    """支持的 CAN 卡信息（静态能力 + 当前已打开通道）。"""

    name: str
    channel_count: int
    opened_channel: tuple[int, ...] = ()
