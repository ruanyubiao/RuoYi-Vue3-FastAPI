from __future__ import annotations

import abc
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .can_sdk_def import CanCardParam, CanRecvObj, CanSendObj


@dataclass
class DeviceRefState:
    """一张物理卡 ``(dev_type, n_dev_index)`` 的占用状态。

    - ``holders``：已 ``init_can`` 的客户端数（>0 时设备保持 OpenDevice）
    - ``opened``：``n_can_index -> open_can 引用数``（StartCAN 后的通道）
    - ``handle``：厂家可选设备句柄（如 ZLG）
    """

    holders: int = 0
    opened: dict[int, int] = field(default_factory=dict)
    handle: Any = None

    def opened_channel_list(self) -> list[int]:
        return sorted(ch for ch, n in self.opened.items() if n > 0)


class DeviceRefTable:
    """线程安全的设备引用表：封装 ``_device_lock`` + 引用增减 / 已开通道记账。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._refs: dict[tuple[int, int], DeviceRefState] = {}

    def opened_channel_list(self, key: tuple[int, int] | None = None) -> list[int]:
        """已 StartCAN 的通道号。

        ``key`` 为 None 时汇总全部物理卡；传入 ``(dev_type, n_dev_index)`` 时只返回该卡。
        """
        with self._lock:
            if key is not None:
                st = self._refs.get(key)
                return st.opened_channel_list() if st is not None else []
            out: set[int] = set()
            for st in self._refs.values():
                out.update(st.opened_channel_list())
            return sorted(out)
    def clear(self) -> None:
        """清空全部引用（仅用于测试隔离）。"""
        with self._lock:
            self._refs.clear()

    def acquire(
        self,
        key: tuple[int, int],
        on_create: Callable[[DeviceRefState], bool] | None = None,
    ) -> DeviceRefState | None:
        """``init_can``：holders+1；首开时调用 ``on_create``，失败返回 None。"""
        with self._lock:
            st = self._refs.get(key)
            if st is None:
                st = DeviceRefState()
                if on_create is not None and not on_create(st):
                    return None
                self._refs[key] = st
            st.holders += 1
            return st

    def release(self, key: tuple[int, int]) -> DeviceRefState | None:
        """``deinit``：holders-1；若已是最后一个持有者则弹出并返回该状态（供 CloseDevice）。"""
        with self._lock:
            st = self._refs.get(key)
            if st is None:
                return None
            st.holders -= 1
            if st.holders > 0:
                return None
            return self._refs.pop(key, None)

    def add_opened_channel(self, key: tuple[int, int], can_index: int) -> None:
        with self._lock:
            st = self._refs.get(key)
            if st is None:
                return
            st.opened[can_index] = st.opened.get(can_index, 0) + 1

    def remove_opened_channel(self, key: tuple[int, int], can_index: int) -> None:
        with self._lock:
            st = self._refs.get(key)
            if st is None:
                return
            refs = st.opened.get(can_index, 1) - 1
            if refs > 0:
                st.opened[can_index] = refs
            else:
                st.opened.pop(can_index, None)


class ICanBase(abc.ABC):
    def __init__(self, param: CanCardParam):
        self._param = param
        self._can_open = False
        self._dev_open = False
        # 发送间隔计时锚点（_apply_send_sleep 使用）
        self._last_send_ts_ms = 0.0

    def get_param(self) -> CanCardParam:
        return self._param

    def _key(self) -> tuple[int, int]:
        """物理卡键：(设备类型 n_dev_type, 设备序号 n_dev_index)。

        与通道号 ``n_can_index`` 无关——同卡多通道共用此键。子类（如 Demo）可覆盖。
        """
        return (int(self._param.n_dev_type), int(self._param.n_dev_index))

    def _apply_send_sleep(self) -> None:
        """按 ``n_can_send_sleep_ms`` 在两次发送之间限速；<=0 时不等待。"""
        if self._param.n_can_send_sleep_ms <= 0:
            return
        now_ms = time.monotonic() * 1000.0
        rest = float(self._param.n_can_send_sleep_ms) - (now_ms - self._last_send_ts_ms)
        if rest > 0:
            time.sleep(rest / 1000.0)
        self._last_send_ts_ms = time.monotonic() * 1000.0

    @abc.abstractmethod
    def init_can(self) -> int: ...

    @abc.abstractmethod
    def deinit_can(self) -> int: ...

    @abc.abstractmethod
    def open_can(self) -> int: ...

    @abc.abstractmethod
    def close_can(self) -> int: ...

    def is_connected(self) -> int:
        return 1 if self._can_open else 0

    @abc.abstractmethod
    def clear_buffer(self) -> int: ...

    @abc.abstractmethod
    def send(
        self,
        un_id: int,
        data: bytes,
        un_data_len: int = 8,
        un_send_type: int = 0,
        un_remote_flag: int = 0,
        un_extern_flag: int = 0,
    ) -> int: ...

    @abc.abstractmethod
    def send_list(self, send_list: list[CanSendObj]) -> int: ...

    @abc.abstractmethod
    def recv(self, n_receive_size: int = 64) -> list[CanRecvObj]: ...

    @classmethod
    def get_opened_channel_list(cls) -> list[int]:
        """返回当前已打开的通道号列表（n_can_index，去重排序）。"""
        devices = getattr(cls, "_devices", None)
        return devices.opened_channel_list() if devices is not None else []

    @classmethod
    def get_channel_count(cls) -> int:
        """该厂家设备的物理通道数（固定属性）。"""
        return 0
