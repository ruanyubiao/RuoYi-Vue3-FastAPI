"""YJ216 组帧：11 位 ID + 分片数据域。"""

from __future__ import annotations

from ...sdk.can_sdk_def import CanSendObj
from ..can_protocol_base import make_send_obj
from ..can_protocol_def import CanCableParam, CanSendParam
from .defs import (
    Yj216FrameFlag,
    Yj216FrameType,
    Yj216NodeAddr,
    Yj216NodeType,
)
from .segment import Yj216Segmenter

__all__ = ["Yj216PacketReq", "resolve_node_addr"]

_DEFAULT_NODE = int(Yj216NodeAddr.LCD_PAYLOAD)


def resolve_node_addr(node_addr: int, *, broadcast: bool) -> int:
    """点对点地址取低 4 位；0 回落到液晶载荷 ``0xD``。广播固定地址 0。"""
    if broadcast:
        return 0
    addr = int(node_addr)
    if addr == 0:
        return _DEFAULT_NODE
    masked = addr & 0xF
    if masked == 0:
        return _DEFAULT_NODE
    return masked


class Yj216PacketReq:
    """一条应用数据 → 带帧标志的 CAN 帧列表。"""

    def __init__(
        self,
        data: bytes = b"",
        *,
        frame_type: int = int(Yj216FrameType.COMMAND_P2P),
        broadcast: bool = False,
        from_slave: bool = False,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        self._data = bytes(data)
        self._frame_type = int(frame_type) & 0x7
        self._broadcast = bool(broadcast)
        self._from_slave = bool(from_slave)
        self._send_param = send_param or CanSendParam()
        self._cable_param = cable_param or CanCableParam()

    @staticmethod
    def generate_id(
        node_type: int,
        frame_type: int,
        node_addr: int,
        cable_flag: int,
        frame_flag: int,
    ) -> int:
        """ID10 主从 | ID9~6 地址 | ID5~3 帧类型 | ID2 总线 | ID1~0 单复帧。"""
        can_id = 0
        can_id |= (int(node_type) & 0x1) << 10
        can_id |= (int(node_addr) & 0xF) << 6
        can_id |= (int(frame_type) & 0x7) << 3
        can_id |= (int(cable_flag) & 0x1) << 2
        can_id |= int(frame_flag) & 0x3
        return can_id

    def build(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
        *,
        segmenter: Yj216Segmenter | None = None,
    ) -> list[CanSendObj]:
        sp = send_param if send_param is not None else self._send_param
        cp = cable_param if cable_param is not None else self._cable_param
        seg = segmenter or Yj216Segmenter()
        chunks = seg.split(self._data)
        node_addr = resolve_node_addr(cp.n_node_addr_to, broadcast=self._broadcast)
        node_type = (
            int(Yj216NodeType.SLAVE) if self._from_slave else int(Yj216NodeType.MASTER)
        )
        cable_flag = int(cp.n_cable_flag) & 0x1
        send_count = len(chunks)
        frames: list[CanSendObj] = []
        for i, chunk in enumerate(chunks):
            if send_count == 1:
                part_flag = int(Yj216FrameFlag.SINGLE)
            elif i == 0:
                part_flag = int(Yj216FrameFlag.FIRST)
            elif i < send_count - 1:
                part_flag = int(Yj216FrameFlag.MIDDLE)
            else:
                part_flag = int(Yj216FrameFlag.LAST)
            frames.append(
                make_send_obj(
                    sp,
                    chunk,
                    self.generate_id(
                        node_type,
                        self._frame_type,
                        node_addr,
                        cable_flag,
                        part_flag,
                    ),
                )
            )
        return frames
