"""YJ216 协议解析：按帧标志重组，应用数据透传。"""

from __future__ import annotations

from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import ProtocolParseResult, ProtocolParserBase
from ..can_protocol_def import CanProtocolType
from ..identity_packet import IdentityPacketDecoder
from .segment import Yj216Segmenter

__all__ = ["ProtocolParser"]


class ProtocolParser(ProtocolParserBase):
    """重组复帧并去掉长度前缀。不解析遥测数据域，不校验 SUM。"""

    PROTOCOL = CanProtocolType.YJ216

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        super().__init__(params)
        self._segmenter = Yj216Segmenter()
        self._packet_dec = IdentityPacketDecoder()

    def feed(self, frames: list[CanRecvObj]) -> None:
        if not frames:
            return
        self._segmenter.feed_many(frames)
        for msg in self._segmenter.drain_assembled():
            logical = bytes(msg.data or b"")
            payload = self._packet_dec.unwrap(logical)
            self._ready.append(
                ProtocolParseResult(
                    src=list(msg.src),
                    data=logical,
                    payload=payload,
                    packet_param={
                        "un_id": msg.un_id,
                        "n_frame_flag": msg.n_frame_flag,
                    },
                )
            )

    def reset(self) -> None:
        self._segmenter.reset()
        super().reset()
