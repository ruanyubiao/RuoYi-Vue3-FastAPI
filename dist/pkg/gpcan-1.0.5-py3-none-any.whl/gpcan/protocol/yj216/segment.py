"""YJ216 传输分片：≤8 字节单帧；更长则首帧带 2 字节大端长度。"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import Segmenter
from .defs import YJ216_APP_DATA_MAX, Yj216FrameFlag

__all__ = ["Yj216Assembled", "Yj216Segmenter"]

_FRAME_DATA_LEN = 8
_FIRST_PAYLOAD = 6  # 首帧 8 字节中扣掉 2 字节长度


@dataclass
class Yj216Assembled:
    """分片重组结果。``data`` 是应用数据，不含复帧长度前缀。"""

    data: bytes
    src: list[CanRecvObj] = field(default_factory=list)
    un_id: int = 0
    n_frame_flag: int = 0


def _frame_flag(obj: CanRecvObj) -> int:
    return int(obj.un_id) & 0x3


def _base_id(un_id: int) -> int:
    return int(un_id) & ~0x3


class Yj216Segmenter(Segmenter):
    """TX 生成数据域；RX 按 ID 低 2 位重组，长度不符则丢弃。"""

    def __init__(self) -> None:
        self._src: list[CanRecvObj] = []
        self._ready: list[Yj216Assembled] = []
        self._byte_ready: list[bytes] = []

    def split(self, logical: bytes) -> list[bytes]:
        """应用数据 → 各帧数据域。

        ≤8 字节：原样单帧。大于 8：首帧为 ``长度 BE | DATA0..5``，其余按 8 字节切。
        """
        data = bytes(logical)
        if len(data) > YJ216_APP_DATA_MAX:
            raise ValueError(
                f"application data exceeds {YJ216_APP_DATA_MAX} bytes: {len(data)}"
            )
        if len(data) <= _FRAME_DATA_LEN:
            return [data]
        chunks = [len(data).to_bytes(2, "big") + data[:_FIRST_PAYLOAD]]
        rest = data[_FIRST_PAYLOAD:]
        while rest:
            chunks.append(rest[:_FRAME_DATA_LEN])
            rest = rest[_FRAME_DATA_LEN:]
        return chunks

    def feed(self, data: bytes) -> None:
        """无帧标志的字节按一条完整应用数据处理。"""
        self._byte_ready.append(bytes(data))

    def feed_frame(self, obj: CanRecvObj) -> None:
        completed = self._feed_one(obj)
        if completed is not None:
            self._ready.append(completed)

    def feed_many(self, items: Sequence[Any]) -> None:
        for item in items:
            if isinstance(item, CanRecvObj):
                self.feed_frame(item)
            elif isinstance(item, (bytes, bytearray, memoryview)):
                self.feed(bytes(item))
            else:
                raise TypeError(
                    f"Yj216Segmenter.feed_many expects CanRecvObj or bytes, got {type(item)!r}"
                )

    def drain(self) -> list[bytes]:
        out = self._byte_ready
        self._byte_ready = []
        return out

    def drain_assembled(self) -> list[Yj216Assembled]:
        out = self._ready
        self._ready = []
        return out

    def assemble(self, recv_list: list[CanRecvObj]) -> list[Yj216Assembled]:
        for obj in recv_list:
            self.feed_frame(obj)
        return self.drain_assembled()

    def reset(self) -> None:
        self._src = []
        self._ready.clear()
        self._byte_ready.clear()

    def _make_result(self, src: list[CanRecvObj], data: bytes) -> Yj216Assembled:
        first = src[0]
        return Yj216Assembled(
            data=data,
            src=list(src),
            un_id=_base_id(first.un_id) | int(Yj216FrameFlag.SINGLE),
            n_frame_flag=int(Yj216FrameFlag.SINGLE),
        )

    def _multi_app(self, src: list[CanRecvObj]) -> bytes | None:
        first = bytes(src[0].str_data or b"")
        if len(first) != _FRAME_DATA_LEN:
            return None
        expected = int.from_bytes(first[:2], "big")
        if expected <= _FRAME_DATA_LEN or expected > YJ216_APP_DATA_MAX:
            return None
        app = bytearray(first[2:])
        for frame in src[1:]:
            chunk = bytes(frame.str_data or b"")
            if _frame_flag(frame) == int(Yj216FrameFlag.MIDDLE) and len(chunk) != _FRAME_DATA_LEN:
                return None
            if not chunk or len(chunk) > _FRAME_DATA_LEN:
                return None
            app.extend(chunk)
        if len(app) != expected:
            return None
        return bytes(app)

    def _feed_one(self, obj: CanRecvObj) -> Yj216Assembled | None:
        flag = _frame_flag(obj)
        first = int(Yj216FrameFlag.FIRST)
        middle = int(Yj216FrameFlag.MIDDLE)
        last = int(Yj216FrameFlag.LAST)
        single = int(Yj216FrameFlag.SINGLE)

        if flag == single:
            self._src = []
            return self._make_result([obj], bytes(obj.str_data or b""))

        if flag == first:
            payload = bytes(obj.str_data or b"")
            if len(payload) != _FRAME_DATA_LEN:
                self._src = []
                return None
            expected = int.from_bytes(payload[:2], "big")
            if expected <= _FRAME_DATA_LEN or expected > YJ216_APP_DATA_MAX:
                self._src = []
                return None
            self._src = [obj]
            return None

        if flag == middle:
            if (
                self._src
                and _frame_flag(self._src[-1]) in (first, middle)
                and _base_id(obj.un_id) == _base_id(self._src[0].un_id)
            ):
                self._src.append(obj)
                return None
            self._src = []
            return None

        if flag == last:
            if (
                self._src
                and _frame_flag(self._src[-1]) in (first, middle)
                and _base_id(obj.un_id) == _base_id(self._src[0].un_id)
            ):
                self._src.append(obj)
                app = self._multi_app(self._src)
                src = self._src
                self._src = []
                if app is None:
                    return None
                return self._make_result(src, app)
            self._src = []
            return None

        self._src = []
        return None
