"""BIU 协议离线生成。"""

from __future__ import annotations

from typing import Any

from ..can_protocol_def import CanCableParam, CanProtocolType, CanSendParam
from ..can_protocol_base import ProtocolBuilderBase, ProtocolBuildResult
from ..time_sync import TimeSyncManager
from .defs import EPOCH_UTC, BiuSystemCmd, CanNodeAddr
from .packet import BiuPacketReq

__all__ = ["ProtocolBuilder"]

_FRAME_TYPE_TIME = 0x30
_DATA_CODE_TIME = 0x00
_FRAME_TYPE_TM_REQ = 0x00
_NODE_ADDR = int(CanNodeAddr.CAN_NODE_ADDR_LASER_B)


class ProtocolBuilder(ProtocolBuilderBase):
    """BIU 协议内容生成。目标地址固定激光 B；线路由 ``cable_param`` 指定。"""

    PROTOCOL = CanProtocolType.BIU

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        cp = cable_param or CanCableParam(n_node_addr_to=_NODE_ADDR, n_cable_flag=0)
        if cp.n_node_addr_to == 0:
            cp = CanCableParam(
                n_node_addr_to=_NODE_ADDR,
                n_cable_flag=cp.n_cable_flag,
            )
        super().__init__(send_param, cp)

    def set_cable_param(self, cable_param: CanCableParam) -> None:
        cp = cable_param or CanCableParam()
        if cp.n_node_addr_to == 0:
            cp = CanCableParam(
                n_node_addr_to=_NODE_ADDR,
                n_cable_flag=cp.n_cable_flag,
            )
        self._cable_param = cp

    def _build_msg(
        self,
        data: bytes,
        *,
        is_broadcast: bool = False,
        is_bus_data: bool = False,
        is_from_slave: bool = False,
    ) -> ProtocolBuildResult:
        req = BiuPacketReq(
            data,
            is_broadcast=is_broadcast,
            is_bus_data=is_bus_data,
            is_from_slave=is_from_slave,
            send_param=self._send_param,
            cable_param=self._cable_param,
        )
        return ProtocolBuildResult(data=bytes(data), frames=req.build())

    def build_time_sync(
        self,
        sec: int,
        ms: int = 0,
        *,
        apply_offset: bool = True,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """时间广播：``30 00 | onboard_sec BE | ms BE``。

        ``sec``/``ms`` 为基准 Unix 时刻。``apply_offset=True``（默认）时再叠加
        :class:`~gpcan.protocol.time_sync.TimeSyncManager` 中 BIU 通道的偏差，用于定时广播（线上 = 系统时间 + offset）。
        ``apply_offset=False`` 时按给定时刻直接组帧（不叠加偏差），用于单次下发。

        例：UTC 2026-08-06 08:00:00、无偏差 → ``30 00 0c 68 5e 00 00 00``。
        """
        del kwargs
        offset_sec = offset_ms = 0
        if apply_offset:
            offset_sec, offset_ms = TimeSyncManager.find(self.PROTOCOL).get_offset_parts()
        onboard = int(sec) - EPOCH_UTC + int(offset_sec)
        if onboard < 0 or onboard > 0xFFFFFFFF:
            raise ValueError(f"onboard seconds out of range: {onboard}")
        ms_val = int(ms) + int(offset_ms)
        if ms_val < 0 or ms_val > 0xFFFF:
            raise ValueError(f"milliseconds out of range: {ms_val}")

        data = (
            bytes([_FRAME_TYPE_TIME, _DATA_CODE_TIME])
            + onboard.to_bytes(4, "big")
            + ms_val.to_bytes(2, "big")
        )
        return self._build_msg(data, is_broadcast=True)

    def build_broadcast(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        return self._build_msg(bytes(data), is_broadcast=True)

    def build_telecommand(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        return self._build_msg(bytes(data), is_broadcast=False)

    def build_telemetry_request(
        self, data_code: int = 0xFF, **kwargs: Any
    ) -> ProtocolBuildResult:
        code = int(data_code) & 0xFF
        data = bytes([_FRAME_TYPE_TM_REQ, code]) + bytes(6)
        return self._build_msg(data, is_broadcast=False)

    def build_telemetry_response(
        self,
        data: bytes,
        *,
        add_frame: bool = False,
        frame_type: int = 0xFF,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """遥测数据：激光（从节点）→ 星务；ID 节点地址为激光地址。

        ``add_frame=False`` 时载荷原样发送，``frame_type`` 不参与组包。
        ``add_frame=True`` 时才把 ``frame_type`` 写入 DataNum，帧为
        ``DataLen | 0x3A | frame_type | data | SUM``。``DataLen`` 计到 data 末尾，
        不含 SUM。SUM 是校验字节前全部字节的无符号累加和，取低 8 位。
        """
        del kwargs
        payload = bytes(data)
        if add_frame:
            payload = _wrap_tm_frame(payload, frame_type)
        return self._build_msg(payload, is_broadcast=False, is_from_slave=True)

    def build_refactor(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_system(
        self,
        cmd_type: Any = BiuSystemCmd.RESET,
        **kwargs: Any,
    ) -> ProtocolBuildResult | None:
        del kwargs
        try:
            cmd = int(cmd_type)
        except (TypeError, ValueError):
            return None
        if cmd != int(BiuSystemCmd.RESET):
            return None
        return self._build_msg(b"", is_broadcast=False, is_bus_data=True)


def _wrap_tm_frame(data: bytes, frame_type: int) -> bytes:
    """``DataLen BE | DataType 0x3A | DataNum | data | SUM``。"""
    body = bytes([0x3A, int(frame_type) & 0xFF]) + bytes(data)
    if len(body) > 0xFFFF:
        raise ValueError(f"telemetry frame body exceeds UINT16: {len(body)}")
    framed = len(body).to_bytes(2, "big") + body
    return framed + bytes([sum(framed) & 0xFF])
