"""NONE 协议定义。"""

from __future__ import annotations

__all__ = ["EPOCH_UTC"]

# 无项目协议：不定义星上纪元，纪元偏移为 0（Unix 秒本身）。
EPOCH_UTC = 0
