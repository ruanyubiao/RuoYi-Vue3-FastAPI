"""YJ216 协议定义（11 位 ID 位域与文档描述字）。"""

from __future__ import annotations

from enum import IntEnum

__all__ = [
    "EPOCH_UTC",
    "YJ216_APP_DATA_MAX",
    "Yj216CableFlag",
    "Yj216FrameFlag",
    "Yj216FrameType",
    "Yj216NodeAddr",
    "Yj216NodeType",
    "make_doc_word",
]

# UTC 2020-01-01 00:00:00。文档字段名是 GPS 周/周秒，纪元不是 GPS。
EPOCH_UTC = 1577836800

# 文档：应用数据原则上不超过 1024 字节。
YJ216_APP_DATA_MAX = 1024


class Yj216NodeType(IntEnum):
    """总线占用标志（ID10）。"""

    MASTER = 0
    SLAVE = 1


class Yj216NodeAddr(IntEnum):
    """节点地址（ID9~ID6，4 位）。"""

    MASTER = 0x0
    LCD_PAYLOAD = 0xD  # 1101，液晶载荷（文档表 5 标为预留，§6 实际使用）


class Yj216FrameType(IntEnum):
    """帧类型（ID5~ID3）。

    ID5：1 数据 / 0 命令。ID4：1 点对点 / 0 广播。ID3：1 通用帧。
    本协议不使用远程帧，ID3 固定为 1。
    """

    COMMAND_P2P = 0b011  # 遥控、遥测请求
    DATA_BROADCAST = 0b101  # 时间广播、数据广播
    DATA_P2P = 0b111  # 从节点遥测返回


class Yj216CableFlag(IntEnum):
    """AB 总线标志（ID2）。"""

    A = 0
    B = 1


class Yj216FrameFlag(IntEnum):
    """单复帧信息（ID1~ID0）。"""

    SINGLE = 0x0
    FIRST = 0x1
    MIDDLE = 0x2
    LAST = 0x3


def make_doc_word(un_id: int, dlc: int) -> int:
    """文档 3 字节描述字：控制字节在前，11 位 ID 左对齐进 16 位。

    ``doc_word = (dlc << 16) | (un_id << 5)``。
    例：B 总线、DLC=4、``un_id=0x35C`` → ``0x046B80``。
    运行时 CAN ID 仍是 11 位 ``un_id``，DLC 在帧长字段里。
    """
    return ((int(dlc) & 0xF) << 16) | ((int(un_id) & 0x7FF) << 5)
