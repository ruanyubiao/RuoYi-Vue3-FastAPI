"""XL 传输分片：多帧时每帧 1 字节控制 + 最多 7 字节载荷。

线格式（每 CAN 帧数据域，多帧）::

    [ctrl:1][payload:0~7]

控制字::

    b7~b6 帧序号标识（:class:`~gpcan.protocol.xl.defs.XlFrameIndex`）
    b5~b0 帧计数（0~0x3F 循环）

首帧示例：``01 000000`` → ``0x40``。

空用户数据时整包恰好 8 字节：按单帧直接发送整包，不加传输控制字
（见 :meth:`ProtocolBuilder._packet_result` / parser 的 SINGLE 分支）。
"""

from __future__ import annotations

from ..can_protocol_base import Segmenter
from .defs import XlFrameIndex, make_xl_frame_ctrl, parse_xl_frame_ctrl

__all__ = ["XlSegmenter"]

_MAX_PAYLOAD = 7
_COUNT_MASK = 0x3F


class XlSegmenter(Segmenter):
    def __init__(self, max_payload: int = _MAX_PAYLOAD) -> None:
        if max_payload < 1 or max_payload > 7:
            raise ValueError("max_payload must be in 1..7")
        self._max_payload = max_payload
        self._active = False
        self._last_count: int = 0
        self._parts: list[bytes] = []
        self._ready: list[bytes] = []

    def split(self, logical: bytes) -> list[bytes]:
        data = bytes(logical)
        if not data:
            # 无载荷：起始空帧 + 结束空帧，保证收端能成对闭合
            return [
                bytes([make_xl_frame_ctrl(XlFrameIndex.FIRST, 0)]),
                bytes([make_xl_frame_ctrl(XlFrameIndex.LAST, 1)]),
            ]

        n = (len(data) + self._max_payload - 1) // self._max_payload
        out: list[bytes] = []
        offset = 0
        for i in range(n):
            chunk = data[offset : offset + self._max_payload]
            offset += len(chunk)
            if n == 1:
                # 唯一分片用结束标识，收端见到 LAST 即可闭合
                index = int(XlFrameIndex.LAST)
            elif i == 0:
                index = int(XlFrameIndex.FIRST)
            elif i == n - 1:
                index = int(XlFrameIndex.LAST)
            else:
                index = int(XlFrameIndex.MIDDLE)
            ctrl = make_xl_frame_ctrl(index, i & _COUNT_MASK)
            out.append(bytes([ctrl]) + chunk)
        return out

    def feed(self, data: bytes) -> bool:
        """喂入一个介质单元；内部因坏控制字而 ``reset`` 时返回 ``True``。"""
        if not data:
            return False
        index, count = parse_xl_frame_ctrl(data[0])
        payload = data[1:]

        if index == int(XlFrameIndex.FIRST):
            self._active = True
            self._last_count = count
            self._parts = [payload]
            return False

        if index == int(XlFrameIndex.MIDDLE):
            if not self._active:
                self.reset()
                return True
            expect = (self._last_count + 1) & _COUNT_MASK
            if count != expect:
                self.reset()
                return True
            self._last_count = count
            self._parts.append(payload)
            return False

        if index == int(XlFrameIndex.LAST):
            if not self._active:
                # 单片多帧（仅结束标识）或孤立结束帧：整段即本片载荷
                self._ready.append(payload)
                self._active = False
                self._parts = []
                return False
            expect = (self._last_count + 1) & _COUNT_MASK
            if count != expect:
                self.reset()
                return True
            self._parts.append(payload)
            self._ready.append(b"".join(self._parts))
            self._active = False
            self._parts = []
            self._last_count = 0
            return False

        self.reset()
        return True

    def drain(self) -> list[bytes]:
        out = self._ready
        self._ready = []
        return out

    def reset(self) -> None:
        self._active = False
        self._last_count = 0
        self._parts.clear()
        self._ready.clear()
