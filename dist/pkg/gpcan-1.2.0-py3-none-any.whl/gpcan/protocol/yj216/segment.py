"""YJ216 传输分片：直接按 8 字节拆分；重组依赖 CAN ID 帧标志。

应用层长度（如遥测 ``DataLen``）已在载荷内，传输层不再额外加长度前缀。
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import Segmenter
from .defs import YJ216_APP_DATA_MAX, Yj216FrameFlag

__all__ = ["Yj216Assembled", "Yj216Segmenter"]

_FRAME_DATA_LEN = 8


@dataclass
class Yj216Assembled:
    """分片重组结果。``data`` 是各帧数据域按序拼接。"""

    data: bytes
    src: list[CanRecvObj] = field(default_factory=list)
    un_id: int = 0
    n_frame_flag: int = 0


def _frame_flag(obj: CanRecvObj) -> int:
    return int(obj.un_id) & 0x3


def _base_id(un_id: int) -> int:
    return int(un_id) & ~0x3


class Yj216Segmenter(Segmenter):
    """TX 纯 8 字节切分；RX 按 ID 低 2 位重组。"""

    def __init__(self) -> None:
        self._src: list[CanRecvObj] = []
        self._ready: list[Yj216Assembled] = []
        self._byte_ready: list[bytes] = []

    def split(self, logical: bytes) -> list[bytes]:
        """应用数据 → 各帧数据域。≤8 单帧；更长则按 8 字节切，不加长度前缀。"""
        data = bytes(logical)
        if len(data) > YJ216_APP_DATA_MAX:
            raise ValueError(
                f"application data exceeds {YJ216_APP_DATA_MAX} bytes: {len(data)}"
            )
        if not data:
            return [b""]
        size = _FRAME_DATA_LEN
        return [data[i : i + size] for i in range(0, len(data), size)]

    def feed(self, data: bytes) -> None:
        """无帧标志的字节按一条完整应用数据处理。"""
        self._byte_ready.append(bytes(data))

    def feed_frame(self, obj: CanRecvObj) -> None:
        completed = self._feed_one(obj)
        if completed is not None:
            self._ready.append(completed)

    def feed_many(self, items: Sequence[Any]) -> None:
        for item in items:
            if isinstance(item, CanRecvObj):
                self.feed_frame(item)
            elif isinstance(item, (bytes, bytearray, memoryview)):
                self.feed(bytes(item))
            else:
                raise TypeError(
                    f"Yj216Segmenter.feed_many expects CanRecvObj or bytes, got {type(item)!r}"
                )

    def drain(self) -> list[bytes]:
        out = self._byte_ready
        self._byte_ready = []
        return out

    def drain_assembled(self) -> list[Yj216Assembled]:
        out = self._ready
        self._ready = []
        return out

    def assemble(self, recv_list: list[CanRecvObj]) -> list[Yj216Assembled]:
        for obj in recv_list:
            self.feed_frame(obj)
        return self.drain_assembled()

    def reset(self) -> None:
        self._src = []
        self._ready.clear()
        self._byte_ready.clear()

    def _make_result(self, src: list[CanRecvObj]) -> Yj216Assembled:
        first = src[0]
        data = b"".join(f.str_data or b"" for f in src)
        return Yj216Assembled(
            data=data,
            src=list(src),
            un_id=_base_id(first.un_id) | int(Yj216FrameFlag.SINGLE),
            n_frame_flag=int(Yj216FrameFlag.SINGLE),
        )

    def _feed_one(self, obj: CanRecvObj) -> Yj216Assembled | None:
        flag = _frame_flag(obj)
        first = int(Yj216FrameFlag.FIRST)
        middle = int(Yj216FrameFlag.MIDDLE)
        last = int(Yj216FrameFlag.LAST)
        single = int(Yj216FrameFlag.SINGLE)

        if flag == single:
            self._src = []
            return self._make_result([obj])

        if flag == first:
            self._src = [obj]
            return None

        if flag == middle:
            if (
                self._src
                and _frame_flag(self._src[-1]) in (first, middle)
                and _base_id(obj.un_id) == _base_id(self._src[0].un_id)
            ):
                self._src.append(obj)
                return None
            self._src = []
            return None

        if flag == last:
            if (
                self._src
                and _frame_flag(self._src[-1]) in (first, middle)
                and _base_id(obj.un_id) == _base_id(self._src[0].un_id)
            ):
                self._src.append(obj)
                merged = self._make_result(self._src)
                self._src = []
                return merged
            self._src = []
            return None

        self._src = []
        return None
