"""XL 协议离线生成。"""

from __future__ import annotations

from typing import Any

from ...sdk.can_sdk_def import CanSendObj
from ..can_protocol_def import CanCableParam, CanProtocolType, CanSendParam
from ..can_protocol_base import ProtocolBuilderBase, ProtocolBuildResult, make_send_obj
from ..time_sync import TimeSyncManager
from .checksum import sum8
from .defs import (
    EPOCH_UTC,
    SystemSecHead,
    XlAddr,
    XlBroadcastKind,
    XlNId,
    XlPacketApidTid,
    XlPacketSeqFlag,
    XlPacketType,
    XlPri,
    XlTcSecHeader,
    XlTmSecHeader,
    XlTypeDir,
    XlTypeFormat,
    XlTypeKind,
    addr_for_nid,
    compose_xl_type,
)
from .id_codec import build_apid, generate_can_id, parse_apid
from .packet import XlPacketEncoder, XlPacketParam
from .segment import XlSegmenter

__all__ = ["ProtocolBuilder", "sum8"]

_TM_SEQ_FLAG = int(XlPacketSeqFlag.STANDALONE)
_LASER_NID = int(XlNId.LASER_COMM)
_SYSTEM_SEC = {int(x) for x in SystemSecHead}


def _corr_id(apid: int, sec_header: int) -> str:
    return f"{int(apid) & 0xFFFF:04x}:{int(sec_header) & 0xFF:02x}"


def _resolve_nid(nid: int | None = None) -> int:
    """默认激光 nID；显式传入则校验可映射到 ADDR。"""
    node_id = _LASER_NID if nid is None else int(nid) & 0xFF
    addr_for_nid(node_id)  # 未知站立即失败
    return node_id


_BROADCAST_MAP: dict[int, tuple[int, int]] = {
    int(XlBroadcastKind.ATTITUDE): (
        int(XlAddr.ATTITUDE_BROADCAST),
        int(XlNId.ATTITUDE),
    ),
    int(XlBroadcastKind.GNSS): (
        int(XlAddr.GNSS_BROADCAST),
        int(XlNId.GNSS),
    ),
}


class ProtocolBuilder(ProtocolBuilderBase):
    """XL 协议内容生成。

    点对点帧的 CAN ADDR 由设备 nID 经 ``addr_for_nid`` 查表得到（默认激光）。
    星时 ADDR、内务广播 nID=0xFF、姿控/GNSS 广播 kind 表另行处理。
    """

    PROTOCOL = CanProtocolType.XL

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        super().__init__(send_param, cable_param)
        self._segmenter = XlSegmenter()

    def _make_frames(self, can_id: int, chunks: list[bytes]) -> list[CanSendObj]:
        sp = self._send_param
        return [make_send_obj(sp, chunk, can_id) for chunk in chunks]

    def _packet_result(
        self,
        can_id: int,
        packet: bytes,
        packet_param: XlPacketParam | None = None,
        *,
        expect_ack: str = "none",
        corr_id: str | None = None,
    ) -> ProtocolBuildResult:
        # 空用户数据：主导头6 + 副导头1 + SUM1 = 8，单帧直发，不走传输分片格式
        if len(packet) <= 8:
            chunks = [bytes(packet)]
        else:
            chunks = self._segmenter.split(packet)
        return ProtocolBuildResult(
            data=packet,
            frames=self._make_frames(can_id, chunks),
            packet_param=packet_param,
            expect_ack=expect_ack,
            corr_id=corr_id,
        )

    @staticmethod
    def _packet_type_kind(packet: bytes) -> int:
        return (
            int(XlTypeKind.SINGLE_FRAME)
            if len(packet) <= 8
            else int(XlTypeKind.MULTI_FRAME)
        )

    def build_time_sync(
        self,
        sec: int,
        ms: int = 0,
        *,
        apply_offset: bool = True,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """星务时间广播（非包）。``apply_offset=False`` 时不叠加本协议 TimeSync 偏差。

        数据域 8 字节：``0x80 | onboard_sec BE | ms_word BE | sum8``。
        """
        offset_sec = offset_ms = 0
        if apply_offset:
            offset_sec, offset_ms = TimeSyncManager.find(self.PROTOCOL).get_offset_parts()
        onboard = int(sec) - EPOCH_UTC + int(offset_sec)
        if onboard < 0 or onboard > 0xFFFFFFFF:
            raise ValueError(f"onboard seconds out of range: {onboard}")
        ms_val = int(ms) + int(offset_ms)
        if ms_val < 0 or ms_val > 0x3FFF:
            raise ValueError(f"milliseconds out of range 0..0x3FFF: {ms_val}")

        gnss_valid = bool(kwargs.get("gnss_valid", True))
        invalid_bit = 0 if gnss_valid else 1
        ms_word = ((invalid_bit & 1) << 15) | (ms_val & 0x3FFF)
        # 8 字节：0x80 | onboard_sec BE | ms_word BE | sum8
        body = (
            bytes([0x80])
            + onboard.to_bytes(4, "big")
            + ms_word.to_bytes(2, "big")
        )
        data = body + bytes([sum8(body)])
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            int(XlAddr.TIME_SYNC_BROADCAST),
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.NON_PACKET),
                int(XlTypeKind.SINGLE_FRAME),
            ),
        )
        return ProtocolBuildResult(
            data=data,
            frames=self._make_frames(can_id, [data]),
            expect_ack="none",
        )

    def build_broadcast(
        self,
        data: bytes,
        kind: int = int(XlBroadcastKind.ATTITUDE),
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        key = int(kind)
        if key not in _BROADCAST_MAP:
            raise ValueError(f"unknown broadcast kind: {kind!r}")
        addr, nid = _BROADCAST_MAP[key]
        apid = build_apid(int(XlPacketApidTid.REALTIME), nid)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=int(XlTmSecHeader.POLL_CLASS_7_BROADCAST),
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        # 广播由姿控/GNSS 等设备发出（星务仅模拟），TYPE 方向为 NODE
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            addr,
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_telecommand(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        node_id = _resolve_nid(kwargs.get("nid"))
        apid = build_apid(int(XlPacketApidTid.REALTIME), node_id)
        sec = int(XlTcSecHeader.NODE_DATA)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELECOMMAND),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=sec,
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(
            can_id,
            packet,
            packet_param,
            expect_ack="always",
            corr_id=_corr_id(apid, sec),
        )

    def build_telemetry_request(
        self,
        sec_header: int = int(XlTmSecHeader.POLL_CLASS_1),
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        sh = int(sec_header) & 0xFF
        if sh not in (
            int(XlTmSecHeader.POLL_CLASS_1),
            int(XlTmSecHeader.POLL_CLASS_2),
        ):
            raise ValueError(
                f"sec_header must be 0x01(速变) or 0x02(缓变), got 0x{sh:02X}"
            )
        node_id = _resolve_nid(kwargs.get("nid"))
        apid = build_apid(int(XlPacketApidTid.REALTIME), node_id)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=_TM_SEQ_FLAG,
            seq_count=0,
            sec_header=sh,
        )
        packet = XlPacketEncoder(packet_param).wrap(b"")
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def build_telemetry_response(
        self,
        data: bytes,
        sec_header: int = int(XlTmSecHeader.POLL_CLASS_1),
        *,
        add_frame: bool = True,
        frame_type: int | None = None,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """遥测数据：下位机 → 星务；TYPE 方向为 NODE。

        ``add_frame=True``（默认）按包格式封装。``frame_type`` 仅在此时生效，
        覆盖 ``sec_header`` 作为副导头。``add_frame=False`` 时忽略这两个参数，
        十六进制载荷直接作为非包数据发送。可选 ``nid``（默认激光）决定 ADDR。
        """
        node_id = _resolve_nid(kwargs.get("nid"))
        if not add_frame:
            return self._raw_telemetry(bytes(data), nid=node_id)
        if frame_type is not None:
            sec_header = frame_type
        sh = int(sec_header) & 0xFF
        apid = build_apid(int(XlPacketApidTid.REALTIME), node_id)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELEMETRY),
            apid=apid,
            seq_flag=_TM_SEQ_FLAG,
            seq_count=0,
            sec_header=sh,
        )
        packet = XlPacketEncoder(packet_param).wrap(bytes(data))
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(can_id, packet, packet_param)

    def _raw_telemetry(self, data: bytes, *, nid: int | None = None) -> ProtocolBuildResult:
        """不套遥测包，数据域就是调用方给出的字节。"""
        node_id = _resolve_nid(nid)
        kind = (
            int(XlTypeKind.SINGLE_FRAME)
            if len(data) <= 8
            else int(XlTypeKind.MULTI_FRAME)
        )
        can_id = generate_can_id(
            int(XlPri.POLL_BROADCAST),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.NON_PACKET),
                kind,
            ),
        )
        chunks = [data] if len(data) <= 8 else self._segmenter.split(data)
        return ProtocolBuildResult(
            data=data,
            frames=self._make_frames(can_id, chunks),
        )

    def build_refactor(self, *args: Any, **kwargs: Any) -> None:
        return None

    def build_system(
        self,
        cmd_type: Any,
        *,
        broadcast: bool = False,
        **kwargs: Any,
    ) -> ProtocolBuildResult | None:
        try:
            sec = int(cmd_type) & 0xFF
        except (TypeError, ValueError):
            return None
        if sec not in _SYSTEM_SEC:
            return None

        if broadcast:
            # 广播目的 nID=0xFF，不在设备映射表；ADDR 仍用目标站（默认激光）占位
            node_id = _resolve_nid(kwargs.get("nid"))
            apid_nid = 0xFF
            addr = addr_for_nid(node_id)
        else:
            node_id = _resolve_nid(kwargs.get("nid"))
            apid_nid = node_id
            addr = addr_for_nid(node_id)
        apid = build_apid(int(XlPacketApidTid.REALTIME), apid_nid)
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELECOMMAND),
            apid=apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=sec,
        )
        packet = XlPacketEncoder(packet_param).wrap(b"")
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            addr,
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.PACKET),
                self._packet_type_kind(packet),
            ),
        )
        return self._packet_result(
            can_id,
            packet,
            packet_param,
            expect_ack="none" if broadcast else "always",
            corr_id=None if broadcast else _corr_id(apid, sec),
        )

    def build_indirect(
        self,
        w1: int,
        w2: int,
        w3: int,
        *,
        nid: int | None = None,
    ) -> ProtocolBuildResult:
        """表 9-9 间接指令（主节点 → 下位机，非包 6 字节）。

        数据场：``20H | nID | W1 | W2 | W3 | SUM``。ADDR 由 nID 映射。
        """
        node_id = _resolve_nid(nid)
        body = bytes(
            [
                0x20,
                node_id,
                int(w1) & 0xFF,
                int(w2) & 0xFF,
                int(w3) & 0xFF,
            ]
        )
        data = body + bytes([sum8(body)])
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.MASTER),
                int(XlTypeFormat.NON_PACKET),
                int(XlTypeKind.SINGLE_FRAME),
            ),
        )
        return ProtocolBuildResult(
            data=data,
            frames=self._make_frames(can_id, [data]),
            expect_ack="always",
            corr_id=f"ind:{node_id:02x}",
        )

    def build_ack(self, kind: str, **kwargs: Any) -> ProtocolBuildResult | None:
        """应答控制序列。

        - ``telecommand``：表 9-12 包格式（``apid`` / ``sec_header``）；ADDR 由 APID 内 nID 映射
        - ``system``：表 9-12，副导头为 ``SystemSecHead``（``cmd_type``，可选 ``nid``）
        - ``indirect``：表 9-10 非包 4 字节（``nid``）
        """
        key = str(kind).strip().lower()
        if key == "telecommand":
            return self._ack_telecommand_packet(
                apid=kwargs.get("apid"),
                sec_header=int(kwargs.get("sec_header", 0x01)),
            )
        if key == "system":
            return self._ack_system_packet(
                kwargs.get("cmd_type"),
                nid=kwargs.get("nid"),
            )
        if key == "indirect":
            return self._ack_indirect(nid=kwargs.get("nid"))
        return None

    def _ack_telecommand_packet(
        self,
        *,
        apid: int | None,
        sec_header: int,
    ) -> ProtocolBuildResult:
        """表 9-12 遥控包格式应答（从节点 → 主节点）。"""
        if apid is not None:
            resolved_apid = int(apid) & 0x7FF
            _tid, node_id = parse_apid(resolved_apid)
            node_id = _resolve_nid(node_id)
        else:
            node_id = _resolve_nid(None)
            resolved_apid = build_apid(int(XlPacketApidTid.REALTIME), node_id)
        sec = int(sec_header) & 0xFF
        packet_param = XlPacketParam(
            packet_type=int(XlPacketType.TELECOMMAND),
            apid=resolved_apid,
            seq_flag=int(XlPacketSeqFlag.STANDALONE),
            seq_count=0,
            sec_header=sec,
        )
        packet = XlPacketEncoder(packet_param).wrap(b"")
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.PACKET),
                int(XlTypeKind.SINGLE_FRAME),
            ),
        )
        return self._packet_result(
            can_id,
            packet,
            packet_param,
            expect_ack="none",
            corr_id=_corr_id(resolved_apid, sec),
        )

    def _ack_system_packet(
        self, cmd_type: Any, *, nid: int | None = None
    ) -> ProtocolBuildResult | None:
        try:
            sec = int(cmd_type) & 0xFF
        except (TypeError, ValueError):
            return None
        if sec not in _SYSTEM_SEC:
            return None
        node_id = _resolve_nid(nid)
        return self._ack_telecommand_packet(
            apid=build_apid(int(XlPacketApidTid.REALTIME), node_id),
            sec_header=sec,
        )

    def _ack_indirect(self, *, nid: int | None) -> ProtocolBuildResult:
        """表 9-10 间接指令应答：``nID | FFH | 20H | SUM``。"""
        node_id = _resolve_nid(nid)
        body = bytes([node_id, 0xFF, 0x20])
        data = body + bytes([sum8(body)])
        can_id = generate_can_id(
            int(XlPri.SELECT_PROCESS),
            addr_for_nid(node_id),
            compose_xl_type(
                int(XlTypeDir.NODE),
                int(XlTypeFormat.NON_PACKET),
                int(XlTypeKind.SINGLE_FRAME),
            ),
        )
        return ProtocolBuildResult(
            data=data,
            frames=self._make_frames(can_id, [data]),
            expect_ack="none",
            corr_id=f"ind:{node_id:02x}",
        )
