"""XL 协议解析：按 CAN ID 的 XlTypeFormat 决定是否解包。"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from ...sdk.can_sdk_def import CanRecvObj
from ..can_protocol_base import ProtocolParseResult, ProtocolParserBase
from ..can_protocol_def import CanProtocolType
from .defs import (
    SystemSecHead,
    XlAddr,
    XlPacketType,
    XlPri,
    XlTypeDir,
    XlTypeFormat,
    XlTypeKind,
    parse_xl_type,
)
from .id_codec import parse_can_id
from .packet import XlPacketDecoder
from .segment import XlSegmenter

__all__ = ["ProtocolParser"]

_SYSTEM_SEC = {int(x) for x in SystemSecHead}


def _classify_msg_kind(
    *,
    is_packet: bool,
    pri: int,
    addr: int,
    direction: int,
    packet_type: int | None,
    sec_header: int | None,
    payload: bytes,
    data: bytes,
) -> tuple[str, str | None]:
    """返回 ``(msg_kind, ack_status)``；非应答时 ``ack_status`` 为 ``None``。"""
    if not is_packet:
        # 表 9-10：间接指令应答 nID|FF|20|SUM
        if (
            direction == int(XlTypeDir.NODE)
            and pri == int(XlPri.SELECT_PROCESS)
            and len(data) == 4
            and data[1:3] == b"\xff\x20"
        ):
            return "indirect_ack", "ok"
        # 表 9-9：间接指令 20|nID|W1|W2|W3|SUM
        if (
            direction == int(XlTypeDir.MASTER)
            and pri == int(XlPri.SELECT_PROCESS)
            and len(data) == 6
            and data[0] == 0x20
        ):
            return "indirect", None
        if addr == int(XlAddr.TIME_SYNC_BROADCAST) or (data and data[0] == 0x80):
            return "time_sync", None
        return "broadcast", None

    assert packet_type is not None and sec_header is not None
    pkt_len = int.from_bytes(data[4:6], "big") if len(data) >= 6 else -1
    empty_user = len(payload) == 0 and pkt_len == 1

    if (
        direction == int(XlTypeDir.NODE)
        and pri == int(XlPri.SELECT_PROCESS)
        and packet_type == int(XlPacketType.TELECOMMAND)
        and empty_user
    ):
        if sec_header in _SYSTEM_SEC:
            return "system_ack", "ok"
        return "telecommand_ack", "ok"

    if packet_type == int(XlPacketType.TELEMETRY):
        if direction == int(XlTypeDir.MASTER):
            return "telemetry_request", None
        return "telemetry_response", None

    if packet_type == int(XlPacketType.TELECOMMAND):
        if direction == int(XlTypeDir.MASTER):
            if sec_header in _SYSTEM_SEC:
                return "system", None
            return "telecommand", None
        return "other", None

    return "other", None


class ProtocolParser(ProtocolParserBase):
    """XL 接收解析。

    - ``XlTypeFormat.PACKET``：分片重组后解包
    - ``XlTypeFormat.NON_PACKET``：不解包，整段为 payload
    """

    PROTOCOL = CanProtocolType.XL

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        super().__init__(params)
        self._segmenter = XlSegmenter()
        self._packet_dec = XlPacketDecoder()
        self._pending: list[CanRecvObj] = []
        self._pending_is_packet: bool | None = None
        self._pending_meta: tuple[int, int, int] | None = None

    def _finish(
        self,
        *,
        src: list[CanRecvObj],
        data: bytes,
        payload: bytes,
        packet_param: dict[str, Any],
        pri: int,
        addr: int,
        type_: int,
        is_packet: bool,
    ) -> None:
        direction, _format, _kind = parse_xl_type(type_)
        packet_param.update({"pri": pri, "addr": addr, "type": type_})
        kind, ack_status = _classify_msg_kind(
            is_packet=is_packet,
            pri=pri,
            addr=addr,
            direction=direction,
            packet_type=packet_param.get("packet_type"),
            sec_header=packet_param.get("sec_header"),
            payload=payload,
            data=data,
        )
        packet_param["msg_kind"] = kind
        if ack_status is not None:
            packet_param["ack_status"] = ack_status
        self._ready.append(
            ProtocolParseResult(
                src=src,
                data=data,
                payload=payload,
                packet_param=packet_param,
            )
        )

    def feed(self, frames: list[CanRecvObj]) -> None:
        if not frames:
            return
        for frame in frames:
            _pri, _addr, type_ = parse_can_id(frame.un_id)
            _dir, format_, kind = parse_xl_type(type_)
            is_packet = format_ == int(XlTypeFormat.PACKET)

            # 单帧：数据域即完整逻辑数据，不走传输分片格式
            if kind == int(XlTypeKind.SINGLE_FRAME):
                data = bytes(frame.str_data or b"")
                if is_packet:
                    try:
                        payload = self._packet_dec.unwrap(data)
                    except ValueError:
                        continue
                    packet_param: dict[str, Any] = {"packet": True}
                    if self._packet_dec.last_param is not None:
                        packet_param.update(asdict(self._packet_dec.last_param))
                else:
                    payload = data
                    packet_param = {"packet": False}
                self._finish(
                    src=[frame],
                    data=data,
                    payload=payload,
                    packet_param=packet_param,
                    pri=_pri,
                    addr=_addr,
                    type_=type_,
                    is_packet=is_packet,
                )
                continue

            if self._pending_is_packet is None:
                self._pending_is_packet = is_packet
                self._pending_meta = (_pri, _addr, type_)
            self._pending.append(frame)
            if self._segmenter.feed(frame.str_data or b""):
                # 坏控制字导致 segmenter 内部 reset：丢弃半包并清掉已缓存的陈旧帧
                self._pending = []
                self._pending_is_packet = None
                self._pending_meta = None
                continue
            for logical in self._segmenter.drain():
                packet_mode = bool(self._pending_is_packet)
                meta = self._pending_meta or (_pri, _addr, type_)
                if packet_mode:
                    try:
                        payload = self._packet_dec.unwrap(logical)
                    except ValueError:
                        self._pending = []
                        self._pending_is_packet = None
                        self._pending_meta = None
                        continue
                    packet_param = {"packet": True}
                    if self._packet_dec.last_param is not None:
                        packet_param.update(asdict(self._packet_dec.last_param))
                else:
                    payload = logical
                    packet_param = {"packet": False}
                self._finish(
                    src=list(self._pending),
                    data=logical,
                    payload=payload,
                    packet_param=packet_param,
                    pri=meta[0],
                    addr=meta[1],
                    type_=meta[2],
                    is_packet=packet_mode,
                )
                self._pending = []
                self._pending_is_packet = None
                self._pending_meta = None

    def reset(self) -> None:
        self._segmenter.reset()
        self._pending = []
        self._pending_is_packet = None
        self._pending_meta = None
        super().reset()
