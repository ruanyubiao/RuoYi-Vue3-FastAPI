"""YJ216 协议离线生成。"""

from __future__ import annotations

from typing import Any

from ..can_protocol_base import ProtocolBuilderBase, ProtocolBuildResult
from ..can_protocol_def import CanCableParam, CanProtocolType, CanSendParam
from ..time_sync import TimeSyncManager
from .defs import EPOCH_UTC, Yj216FrameType, Yj216NodeAddr
from .packet import Yj216PacketReq

__all__ = ["ProtocolBuilder", "unix_to_week_sow"]

_SECONDS_PER_WEEK = 604800
_NODE_ADDR = int(Yj216NodeAddr.LCD_PAYLOAD)
_WEEK_MAX = 0xFFFF


class ProtocolBuilder(ProtocolBuilderBase):
    """YJ216 主节点组帧。目标地址默认液晶载荷 ``0xD``，线路由 ``cable_param`` 指定。"""

    PROTOCOL = CanProtocolType.YJ216

    def __init__(
        self,
        send_param: CanSendParam | None = None,
        cable_param: CanCableParam | None = None,
    ) -> None:
        cp = cable_param or CanCableParam(n_node_addr_to=_NODE_ADDR, n_cable_flag=0)
        super().__init__(send_param, _normalize_cable(cp))

    def set_cable_param(self, cable_param: CanCableParam) -> None:
        self._cable_param = _normalize_cable(cable_param or CanCableParam())

    def _build_msg(
        self,
        data: bytes,
        *,
        frame_type: int,
        broadcast: bool = False,
        from_slave: bool = False,
    ) -> ProtocolBuildResult:
        req = Yj216PacketReq(
            data,
            frame_type=frame_type,
            broadcast=broadcast,
            from_slave=from_slave,
            send_param=self._send_param,
            cable_param=self._cable_param,
        )
        return ProtocolBuildResult(data=bytes(data), frames=req.build())

    def build_time_sync(
        self,
        sec: int,
        ms: int = 0,
        *,
        apply_offset: bool = True,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """时间广播：UINT16 周 + UINT32 周秒，大端，DLC=6。

        ``sec``/``ms`` 为 Unix UTC。``apply_offset=True`` 时先叠加本协议
        :class:`~gpcan.protocol.time_sync.TimeSyncManager` 的偏差。
        毫秒满 1000 进位到秒，余数丢弃。纪元为 2020-01-01 00:00:00 UTC，不加闰秒。
        接收方还原：``unix = week * 604800 + sow + EPOCH_UTC``。
        """
        del kwargs
        offset_sec = offset_ms = 0
        if apply_offset:
            offset_sec, offset_ms = TimeSyncManager.find(self.PROTOCOL).get_offset_parts()
        week, sow = unix_to_week_sow(
            int(sec) + int(offset_sec),
            int(ms) + int(offset_ms),
        )
        data = week.to_bytes(2, "big") + sow.to_bytes(4, "big")
        return self._build_msg(
            data,
            frame_type=int(Yj216FrameType.DATA_BROADCAST),
            broadcast=True,
        )

    def build_broadcast(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        del kwargs
        return self._build_msg(
            bytes(data),
            frame_type=int(Yj216FrameType.DATA_BROADCAST),
            broadcast=True,
        )

    def build_telecommand(self, data: bytes, **kwargs: Any) -> ProtocolBuildResult:
        del kwargs
        return self._build_msg(
            bytes(data),
            frame_type=int(Yj216FrameType.COMMAND_P2P),
        )

    def build_telemetry_request(
        self, data_code: int = 0xFF, **kwargs: Any
    ) -> ProtocolBuildResult:
        """遥测请求。默认 ``00 FF 00 00 00 00 00 00``（液晶载荷实时包）。"""
        del kwargs
        code = int(data_code) & 0xFF
        data = bytes([0x00, code]) + bytes(6)
        return self._build_msg(data, frame_type=int(Yj216FrameType.COMMAND_P2P))

    def build_telemetry_response(
        self,
        data: bytes,
        *,
        add_frame: bool = False,
        frame_type: int = 0xFF,
        **kwargs: Any,
    ) -> ProtocolBuildResult:
        """从节点遥测返回。

        ``add_frame=False`` 时载荷原样发送，``frame_type`` 不参与组包；
        CAN ID 帧类型固定为数据点对点。``add_frame=True`` 时才把 ``frame_type``
        写入 DataNum，帧为 ``DataLen | 0x3A | frame_type | data | SUM``。
        ``DataLen`` 从 DataType 计到 data 末尾，不含 SUM。SUM 是校验字节前
        全部字节的无符号累加和，取低 8 位。
        """
        del kwargs
        payload = bytes(data)
        if add_frame:
            payload = _wrap_tm_frame(payload, frame_type)
        return self._build_msg(
            payload,
            frame_type=int(Yj216FrameType.DATA_P2P),
            from_slave=True,
        )

    def build_refactor(self, *args: Any, **kwargs: Any) -> None:
        del args, kwargs
        return None

    def build_system(self, cmd_type: Any = None, **kwargs: Any) -> None:
        del cmd_type, kwargs
        return None

    def build_ack(self, kind: str, **kwargs: Any) -> ProtocolBuildResult | None:
        del kind, kwargs
        return None


def unix_to_week_sow(sec: int, ms: int = 0) -> tuple[int, int]:
    """Unix 秒 + 毫秒 → ``(week, sow)``。毫秒进位后余数丢弃。负偏差按 floor。"""
    unix_sec = (int(sec) * 1000 + int(ms)) // 1000
    total = unix_sec - EPOCH_UTC
    if total < 0:
        raise ValueError(f"time before 2020-01-01 UTC: total={total}")
    week, sow = divmod(total, _SECONDS_PER_WEEK)
    if week > _WEEK_MAX:
        raise ValueError(f"week out of UINT16: {week}")
    return int(week), int(sow)


def _wrap_tm_frame(data: bytes, frame_type: int) -> bytes:
    """``DataLen BE | DataType 0x3A | DataNum | data | SUM``。"""
    body = bytes([0x3A, int(frame_type) & 0xFF]) + bytes(data)
    if len(body) > 0xFFFF:
        raise ValueError(f"telemetry frame body exceeds UINT16: {len(body)}")
    framed = len(body).to_bytes(2, "big") + body
    return framed + bytes([sum(framed) & 0xFF])


def _normalize_cable(cable_param: CanCableParam) -> CanCableParam:
    if int(cable_param.n_node_addr_to) == 0:
        return CanCableParam(
            n_node_addr_to=_NODE_ADDR,
            n_cable_flag=cable_param.n_cable_flag,
        )
    return cable_param
