"""
Python port of cpp/hpp/bytebuffer.hpp

Stream-style binary buffer with sequential reading, configurable endianness,
direct byte-position access, and from_hex / to_hex helpers.

Default buffer byte order is big-endian (matches telemetry frame / parse API).
"""
from typing import Optional

from .number import Number


def _bytes_to_hex(data: "bytes | bytearray", separator: str, uppercase: bool) -> str:
    """Fast hex dump using the C-level bytes.hex (single-char separators)."""
    if not data:
        return ""
    if len(separator) == 1:
        h = data.hex(separator)
    elif separator == "":
        h = data.hex()
    else:
        h = separator.join(data.hex()[i:i + 2] for i in range(0, len(data) * 2, 2))
    return h.upper() if uppercase else h


def _normalize_hex_str(hex_str: str) -> str:
    """Strip whitespace / optional 0x; pad odd trailing nibble (e.g. '5' → '50')."""
    clean = "".join(hex_str.split())
    if clean[:2].lower() == "0x":
        clean = clean[2:]
    if len(clean) % 2 == 1:
        clean += "0"
    return clean


def decode_hex(hex_str: str) -> bytearray:
    """Decode a hex string (spaces / 0x / odd nibble ok) to ``bytearray``."""
    return bytearray.fromhex(_normalize_hex_str(hex_str))


class ByteBuffer:
    """
    Binary byte buffer with stream-style sequential reading and optional
    endian conversion between buffer byte order and system byte order.

    Storage is always a writable ``bytearray`` (input is copied).
    Default ``big_endian_buffer=True`` (network / telemetry frame order).
    """

    __slots__ = ("_storage", "_rpos", "_buf_big")

    def __init__(self, data: "bytes | bytearray | None" = None,
                 big_endian_buffer: bool = True):
        self._rpos: int = 0
        self._buf_big: bool = big_endian_buffer
        self._storage: bytearray = bytearray() if data is None else bytearray(data)

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_byte_order_buffer(self, big_endian: bool = True) -> None:
        self._buf_big = big_endian

    @property
    def is_big_endian(self) -> bool:
        return self._buf_big

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------

    def clear(self) -> None:
        self._rpos = 0
        self._storage.clear()

    def rpos(self, pos: Optional[int] = None) -> int:
        """Get or set the sequential read position."""
        if pos is None:
            return self._rpos
        self._rpos = pos
        return self._rpos

    def size(self) -> int:
        """Remaining bytes from current rpos."""
        return max(0, len(self._storage) - self._rpos)

    def total_size(self) -> int:
        return len(self._storage)

    def empty(self) -> bool:
        return self._rpos >= len(self._storage)

    # ------------------------------------------------------------------
    # Low-level access
    # ------------------------------------------------------------------

    def __getitem__(self, pos: int) -> int:
        """Read byte at pos relative to current rpos (no advance)."""
        return self._storage[self._rpos + pos]

    def raw_byte_at(self, absolute_pos: int) -> int:
        """Read byte at absolute position in the underlying storage."""
        return self._storage[absolute_pos]

    def raw_bytes_at(self, absolute_pos: int, length: int) -> bytes:
        """Read bytes at absolute position without modifying rpos."""
        return bytes(self._storage[absolute_pos: absolute_pos + length])

    def try_read(self, length: int, pos: int = 0) -> bool:
        """True if length bytes are available at rpos+pos."""
        return self._rpos + pos + length <= len(self._storage)

    def try_read_at(self, absolute_pos: int, length: int) -> bool:
        """True if length bytes are available from absolute position."""
        return absolute_pos + length <= len(self._storage)

    # ------------------------------------------------------------------
    # Peek (read without advancing rpos)
    # ------------------------------------------------------------------

    def peek_bytes(self, length: int, pos: int = 0) -> bytes:
        """Return raw bytes at rpos+pos without advancing."""
        start = self._rpos + pos
        return bytes(self._storage[start: start + length])

    def peek_number(self, num: Number, pos: int = 0) -> None:
        """Fill a Number from rpos+pos without advancing."""
        raw = self.peek_bytes(num.size, pos)
        num.set_from_bytes(raw, self._buf_big)

    # ------------------------------------------------------------------
    # Sequential read (advances rpos)
    # ------------------------------------------------------------------

    def read_skip(self, length: int) -> "ByteBuffer":
        self._rpos += length
        return self

    def read_bytes(self, length: int) -> bytes:
        data = self.peek_bytes(length, 0)
        self._rpos += length
        return data

    def read_uint8(self) -> int:
        v = self._storage[self._rpos]
        self._rpos += 1
        return v

    def read_number(self, num: Number) -> "ByteBuffer":
        """
        Read num.size bytes into num, applying endian conversion when needed.
        Advances rpos by num.size.
        """
        raw = self.peek_bytes(num.size, 0)
        num.set_from_bytes(raw, self._buf_big)
        self._rpos += num.size
        return self

    # ------------------------------------------------------------------
    # Append (write to buffer)
    # ------------------------------------------------------------------

    def append_bytes(self, data: "bytes | bytearray") -> "ByteBuffer":
        self._storage.extend(data)
        return self

    def append_number(self, num: Number) -> "ByteBuffer":
        """
        Append a Number's value as bytes in this buffer's endianness.

        Prefer packing from the current Number value (``to_bytes``), so
        ``value()`` + ``write()`` / ``append_number()`` works without a prior read.
        """
        self._storage.extend(num.to_bytes(big_endian_buffer=self._buf_big))
        return self

    def append_hex(self, hex_str: str) -> "ByteBuffer":
        """
        Parse a hex string (spaces, 0x prefix, newlines allowed) and
        append the decoded bytes to the buffer.
        """
        self._storage.extend(bytes.fromhex(_normalize_hex_str(hex_str)))
        return self

    # ------------------------------------------------------------------
    # Operator equivalents (<<  and  >>)
    # ------------------------------------------------------------------

    def write(self, num: Number) -> "ByteBuffer":
        """Equivalent to C++ buf << num."""
        return self.append_number(num)

    def read_into(self, num: Number) -> "ByteBuffer":
        """Equivalent to C++ buf >> num."""
        return self.read_number(num)

    # ------------------------------------------------------------------
    # Hex conversion helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_hex(cls, hex_str: str,
                 big_endian_buffer: bool = True) -> "ByteBuffer":
        """Decode hex into a ByteBuffer (spaces / newlines / optional ``0x`` ok)."""
        return cls(decode_hex(hex_str), big_endian_buffer=big_endian_buffer)

    def to_hex(self, separator: str = " ", uppercase: bool = True) -> str:
        return _bytes_to_hex(self._storage[self._rpos:], separator, uppercase)

    def raw_to_hex(self, absolute_pos: int, length: int,
                   separator: str = " ", uppercase: bool = True) -> str:
        """Hex string of bytes at absolute position."""
        return _bytes_to_hex(self.raw_bytes_at(absolute_pos, length),
                             separator, uppercase)

    # ------------------------------------------------------------------
    # Miscellaneous
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._storage)

    def __repr__(self) -> str:
        return (f"ByteBuffer(size={len(self._storage)}, rpos={self._rpos}, "
                f"big_endian={self._buf_big})")
