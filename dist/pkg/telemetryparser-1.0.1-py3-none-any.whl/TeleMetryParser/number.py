"""
Python port of cpp/hpp/number.hpp

Provides Number and NumberType classes for typed integer/float storage,
supporting 1–8 byte custom-width integers with sign extension,
mirroring the C++ NumberCustom<T,S> and Number class.
"""
import struct
from enum import Enum, auto


class NumberType(Enum):
    INT8   = auto()
    UINT8  = auto()
    INT16  = auto()
    UINT16 = auto()
    INT24  = auto()
    UINT24 = auto()
    INT32  = auto()
    UINT32 = auto()
    INT40  = auto()
    UINT40 = auto()
    INT48  = auto()
    UINT48 = auto()
    INT56  = auto()
    UINT56 = auto()
    INT64  = auto()
    UINT64 = auto()
    FLOAT  = auto()
    DOUBLE = auto()


# (byte_size, is_signed, is_float)
_TYPE_INFO: dict[NumberType, tuple[int, bool, bool]] = {
    NumberType.INT8:   (1, True,  False),
    NumberType.UINT8:  (1, False, False),
    NumberType.INT16:  (2, True,  False),
    NumberType.UINT16: (2, False, False),
    NumberType.INT24:  (3, True,  False),
    NumberType.UINT24: (3, False, False),
    NumberType.INT32:  (4, True,  False),
    NumberType.UINT32: (4, False, False),
    NumberType.INT40:  (5, True,  False),
    NumberType.UINT40: (5, False, False),
    NumberType.INT48:  (6, True,  False),
    NumberType.UINT48: (6, False, False),
    NumberType.INT56:  (7, True,  False),
    NumberType.UINT56: (7, False, False),
    NumberType.INT64:  (8, True,  False),
    NumberType.UINT64: (8, False, False),
    NumberType.FLOAT:  (4, True,  True),
    NumberType.DOUBLE: (8, True,  True),
}

_TYPE_NAME_MAP: dict[str, NumberType] = {
    "INT8":   NumberType.INT8,
    "UINT8":  NumberType.UINT8,
    "BYTE":   NumberType.UINT8,
    "INT16":  NumberType.INT16,
    "UINT16": NumberType.UINT16,
    "INT24":  NumberType.INT24,
    "UINT24": NumberType.UINT24,
    "INT32":  NumberType.INT32,
    "UINT32": NumberType.UINT32,
    "INT40":  NumberType.INT40,
    "UINT40": NumberType.UINT40,
    "INT48":  NumberType.INT48,
    "UINT48": NumberType.UINT48,
    "INT56":  NumberType.INT56,
    "UINT56": NumberType.UINT56,
    "INT64":  NumberType.INT64,
    "UINT64": NumberType.UINT64,
    "FLOAT":  NumberType.FLOAT,
    "float":  NumberType.FLOAT,
    "DOUBLE": NumberType.DOUBLE,
    "double": NumberType.DOUBLE,
}


def _sign_extend(value: int, n_bytes: int) -> int:
    """Sign-extend an unsigned integer value from n_bytes to Python int."""
    n_bits = n_bytes * 8
    if value >= (1 << (n_bits - 1)):
        value -= (1 << n_bits)
    return value


class Number:
    """
    Typed numeric value container, mirroring C++ Number class.

    Supports INT8..UINT64, FLOAT, DOUBLE with configurable byte-width.
    Internally stores the interpreted Python value; raw bytes from
    ``set_from_bytes`` are kept for hex display.
    """

    __slots__ = ("_py_value", "_raw_bytes", "_type", "_size",
                 "_is_signed", "_is_float_type")

    def __init__(self, type_or_str: "NumberType | str" = NumberType.INT64):
        self._py_value: int | float = 0
        self._raw_bytes: bytes = b""
        self._type = NumberType.INT64
        self._size = 8
        self._is_signed = True
        self._is_float_type = False
        self.set_type(type_or_str)

    # ------------------------------------------------------------------
    # Type management
    # ------------------------------------------------------------------

    def set_type(self, type_or_str: "NumberType | str") -> None:
        if isinstance(type_or_str, str):
            ntype = _TYPE_NAME_MAP.get(type_or_str, NumberType.INT64)
        elif isinstance(type_or_str, NumberType):
            ntype = type_or_str
        else:
            ntype = NumberType.INT64

        self._type = ntype
        info = _TYPE_INFO[ntype]
        self._size = info[0]
        self._is_signed = info[1]
        self._is_float_type = info[2]

    @property
    def type(self) -> NumberType:
        return self._type

    @property
    def size(self) -> int:
        return self._size

    # ------------------------------------------------------------------
    # Value access
    # ------------------------------------------------------------------

    def value(self, val: "int | float | None" = None) -> "int | float | None":
        """Get or set the Python value."""
        if val is None:
            return self._py_value
        self._py_value = val
        return None

    def set_from_bytes(self, raw: bytes, big_endian_buffer: bool = True) -> None:
        """
        Populate value from ``raw`` (slice of frame / buffer bytes).

        ``big_endian_buffer`` selects byte order (default True = big-endian,
        matching telemetry frames). Original ``raw`` is kept for hex display.
        """
        self._raw_bytes = raw
        byteorder = "big" if big_endian_buffer else "little"

        if self._is_float_type:
            fmt = (">" if big_endian_buffer else "<") + ("f" if self._size == 4 else "d")
            self._py_value = struct.unpack_from(fmt, raw)[0]
        else:
            v = int.from_bytes(raw, byteorder)
            if self._is_signed:
                v = _sign_extend(v, self._size)
            self._py_value = v

    def get_raw_bytes(self) -> bytes:
        """Return the raw bytes last set via set_from_bytes (buffer order)."""
        return self._raw_bytes

    def to_bytes(self, big_endian_buffer: bool = True) -> bytes:
        """
        Serialize the current value to ``size`` bytes.

        Packs little-endian then byte-swaps when ``big_endian_buffer`` is True
        (default True, matching telemetry / ByteBuffer defaults).
        """
        if self._is_float_type:
            if self._size == 4:
                data = struct.pack("<f", float(self._py_value))
            else:
                data = struct.pack("<d", float(self._py_value))
        else:
            n_bits = self._size * 8
            mask = (1 << n_bits) - 1
            v = int(self._py_value) & mask
            data = v.to_bytes(self._size, "little")

        if big_endian_buffer and len(data) > 1:
            data = data[::-1]
        return data

    # ------------------------------------------------------------------
    # Type checks
    # ------------------------------------------------------------------

    def is_float(self) -> bool:
        return self._type == NumberType.FLOAT

    def is_double(self) -> bool:
        return self._type == NumberType.DOUBLE

    def is_signed_integer(self) -> bool:
        return self._is_signed and not self._is_float_type

    def is_unsigned_integer(self) -> bool:
        return not self._is_signed and not self._is_float_type

    def is_integer(self) -> bool:
        return not self._is_float_type

    # ------------------------------------------------------------------
    # Conversion helpers
    # ------------------------------------------------------------------

    def to_int64(self) -> int:
        return int(self._py_value)

    def to_uint64(self) -> int:
        v = int(self._py_value)
        if v < 0:
            v += 1 << 64
        return v

    def to_double(self) -> float:
        return float(self._py_value)

    def to_string(self) -> str:
        if self._is_float_type:
            return str(self._py_value)
        return str(int(self._py_value))

    def to_hex(self, uppercase: bool = True, prefix: str = "") -> str:
        """
        Hex representation of the value, zero-padded to 2*size digits.
        Negative signed values are shown as two's complement (matching C++).
        """
        n_bits = self._size * 8
        mask = (1 << n_bits) - 1

        if self._is_float_type:
            if self._size == 4:
                raw = struct.pack("<f", float(self._py_value))
            else:
                raw = struct.pack("<d", float(self._py_value))
            v_int = int.from_bytes(raw, "little")
        else:
            v_int = int(self._py_value) & mask

        fmt = f"0{self._size * 2}{'X' if uppercase else 'x'}"
        return prefix + format(v_int, fmt)

    def __repr__(self) -> str:
        return f"Number({self._type.name}, {self._py_value})"
