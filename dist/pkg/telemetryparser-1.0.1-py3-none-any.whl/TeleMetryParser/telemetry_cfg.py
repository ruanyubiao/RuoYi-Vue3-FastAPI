"""
Compatibility facade for telemetry config / parse / manager.

Prefer importing from the dedicated modules (or the package root).
This module re-exports the historical public surface for deep imports:

  from TeleMetryParser.telemetry_cfg import TeleMetryCfgManager, ...

Split layout:

  - telemetry_types.py   – dataclasses
  - telemetry_parse.py   – row/frame parse helpers
  - telemetry_manager.py – TeleMetryCfgManager singleton
  - utils.py             – CSV helpers
"""
from __future__ import annotations

from .telemetry_manager import TeleMetryCfgManager
from .telemetry_parse import (
    parse_line,
    parse_line_hex,
    row_cfg_from_dict,
)
from .telemetry_types import (
    TeleMetryLine,
    TeleMetryPageCfg,
    TeleMetryTableCfg,
    TeleMetryTableRowCfg,
)

__all__ = [
    "TeleMetryLine",
    "TeleMetryTableRowCfg",
    "TeleMetryTableCfg",
    "TeleMetryPageCfg",
    "TeleMetryCfgManager",
    "row_cfg_from_dict",
    "parse_line",
    "parse_line_hex",
]
