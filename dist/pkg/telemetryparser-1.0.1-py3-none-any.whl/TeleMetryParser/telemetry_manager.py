"""
TeleMetryCfgManager – singleton that loads TeleMetryCfg.json and
parses binary telemetry frames.
"""
from __future__ import annotations

import json
import os
from typing import Optional

from .telemetry_parse import parse_frame, parse_frame_calc
from .telemetry_types import (
    TeleMetryPageCfg,
    TeleMetryTableCfg,
    TeleMetryTableRowCfg,
)


class TeleMetryCfgManager:
    """
    Loads a TeleMetryCfg.json once and provides parse helpers.

    Typical use::

        mgr = TeleMetryCfgManager.instance()
        mgr.init("path/to/TeleMetryCfg.json")
        data = bytes.fromhex("00BF...")  # or payload from MySQL BLOB
        # curves (~1000 fps)
        calc = mgr.parse_calc("FF", data, big_endian_buffer=True)
        # UI table (~2 fps, latest frame only)
        fields = mgr.parse("FF", data, big_endian_buffer=True)
    """

    _instance: Optional["TeleMetryCfgManager"] = None

    def __init__(self) -> None:
        self._datetime: str = ""
        self._table: dict[str, TeleMetryTableCfg] = {}
        self._page: list[TeleMetryPageCfg] = []
        self._sp_table: dict[int, TeleMetryTableCfg] = {}

    @classmethod
    def instance(cls) -> "TeleMetryCfgManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def init(self, file_path: str) -> bool:
        """Load and parse TeleMetryCfg.json. Returns True on success."""
        if not os.path.isfile(file_path):
            return False

        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        self._datetime = data.get("datetime", "")

        self._table = {}
        self._sp_table = {}
        for key, tbl in data.get("table", {}).items():
            rows = [
                TeleMetryTableRowCfg(
                    no=r.get("no", 0),
                    id=r.get("id", ""),
                    name=r.get("name", ""),
                    bytepos=r.get("bytepos", 0),
                    bits=r.get("bits", 8),
                    bitpos=r.get("bitpos", 0),
                    showType=r.get("showType", 0),
                    formula=r.get("formula", ""),
                    unit=r.get("unit", ""),
                    fmt=r.get("fmt", "%d"),
                    value={str(k2): str(v2) for k2, v2 in r.get("value", {}).items()},
                    dataType=r.get("dataType", "BYTE"),
                    variableName=r.get("variableName", ""),
                    tip=json.dumps(r, ensure_ascii=False, indent=2),
                )
                for r in tbl.get("row", [])
            ]
            cfg = TeleMetryTableCfg(id=tbl.get("id", key), name=tbl.get("name", ""), row=rows)
            self._table[key] = cfg
            try:
                int_key = int(key, 16)
                self._sp_table[int_key] = cfg
            except ValueError:
                pass

        raw_pages = data.get("page", [])
        if raw_pages:
            self._page = [
                TeleMetryPageCfg(id=p.get("id", 0), name=p.get("name", ""), key=p.get("key", ""))
                for p in raw_pages
            ]
        else:
            self._page = []
            for key, cfg in self._table.items():
                try:
                    int_id = int(key, 16)
                except ValueError:
                    int_id = 0
                display_name = f"0x{key}：{cfg.name}" if cfg.name else key
                self._page.append(TeleMetryPageCfg(id=int_id, name=display_name, key=key))

        return True

    # ------------------------------------------------------------------
    # Config access
    # ------------------------------------------------------------------

    def get_page_list(self) -> list[TeleMetryPageCfg]:
        return list(self._page)

    def get_table_list(self) -> list[TeleMetryTableCfg]:
        return list(self._table.values())

    def get_table_cfg_by_key(self, key: str) -> Optional[TeleMetryTableCfg]:
        """Look up table config by string key (e.g. 'FF')."""
        return self._table.get(key)

    def get_table_cfg(self, data_type: int) -> Optional[TeleMetryTableCfg]:
        """Look up table config by integer data-type id (e.g. 0xFF = 255)."""
        return self._sp_table.get(data_type)

    def _resolve_cfg(self, key_or_cfg: "str | TeleMetryTableCfg") -> Optional[TeleMetryTableCfg]:
        if isinstance(key_or_cfg, TeleMetryTableCfg):
            return key_or_cfg
        if isinstance(key_or_cfg, str):
            return self.get_table_cfg_by_key(key_or_cfg)
        raise TypeError(
            f"key_or_cfg must be str or TeleMetryTableCfg, got {type(key_or_cfg)!r}"
        )

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    def parse(self, key_or_cfg: "str | TeleMetryTableCfg",
              data: "bytes | bytearray",
              big_endian_buffer: bool = True) -> list[dict]:
        """
        Parse a full frame to field dicts with ``hex`` / ``show`` filled.

        ``key_or_cfg``: table key (e.g. ``\"FF\"``) or ``TeleMetryTableCfg``.
        ``data``: raw frame bytes (no copy; passed straight to the parser).
        Returns ``list[dict]`` keys: id, name, value, calc_val, show, hex, unit.
        Unknown key → ``[]``. Does not insert a DateTime row.
        """
        cfg = self._resolve_cfg(key_or_cfg)
        if cfg is None:
            return []
        lines = parse_frame(cfg, data, big_endian_buffer)
        return [ln.to_field_dict() for ln in lines]

    def parse_calc(self, key_or_cfg: "str | TeleMetryTableCfg",
                   data: "bytes | bytearray",
                   big_endian_buffer: bool = True) -> dict[str, int | float]:
        """
        Parse a full frame to ``dict[id, calc_val]`` (curves / high-rate path).

        Does not build hex/show strings. Unknown key → ``{}``.
        """
        cfg = self._resolve_cfg(key_or_cfg)
        if cfg is None:
            return {}
        return parse_frame_calc(cfg, data, big_endian_buffer)
