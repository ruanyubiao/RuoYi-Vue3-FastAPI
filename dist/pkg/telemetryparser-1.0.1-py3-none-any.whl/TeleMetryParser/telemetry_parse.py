"""
Single-field / frame-row parse helpers for TeleMetry.

Provides:
  - row_cfg_from_dict, parse_line, parse_line_hex (public)
  - per-row precompiled parse plan and frame-row helpers (internal)

Bit-field ordering follows the "terminal bit order" convention used in
the C++ source: bit position 0 is the MSB of the byte (big-endian bit
numbering), identical to the get_bit_value() logic in TeleMetryCfg.cpp.
"""
from __future__ import annotations

import datetime
import math
import threading

from .bytebuffer import decode_hex
from .number import Number
from .telemetry_types import TeleMetryLine, TeleMetryTableCfg, TeleMetryTableRowCfg
from .tinyexpr import exec_formula as _exec_formula

# Seconds since epoch for 2020-01-01 00:00:00 UTC (matches C++ UNIX_TIMESTAMP_2020_UTC_0)
_EPOCH_2020_UTC = 1_577_836_800


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _fmt_time(val: float) -> str:
    """
    Convert seconds-since-2020-01-01-UTC to a datetime string.
    The value passed here is *after* formula evaluation, so any timezone
    offset (e.g. D+8*3600 in the formula) is already included.
    We simply add the 2020-01-01 UTC epoch and format as-is.
    """
    sec = int(val) + _EPOCH_2020_UTC
    try:
        dt = datetime.datetime(1970, 1, 1) + datetime.timedelta(seconds=sec)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (OverflowError, OSError, ValueError):
        return f"{sec} s"


# ---------------------------------------------------------------------------
# Per-row precompiled parse plan (internal, transparent to public API)
# ---------------------------------------------------------------------------

# calc_val conversion category, derived once from fmt
_CALC_TIME, _CALC_FLOAT, _CALC_INT, _CALC_AUTO = 0, 1, 2, 3
# fmt kinds
_FMT_EMPTY, _FMT_TIME, _FMT_NORMAL = 0, 1, 2
# field kinds
_KIND_BIT, _KIND_INT, _KIND_OTHER = 0, 1, 2


class _RowPlan:
    """
    Precomputed per-row parse state. Rebuilt automatically when the
    row's parse-relevant fields change (sig check).
    """

    __slots__ = (
        "sig", "kind", "byte_count", "size_mismatch",
        "ntype", "nsize", "nsigned", "nfloat",
        "has_formula", "formula",
        "fmt_kind", "fmt_expanded",
        "calc_conv", "show_formula_only", "bit_fmt",
    )

    def __init__(self, row: TeleMetryTableRowCfg) -> None:
        fmt = row.fmt or ""
        self.sig = (row.dataType, row.formula, fmt, row.bits, row.showType)

        bits = row.bits
        if bits < 8:
            self.kind = _KIND_BIT
            type_str = "BYTE"
        elif bits <= 64:
            self.kind = _KIND_INT
            type_str = row.dataType
        else:
            self.kind = _KIND_OTHER
            type_str = "INT64"  # untouched default, mirrors old behaviour

        probe = Number(type_str)
        self.ntype = probe.type
        self.nsize = probe.size
        self.nsigned = probe.is_signed_integer() or probe.is_float() or probe.is_double()
        self.nfloat = probe.is_float() or probe.is_double()

        self.byte_count = bits // 8
        self.size_mismatch = (self.kind == _KIND_INT and self.nsize != self.byte_count)

        self.has_formula = bool(row.formula) and row.formula != "D"
        self.formula = row.formula

        if not fmt:
            self.fmt_kind = _FMT_EMPTY
            self.fmt_expanded = ""
        elif fmt == "%time":
            self.fmt_kind = _FMT_TIME
            self.fmt_expanded = fmt
        else:
            self.fmt_kind = _FMT_NORMAL
            # Bare %g/%G would round 111.4116 → 111.412 (6 sig. digits)
            self.fmt_expanded = {"%g": "%.15g", "%G": "%.15G"}.get(fmt, fmt)

        if fmt == "%time":
            self.calc_conv = _CALC_TIME
        elif fmt and fmt[-1] in "aAeEfFgG":
            self.calc_conv = _CALC_FLOAT
        elif fmt and fmt[-1] in "diouxX":
            self.calc_conv = _CALC_INT
        else:
            self.calc_conv = _CALC_AUTO

        self.show_formula_only = row.showType <= 0
        self.bit_fmt = f"0{bits}b" if self.kind == _KIND_BIT else ""


def _plan_of(row: TeleMetryTableRowCfg) -> _RowPlan:
    """Get (or lazily rebuild) the cached plan for a row config."""
    plan = getattr(row, "_plan", None)
    if plan is not None and plan.sig == (
        row.dataType, row.formula, row.fmt or "", row.bits, row.showType
    ):
        return plan
    plan = _RowPlan(row)
    row._plan = plan
    return plan


def _fmt_fast(plan: _RowPlan, val: "int | float") -> str:
    """Plan-accelerated `_fmt_value` (identical output)."""
    fk = plan.fmt_kind
    if fk == _FMT_NORMAL:
        if isinstance(val, float) and not math.isfinite(val):
            return str(val)
        try:
            return plan.fmt_expanded % val
        except TypeError:
            try:
                return plan.fmt_expanded % int(val)
            except Exception:
                return str(val)
        except Exception:
            return str(val)
    if fk == _FMT_TIME:
        return _fmt_time(val)
    # empty fmt
    if isinstance(val, float):
        if not math.isfinite(val):
            return str(val)
        return f"{val:.15g}"
    return str(int(val))


def _calc_from_formula(plan: _RowPlan, result: float) -> int | float:
    conv = plan.calc_conv
    if conv == _CALC_FLOAT:
        return float(result)
    if conv == _CALC_INT or conv == _CALC_TIME:
        return int(result)
    # auto: follow data type
    if plan.nfloat:
        return float(result)
    return int(result)


def _calc_from_raw(plan: _RowPlan, num: Number) -> int | float:
    """Exact-width calc_val without a formula (no float round-trip for ints)."""
    conv = plan.calc_conv
    if conv == _CALC_TIME:
        return int(num.to_double())
    if conv == _CALC_FLOAT:
        return float(num.to_double())
    if conv == _CALC_INT:
        return num.to_int64() if plan.nsigned else num.to_uint64()
    if plan.nfloat:
        return float(num.to_double())
    return num.to_int64() if plan.nsigned else num.to_uint64()


def _apply_calc_val(plan: _RowPlan, num: Number, out: TeleMetryLine) -> tuple[str, bool]:
    """
    Fill ``out.calc_val`` (and formula ``err``). Returns
    ``(str_fmt_formula, formula_had_err)``.
    """
    if plan.has_formula:
        result, had_err = _exec_formula(plan.formula, num.to_double())
        if had_err:
            out.err = True
            out.calc_val = _calc_from_raw(plan, num)
            return "", True
        out.calc_val = _calc_from_formula(plan, result)
        return _fmt_fast(plan, result), False
    out.calc_val = _calc_from_raw(plan, num)
    return "", False


def _format_show_text(
    plan: _RowPlan,
    row_cfg: TeleMetryTableRowCfg,
    num: Number,
    str_key: str,
    out: TeleMetryLine,
    str_fmt_formula: str,
    formula_had_err: bool,
) -> str:
    """
    Build show string (same semantics as former getLineValueShow tail):
      1. Value dictionary lookup
      2. Formula-only / formula+raw display
      3. Direct fmt of raw value
    """
    if formula_had_err:
        return "formula error"

    value_map = row_cfg.value
    if value_map:
        if str_key:
            found = value_map.get(str_key, "")
            if found:
                return found
        hex_key = num.to_hex(uppercase=True, prefix="0x")
        found = value_map.get(hex_key, "")
        if not found:
            out.err = True
            return "no matching value"
        return found

    if str_fmt_formula and plan.show_formula_only:
        return str_fmt_formula

    if plan.nfloat:
        str_ret = _fmt_fast(plan, num.to_double())
    elif plan.nsigned:
        str_ret = _fmt_fast(plan, num.to_int64())
    else:
        str_ret = _fmt_fast(plan, num.to_uint64())

    if not str_fmt_formula:
        return str_ret
    return f"{str_fmt_formula}({str_ret})"


def _make_number(plan: _RowPlan) -> Number:
    """Fast Number construction from precomputed type info."""
    num = Number.__new__(Number)
    num._py_value = 0
    num._raw_bytes = b""
    num._type = plan.ntype
    num._size = plan.nsize
    num._is_signed = plan.nsigned
    num._is_float_type = plan.nfloat
    return num


def _reset_number(num: Number, plan: _RowPlan) -> None:
    """Reuse a Number instance for a new field (type + clear value)."""
    num._py_value = 0
    num._raw_bytes = b""
    num._type = plan.ntype
    num._size = plan.nsize
    num._is_signed = plan.nsigned
    num._is_float_type = plan.nfloat


def _new_line(row: TeleMetryTableRowCfg, num: Number) -> TeleMetryLine:
    """Fast TeleMetryLine construction (bypasses dataclass __init__)."""
    out = TeleMetryLine.__new__(TeleMetryLine)
    out.err = False
    out.id = row.id
    out.name = row.name
    out.show = ""
    out.unit = ""
    out.hex = ""
    out.calc_val = 0
    out.val = num
    return out


def _reset_line(out: TeleMetryLine, row: TeleMetryTableRowCfg, num: Number) -> None:
    """Reuse a TeleMetryLine for a new field."""
    out.err = False
    out.id = row.id
    out.name = row.name
    out.show = ""
    out.unit = ""
    out.hex = ""
    out.calc_val = 0
    out.val = num


# ---------------------------------------------------------------------------
# Thread-local reuse of Line / Number / result list
# ---------------------------------------------------------------------------
# Same API signatures; the returned list and its TeleMetryLine/Number instances
# are reused on the next parse_frame() in this thread.
# Callers that keep previous results across another parse must copy what they need.

class _FrameScratch:
    __slots__ = ("lines",)

    def __init__(self) -> None:
        self.lines: list[TeleMetryLine] = []

    def ensure(self, n: int) -> list[TeleMetryLine]:
        """Grow/shrink in place; return the same list object every time."""
        from .number import NumberType, _TYPE_INFO

        lines = self.lines
        ntype = NumberType.INT64
        info = _TYPE_INFO[ntype]
        while len(lines) < n:
            num = Number.__new__(Number)
            num._py_value = 0
            num._raw_bytes = b""
            num._type = ntype
            num._size = info[0]
            num._is_signed = info[1]
            num._is_float_type = info[2]
            out = TeleMetryLine.__new__(TeleMetryLine)
            out.err = False
            out.id = ""
            out.name = ""
            out.show = ""
            out.unit = ""
            out.hex = ""
            out.calc_val = 0
            out.val = num
            lines.append(out)
        if len(lines) > n:
            del lines[n:]
        return lines


_tls = threading.local()


def _scratch() -> _FrameScratch:
    s = getattr(_tls, "frame_scratch", None)
    if s is None:
        s = _FrameScratch()
        _tls.frame_scratch = s
    return s


def _parse_row(
    plan: _RowPlan,
    row_cfg: TeleMetryTableRowCfg,
    storage: "bytes | bytearray",
    big_endian: bool,
    out: TeleMetryLine,
    num: Number,
    *,
    fill_show: bool = False,
) -> None:
    """
    Parse one field from raw frame bytes into ``out`` (plan-driven).

    ``fill_show``: also fill ``hex`` / ``show`` (UI path). Calc-only skips them.
    """
    kind = plan.kind
    bytepos = row_cfg.bytepos
    storage_len = len(storage)

    if kind == _KIND_INT:
        if plan.size_mismatch or bytepos >= storage_len:
            out.err = True
            return
        byte_count = plan.byte_count
        # Partial reads at end of buffer are zero-padded (short frames)
        raw = bytes(storage[bytepos: bytepos + byte_count])
        if len(raw) < byte_count:
            raw = raw + bytes(byte_count - len(raw))
        num.set_from_bytes(raw, big_endian)
        str_fmt_formula, formula_had_err = _apply_calc_val(plan, num, out)
        if fill_show:
            out.hex = raw.hex(" ").upper()
            out.show = _format_show_text(
                plan, row_cfg, num, "", out, str_fmt_formula, formula_had_err
            )
        return

    if kind == _KIND_BIT:
        # Direct byte access; multiple bit-fields may share the same byte
        if bytepos >= storage_len:
            out.err = True
            return
        sv = storage[bytepos]
        bits = row_cfg.bits
        v = (sv >> (8 - row_cfg.bitpos - bits)) & ((1 << bits) - 1)
        bit_str = format(v, plan.bit_fmt) + "b"
        num.value(v)
        str_fmt_formula, formula_had_err = _apply_calc_val(plan, num, out)
        if fill_show:
            # Bit hex is special: "<bits>b  0xHH" (field bits + full host byte)
            out.hex = f"{bit_str}  0x{sv:02X}"
            out.show = _format_show_text(
                plan, row_cfg, num, bit_str, out, str_fmt_formula, formula_had_err
            )
        return

    # _KIND_OTHER: oversized field (bits > 64) — hex display only
    byte_count = plan.byte_count
    if bytepos + byte_count > storage_len:
        out.err = True
        return
    raw = bytes(storage[bytepos: bytepos + byte_count])
    if fill_show:
        out.hex = raw.hex(" ").upper()
        out.show = "0x" + raw.hex().upper()


def _lines_to_calc_map(lines: list[TeleMetryLine]) -> dict[str, int | float]:
    """id → calc_val (empty ids skipped). For curve / numeric ingest."""
    out: dict[str, int | float] = {}
    for ln in lines:
        lid = ln.id
        if lid:
            out[lid] = ln.calc_val
    return out


def _parse_frame_rows(
    cfg: TeleMetryTableCfg,
    storage: "bytes | bytearray",
    big_endian: bool,
    plans: "list[tuple[TeleMetryTableRowCfg, _RowPlan]] | None",
    *,
    fill_show: bool,
    set_unit: bool,
) -> list[TeleMetryLine]:
    if plans is None:
        plans = [(row, _plan_of(row)) for row in cfg.row]
    lines = _scratch().ensure(len(plans))
    for idx, (row, plan) in enumerate(plans):
        row_out = lines[idx]
        num = row_out.val
        _reset_number(num, plan)
        _reset_line(row_out, row, num)
        _parse_row(
            plan, row, storage, big_endian, row_out, num,
            fill_show=fill_show,
        )
        if set_unit:
            row_out.unit = row.unit
    return lines


def parse_frame(
    cfg: TeleMetryTableCfg,
    data: "bytes | bytearray",
    big_endian_buffer: bool = True,
    plans: "list[tuple[TeleMetryTableRowCfg, _RowPlan]] | None" = None,
) -> list[TeleMetryLine]:
    """
    Parse a full frame into scratch ``TeleMetryLine`` objects with ``hex``/``show`` filled.

    Prefer ``TeleMetryCfgManager.parse`` (returns ``list[dict]`` snapshots).
    Scratch lines are overwritten on the next parse in this thread.
    """
    return _parse_frame_rows(
        cfg, data, big_endian_buffer, plans,
        fill_show=True, set_unit=True,
    )


def parse_frame_calc(
    cfg: TeleMetryTableCfg,
    data: "bytes | bytearray",
    big_endian_buffer: bool = True,
    plans: "list[tuple[TeleMetryTableRowCfg, _RowPlan]] | None" = None,
) -> dict[str, int | float]:
    """Parse a full frame to ``dict[id, calc_val]`` (no hex/show formatting)."""
    lines = _parse_frame_rows(
        cfg, data, big_endian_buffer, plans,
        fill_show=False, set_unit=False,
    )
    return _lines_to_calc_map(lines)


def row_cfg_from_dict(line_cfg: "TeleMetryTableRowCfg | dict") -> TeleMetryTableRowCfg:
    """
    Normalize a row config: accept TeleMetryTableRowCfg or a JSON-like dict
    (convenient for ad-hoc / unit tests).
    """
    if isinstance(line_cfg, TeleMetryTableRowCfg):
        return line_cfg
    if not isinstance(line_cfg, dict):
        raise TypeError(f"line_cfg must be TeleMetryTableRowCfg or dict, got {type(line_cfg)!r}")

    value = line_cfg.get("value", {}) or {}
    return TeleMetryTableRowCfg(
        no=line_cfg.get("no", 0),
        id=line_cfg.get("id", ""),
        name=line_cfg.get("name", ""),
        bytepos=line_cfg.get("bytepos", 0),
        bits=line_cfg.get("bits", 8),
        bitpos=line_cfg.get("bitpos", 0),
        showType=line_cfg.get("showType", 0),
        formula=line_cfg.get("formula", ""),
        unit=line_cfg.get("unit", ""),
        fmt=line_cfg.get("fmt", "%d"),
        value={str(k): str(v) for k, v in value.items()},
        dataType=line_cfg.get("dataType", "BYTE"),
        variableName=line_cfg.get("variableName", ""),
        tip=line_cfg.get("tip", ""),
    )


def parse_line(
    line_cfg: "TeleMetryTableRowCfg | dict",
    data: "bytes | bytearray",
    big_endian_buffer: bool = True,
) -> TeleMetryLine:
    """
    Parse a single telemetry field from raw bytes using one row config.

    Returns ``TeleMetryLine`` with ``hex`` / ``show`` / ``unit`` filled.
    """
    row_cfg = row_cfg_from_dict(line_cfg)
    plan = _plan_of(row_cfg)
    num = _make_number(plan)
    line = _new_line(row_cfg, num)
    _parse_row(
        plan, row_cfg, data, big_endian_buffer, line, num,
        fill_show=True,
    )
    line.unit = row_cfg.unit
    return line


def parse_line_hex(
    line_cfg: "TeleMetryTableRowCfg | dict",
    hex_str: str,
    big_endian_buffer: bool = True,
) -> TeleMetryLine:
    """Parse a single telemetry field from a hex string using one row config."""
    return parse_line(line_cfg, decode_hex(hex_str), big_endian_buffer)
