"""
Telemetry config / result dataclasses (mirrors C++ structs).

Bit-field ordering for parse uses the "terminal bit order" convention:
bit position 0 is the MSB of the byte (see telemetry_parse).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .number import Number


@dataclass(slots=True)
class TeleMetryLine:
    """
    One parsed telemetry field.

    Public fields: ``err``, ``id``, ``name``, ``show``, ``unit``, ``hex``,
    ``calc_val``, ``val``.
    """

    err:  bool   = False
    id:   str    = ""
    name: str    = ""
    show: str    = ""
    unit: str    = ""
    hex:  str    = ""
    # Numeric value after formula (if any), before value-map lookup for show.
    # Type follows fmt / dataType: int for integer formats, float for float formats.
    calc_val: int | float = 0
    val:  Number = field(default_factory=Number)

    def to_field_dict(self, *, unit: str | None = None) -> dict[str, Any]:
        """
        Snapshot for storage / display.

        Keys: id, name, value, calc_val, show, hex, unit.
        """
        raw = self.val.value() if self.val is not None else None
        calc = self.calc_val
        u = self.unit if unit is None else unit
        return {
            "id": self.id or "",
            "name": self.name or "",
            "value": raw,
            "calc_val": calc if calc is not None else raw,
            "show": self.show or "",
            "hex": self.hex or "",
            "unit": u or "",
        }


@dataclass
class TeleMetryTableRowCfg:
    no:           int         = 0
    id:           str         = ""
    name:         str         = ""
    bytepos:      int         = 0
    bits:         int         = 8
    bitpos:       int         = 0
    showType:     int         = 0
    formula:      str         = ""
    unit:         str         = ""
    fmt:          str         = "%d"
    value:        dict        = field(default_factory=dict)
    dataType:     str         = "BYTE"
    variableName: str         = ""
    tip:          str         = ""


@dataclass
class TeleMetryTableCfg:
    id:   str                      = ""
    name: str                      = ""
    row:  list[TeleMetryTableRowCfg] = field(default_factory=list)


@dataclass
class TeleMetryPageCfg:
    id:   int = 0
    name: str = ""
    key:  str = ""
