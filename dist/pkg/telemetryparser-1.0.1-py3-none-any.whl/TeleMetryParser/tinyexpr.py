"""
Python port of tinyexpr (C expression evaluator used by TeleMetry C++).

Evaluates telemetry formulas with variable ``D`` and a fixed math namespace.
Domain errors return ±inf/nan (tinyexpr-like), not exceptions.
Syntax / type errors return ``(0.0, True)``.
"""
from __future__ import annotations

import math
from functools import lru_cache
from typing import Any


def _safe_log(x: float) -> float:
    if x <= 0:
        return float("-inf") if x == 0 else float("nan")
    return math.log(x)


def _safe_sqrt(x: float) -> float:
    if x < 0:
        return float("nan")
    return math.sqrt(x)


def _safe_asin(x: float) -> float:
    if x < -1 or x > 1:
        return float("nan")
    return math.asin(x)


def _safe_acos(x: float) -> float:
    if x < -1 or x > 1:
        return float("nan")
    return math.acos(x)


# Safe math namespace for formula evaluation (replaces C tinyexpr builtins)
MATH_NS: dict[str, Any] = {
    "__builtins__": {},
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": _safe_asin,
    "acos": _safe_acos,
    "atan": math.atan,
    "atan2": math.atan2,
    "sinh": math.sinh,
    "cosh": math.cosh,
    "tanh": math.tanh,
    "sqrt": _safe_sqrt,
    "pow": math.pow,
    "exp": math.exp,
    "log": _safe_log,
    "ln": _safe_log,
    "log10": math.log10,
    "abs": abs,
    "fabs": abs,
    "ceil": math.ceil,
    "floor": math.floor,
    "pi": math.pi,
    "e": math.e,
}


def normalize_expression(expression: str) -> str:
    """Normalize tinyexpr syntax to Python (``^`` → ``**``)."""
    return expression.replace("^", "**")


@lru_cache(maxsize=4096)
def _compile_formula(expression: str):
    """Compile a formula once; identical strings reuse the code object."""
    return compile(normalize_expression(expression), "<formula>", "eval")


def exec_formula(expression: str, val: float) -> tuple[float, bool]:
    """
    Evaluate a tinyexpr-style formula with variable ``D = val``.

    Returns
    -------
    (result, had_error)
        Runtime math domain / overflow / zero-division → ±inf/nan, ``had_error=False``.
        Parse / syntax / unsupported ops → ``(0.0, True)``.

    Notes
    -----
    Bit-shift formulas (``D<<16>>16``) need an integer ``D``; if float eval
    raises ``TypeError``, the expression is retried with ``int(val)``.

    Compiled code objects are cached per expression string, and ``D`` is
    passed via locals so the shared math namespace is never copied.
    """
    try:
        code = _compile_formula(expression)
    except Exception:
        return 0.0, True

    try:
        return float(eval(code, MATH_NS, {"D": float(val)})), False  # noqa: S307
    except TypeError:
        # e.g. float << int — retry with integer D
        try:
            return float(eval(code, MATH_NS, {"D": int(val)})), False  # noqa: S307
        except (ZeroDivisionError, OverflowError):
            return float("inf"), False
        except Exception:
            return 0.0, True
    except (ZeroDivisionError, OverflowError):
        return float("inf"), False
    except Exception:
        return 0.0, True
