"""
Utility helpers for TeleMetryParser (CSV export).
"""
from __future__ import annotations

import csv
import datetime
import os
from typing import Any, Iterable, Mapping

from .telemetry_types import TeleMetryLine


def make_rsp_filename(key: str, dt: datetime.datetime | None = None) -> str:
    dt = dt or datetime.datetime.now()
    date_str = dt.strftime("%Y%m%d")
    return f"rsp_{key}_{date_str}.csv"


def _field_name(row: "TeleMetryLine | Mapping[str, Any]") -> str:
    return str(row.get("name") or "") if isinstance(row, Mapping) else row.name


def _cell_text(row: "TeleMetryLine | Mapping[str, Any]") -> str:
    """CSV / display cell: show value with unit appended when present."""
    if isinstance(row, Mapping):
        show = str(row.get("show") or "")
        unit = str(row.get("unit") or "")
    else:
        show = row.show
        unit = row.unit
    if unit:
        return f"{show} {unit}"
    return show


def save_lines_to_csv_append(
    path: str,
    lines: Iterable["TeleMetryLine | Mapping[str, Any]"],
) -> None:
    """
    Save one telemetry parse result into a CSV file.

    Accepts ``TeleMetryLine`` or field ``dict`` rows (from ``mgr.parse``).

    Rules:
    - If file does not exist OR exists but is empty:
      write header row then one data row.
    - If file exists AND has content:
      append one data row (insert a new line).
    """
    lines = list(lines)
    if not lines:
        return

    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)

    header_row = [_field_name(ln) for ln in lines]
    data_row = [_cell_text(ln) for ln in lines]

    file_exists = os.path.exists(path)
    file_has_content = file_exists and os.path.getsize(path) > 0

    if not file_has_content:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(header_row)
            w.writerow(data_row)
        return

    with open(path, "rb+") as fb:
        fb.seek(0, os.SEEK_END)
        size = fb.tell()
        if size > 0:
            fb.seek(-1, os.SEEK_END)
            last = fb.read(1)
            if last not in (b"\n", b"\r"):
                fb.write(b"\n")

    with open(path, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(data_row)
