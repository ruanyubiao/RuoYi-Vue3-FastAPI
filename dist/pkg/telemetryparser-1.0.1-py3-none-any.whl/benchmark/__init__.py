# TeleMetryParser benchmarks (parse-only).
# Run: python -m benchmark.bench_parse
