# -*- coding: utf-8 -*-
"""
TeleMetryParser parse-path benchmarks (no file I/O inside timed loops).

Groups
------
  API     : parse / parse_calc / parse_line*
  FORMULA : exec_formula

Stress scenarios (p50/p90/p99/max):
  - sustained full-frame parsing
  - multi-table key rotation
  - truncated / empty frames (must not raise)

Extras:
  - --target-mbps  : required-frame-rate coverage vs a line-rate target
  - --duration     : run stress by wall-time seconds instead of iterations
  - memory stability check (tracemalloc, net growth after GC)
  - regression gates: --assert-min-fps / --baselines

Usage
-----
    python -m benchmark.bench_parse
    python -m benchmark.bench_parse --iters 5000 --stress 20000
    python -m benchmark.bench_parse --baselines benchmark/baselines.json
    python -m benchmark.bench_parse --target-mbps 60
    python -m benchmark.bench_parse --duration 30
"""
from __future__ import annotations

import argparse
import gc
import json
import statistics
import sys
import time
import tracemalloc
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TeleMetryParser import (  # noqa: E402
    TeleMetryCfgManager,
    decode_hex,
    exec_formula,
    parse_line,
    parse_line_hex,
)

CFG_PATH = ROOT / "json" / "BIU-TeleMetryCfg.json"
DEFAULT_BASELINES = Path(__file__).resolve().parent / "baselines.json"

FF_PAYLOAD_HEX = (
    "33 00 00 00 00 00 00 00 00 00 45 00 DC 00 00 00 00 00 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 09 08 00 00 00 00 00 00 00 00 00 00 6E 4C 71 A2 05 "
    "97 00 81 00 00 00 02 11 01 C8 0C B1 42 70 00 00 3F 2D 74 BE 44 C3 61 9A 41 "
    "6E BF 80 00 00 6D C3 80 26 00 00 55 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 00 00 01 00 02 00 21 1F AA AA AA AA 00 00 00 00 00 "
    "00 30 FF 0C 00 FC 00 00 10 00 00 00 00 00 00 03 00 CC 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 4C"
)

LINE_CFG_SIMPLE = {
    "id": "BENCH_INT32",
    "bytepos": 0,
    "bits": 32,
    "formula": "D / 10000",
    "fmt": "%g",
    "dataType": "INT32",
}
LINE_HEX_SIMPLE = "00 11 00 04"

FORMULA_HEAVY = (
    "2*(-129921.0132)/(-4185.7536+sqrt(pow(4185.7536,2)"
    "-4*(-129921.0132)*(-3.3672-ln(10000*D/(65535-D)))))-273.15"
)
FORMULA_SIMPLE = "D / 10000"
FORMULA_D = 30000.0

GROUP_API = "API"
GROUP_FORMULA = "FORMULA"


@dataclass
class BenchResult:
    name: str
    group: str
    iterations: int
    total_s: float
    per_call_us: float
    ops_per_s: float
    notes: str = ""


def _time_loop(fn, iterations: int, warmup: int = 20) -> float:
    for _ in range(warmup):
        fn()
    t0 = time.perf_counter()
    for _ in range(iterations):
        fn()
    return time.perf_counter() - t0


def _make_result(name: str, group: str, iterations: int, total_s: float,
                 notes: str = "") -> BenchResult:
    per = (total_s / iterations) * 1e6 if iterations else 0.0
    ops = iterations / total_s if total_s > 0 else 0.0
    return BenchResult(name, group, iterations, total_s, per, ops, notes)


def _stress_chunked(fn_one, iterations: int, duration_s: float | None = None,
                    chunk: int | None = None) -> tuple[float, list[float], int]:
    """
    Run ``fn_one`` repeatedly, chunked; return (total_s, per-call samples, count).
    If duration_s is given it takes precedence over iterations.
    """
    chunk = chunk or max(100, iterations // 20)
    samples: list[float] = []
    done = 0
    t0_all = time.perf_counter()
    while True:
        if duration_s is not None:
            if time.perf_counter() - t0_all >= duration_s:
                break
            n = chunk
        else:
            if done >= iterations:
                break
            n = min(chunk, iterations - done)
        t0 = time.perf_counter()
        for _ in range(n):
            fn_one()
        dt = time.perf_counter() - t0
        samples.append(dt / n)
        done += n
    return time.perf_counter() - t0_all, samples, done


def _latency_notes(samples: list[float]) -> str:
    if not samples:
        return ""
    ordered = sorted(samples)
    n = len(ordered)
    p50 = statistics.median(ordered) * 1e6
    p90 = ordered[min(n - 1, int(n * 0.9))] * 1e6
    p99 = ordered[min(n - 1, int(n * 0.99))] * 1e6
    mx = ordered[-1] * 1e6
    return f"p50={p50:.1f}us p90={p90:.1f}us p99={p99:.1f}us max={mx:.1f}us"


def setup_manager() -> TeleMetryCfgManager:
    """Load config once (file I/O outside timed sections)."""
    TeleMetryCfgManager._instance = None
    mgr = TeleMetryCfgManager.instance()
    if not mgr.init(str(CFG_PATH)):
        raise RuntimeError(f"failed to load {CFG_PATH}")
    return mgr


def collect_formulas() -> list[str]:
    """Load formulas from JSON once (not timed)."""
    data = json.loads(CFG_PATH.read_text(encoding="utf-8"))
    seen: set[str] = set()
    uniq: list[str] = []
    for tbl in data.get("table", {}).values():
        for row in tbl.get("row", []):
            f = (row.get("formula") or "").strip()
            if f and f != "D" and f not in seen:
                seen.add(f)
                uniq.append(f)
    return uniq


def memory_stability(fn_one, frames_n: int = 3000) -> tuple[int, int]:
    """
    Run fn_one frames_n times under tracemalloc.
    Returns (net_growth_bytes_after_gc, peak_bytes).
    """
    gc.collect()
    tracemalloc.start()
    base, _ = tracemalloc.get_traced_memory()
    for _ in range(frames_n):
        fn_one()
    gc.collect()
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return cur - base, peak


def run_benchmarks(iters: int, stress_iters: int,
                   duration_s: float | None) -> tuple[list[BenchResult], dict]:
    results: list[BenchResult] = []
    extra: dict = {}

    print("=== Setup (not timed): load config + prepare buffers ===")
    t_setup0 = time.perf_counter()
    mgr = setup_manager()
    cfg_ff = mgr.get_table_cfg_by_key("FF")
    assert cfg_ff is not None
    n_fields = len(cfg_ff.row)

    payload_bytes = bytes(decode_hex(FF_PAYLOAD_HEX))
    truncated_bytes = payload_bytes[: max(16, len(payload_bytes) // 3)]
    extra["frame_bytes"] = len(payload_bytes)

    table_keys = [p.key for p in mgr.get_page_list() if mgr.get_table_cfg_by_key(p.key)]
    if not table_keys:
        table_keys = ["FF"]

    row_heavy = next(
        (r for r in cfg_ff.row if r.formula and "ln" in r.formula), cfg_ff.row[0]
    )
    formulas = collect_formulas()
    t_setup = time.perf_counter() - t_setup0
    print(
        f"  tables={len(table_keys)}, FF fields={n_fields}, formulas={len(formulas)}, "
        f"payload={len(payload_bytes)}B, setup={t_setup * 1000:.1f} ms\n"
    )

    # ------------------------------------------------------------------
    # API benches
    # ------------------------------------------------------------------

    def _parse():
        mgr.parse("FF", payload_bytes, True)

    total = _time_loop(_parse, iters)
    results.append(_make_result(
        "parse(FF)", GROUP_API, iters, total,
        notes=f"{n_fields} fields; list[dict] hex/show"))

    def _parse_calc():
        mgr.parse_calc("FF", payload_bytes, True)

    total = _time_loop(_parse_calc, iters)
    results.append(_make_result(
        "parse_calc(FF)", GROUP_API, iters, total,
        notes="dict[id, calc_val]"))

    def _parse_cfg():
        mgr.parse(cfg_ff, payload_bytes, True)

    total = _time_loop(_parse_cfg, iters)
    results.append(_make_result(
        "parse(cfg, buf) FF", GROUP_API, iters, total,
        notes="table cfg pre-resolved"))

    def _parse_line_hex():
        parse_line_hex(LINE_CFG_SIMPLE, LINE_HEX_SIMPLE)

    total = _time_loop(_parse_line_hex, iters * 10)
    results.append(_make_result(
        "parse_line_hex(INT32 D/10000)", GROUP_API, iters * 10, total,
        notes="single field + hex decode"))

    line_buf_bytes = bytes.fromhex(LINE_HEX_SIMPLE.replace(" ", ""))

    def _parse_line_buf():
        parse_line(LINE_CFG_SIMPLE, line_buf_bytes, True)

    total = _time_loop(_parse_line_buf, iters * 10)
    results.append(_make_result(
        "parse_line(INT32 D/10000)", GROUP_API, iters * 10, total,
        notes="single field, no hex decode"))

    def _parse_line_heavy():
        parse_line(row_heavy, payload_bytes, True)

    total = _time_loop(_parse_line_heavy, iters * 5)
    results.append(_make_result(
        f"parse_line(heavy cfg {row_heavy.id})", GROUP_API, iters * 5, total,
        notes="formula with ln/sqrt/pow"))

    # ------------------------------------------------------------------
    # Formula engine
    # ------------------------------------------------------------------

    def _f_simple():
        exec_formula(FORMULA_SIMPLE, FORMULA_D)

    total = _time_loop(_f_simple, iters * 50)
    results.append(_make_result(
        "exec_formula(D/10000)", GROUP_FORMULA, iters * 50, total))

    def _f_heavy():
        exec_formula(FORMULA_HEAVY, FORMULA_D)

    total = _time_loop(_f_heavy, iters * 20)
    results.append(_make_result(
        "exec_formula(NTC-like heavy)", GROUP_FORMULA, iters * 20, total))

    def _f_all_json():
        for f in formulas:
            exec_formula(f, 1000.0)

    formula_iters = max(50, iters // 5)
    total = _time_loop(_f_all_json, formula_iters, warmup=5)
    results.append(_make_result(
        "exec_formula(all BIU unique formulas x1)", GROUP_FORMULA, formula_iters, total,
        notes=f"{len(formulas)} formulas per iteration"))

    # ------------------------------------------------------------------
    # Stress
    # ------------------------------------------------------------------

    mode = f"{duration_s}s wall-time" if duration_s else f"{stress_iters} iters"
    print(f"=== Stress: parse_calc(FF), {mode} ===")

    def _one_old():
        mgr.parse_calc("FF", payload_bytes, True)

    t_st, samples, done = _stress_chunked(_one_old, stress_iters, duration_s)
    results.append(_make_result(
        "STRESS parse_calc(FF)", GROUP_API, done, t_st, notes=_latency_notes(samples)))
    print(f"  done: {done / t_st:.0f} frames/s\n")

    print(f"=== Stress: parse(FF), {mode} ===")

    def _one_full():
        mgr.parse("FF", payload_bytes, True)

    t_st_s, samples_s, done_s = _stress_chunked(_one_full, stress_iters, duration_s)
    results.append(_make_result(
        "STRESS parse(FF)", GROUP_API, done_s, t_st_s,
        notes=_latency_notes(samples_s)))
    print(f"  done: {done_s / t_st_s:.0f} frames/s\n")

    # multi-table rotation
    multi_iters = max(stress_iters // 2, 1000)
    print(f"=== Stress: multi-table rotate x {multi_iters}, {len(table_keys)} keys ===")
    key_cycle = list(table_keys)
    state = {"i": 0}

    def _one_multi():
        key = key_cycle[state["i"] % len(key_cycle)]
        state["i"] += 1
        mgr.parse_calc(key, payload_bytes, True)

    t_multi, samples_m, done_m = _stress_chunked(_one_multi, multi_iters)
    results.append(_make_result(
        "STRESS multi-table rotate", GROUP_API, done_m, t_multi,
        notes=f"{len(key_cycle)} keys; {_latency_notes(samples_m)}"))
    print(f"  done: {done_m / t_multi:.0f} ops/s\n")

    # truncated / empty frames
    trunc_iters = max(stress_iters // 2, 1000)
    print(f"=== Stress: truncated/empty frames x {trunc_iters} ===")
    trunc_variants = (truncated_bytes, b"", payload_bytes[:8], payload_bytes[:1])
    tstate = {"i": 0}

    def _one_trunc():
        raw = trunc_variants[tstate["i"] % len(trunc_variants)]
        tstate["i"] += 1
        mgr.parse_calc("FF", raw, True)

    t_trunc, samples_t, done_t = _stress_chunked(_one_trunc, trunc_iters)
    results.append(_make_result(
        "STRESS truncated frame", GROUP_API, done_t, t_trunc,
        notes=f"short/empty variants; no raise; {_latency_notes(samples_t)}"))
    print(f"  done: {done_t / t_trunc:.0f} ops/s (no exceptions)\n")

    # ------------------------------------------------------------------
    # Memory stability
    # ------------------------------------------------------------------

    print("=== Memory stability (tracemalloc, 3000 frames each) ===")
    growth_old, peak_old = memory_stability(_one_old)
    extra["mem"] = (growth_old, peak_old)
    print(f"  parse_calc : net growth {growth_old / 1024:.1f} KB, peak {peak_old / 1024:.1f} KB\n")

    return results, extra


def print_table(results: list[BenchResult]) -> None:
    print(f"{'group':<8} {'name':<40} {'iters':>8} {'total_s':>9} {'us/call':>9} {'ops/s':>10}  notes")
    print("-" * 130)
    for r in results:
        print(
            f"{r.group:<8} {r.name:<40} {r.iterations:>8} {r.total_s:>9.4f} "
            f"{r.per_call_us:>9.2f} {r.ops_per_s:>10.0f}  {r.notes}"
        )


def check_gates(results: list[BenchResult], assert_min_fps: float | None,
                baselines_path: Path | None) -> list[str]:
    failures: list[str] = []
    by_name = {r.name: r for r in results}

    min_fps = assert_min_fps
    min_ops: dict[str, float] = {}

    if baselines_path is not None:
        if not baselines_path.is_file():
            failures.append(f"baselines file not found: {baselines_path}")
            return failures
        data = json.loads(baselines_path.read_text(encoding="utf-8"))
        if min_fps is None and "assert_min_fps" in data:
            min_fps = float(data["assert_min_fps"])
        min_ops = {str(k): float(v) for k, v in (data.get("min_ops_per_s") or {}).items()}

    if min_fps is not None:
        st = by_name.get("STRESS parse_calc(FF)")
        if st is None:
            failures.append("assert-min-fps: missing STRESS parse_calc(FF) result")
        elif st.ops_per_s < min_fps:
            failures.append(
                f"assert-min-fps: STRESS parse_calc(FF) {st.ops_per_s:.0f} ops/s "
                f"< required {min_fps:.0f}")

    for name, required in min_ops.items():
        r = by_name.get(name)
        if r is None:
            failures.append(f"baselines: missing metric '{name}'")
        elif r.ops_per_s < required:
            failures.append(f"baselines: {name} {r.ops_per_s:.0f} ops/s < min {required:.0f}")

    return failures


def target_coverage(results: list[BenchResult], target_mbps: float,
                    frame_bytes: int) -> list[str]:
    """Human-readable coverage lines for a line-rate target."""
    need_fps = target_mbps * 1e6 / 8.0 / frame_bytes
    lines = [
        f"目标线速 {target_mbps:g} Mbps，帧长 {frame_bytes} B → 需求 **{need_fps:,.0f} 帧/s**"
        f"（每帧预算 {1e6 / need_fps:.1f} us）",
    ]
    for name in ("STRESS parse_calc(FF)",):
        r = next((x for x in results if x.name == name), None)
        if r is None:
            continue
        pct = r.ops_per_s / need_fps * 100.0
        verdict = "满足" if pct >= 100.0 else "不满足"
        lines.append(
            f"- {name}: {r.ops_per_s:,.0f} 帧/s → 覆盖 **{pct:.1f}%**（{verdict}）"
        )
    return lines


def write_baselines(results: list[BenchResult], path: Path,
                    assert_min_fps: float | None) -> None:
    min_ops = {r.name: int(r.ops_per_s * 0.7) for r in results if r.ops_per_s > 0}
    st = next((r for r in results if r.name == "STRESS parse_calc(FF)"), None)
    payload = {
        "_comment": "Auto-generated; values are ~70% of measured ops/s. Edit before committing.",
        "assert_min_fps": int(
            assert_min_fps if assert_min_fps is not None
            else (st.ops_per_s * 0.7 if st else 2000)),
        "min_ops_per_s": min_ops,
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Baselines written: {path}")


def write_report(results: list[BenchResult], extra: dict, path: Path,
                 iters: int, stress_iters: int,
                 target_mbps: float | None) -> None:
    import platform

    py = sys.version.replace("\n", " ")
    lines = [
        "# TeleMetryParser 解析性能评估报告",
        "",
        f"- 生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- Python: `{py}`",
        f"- Platform: `{platform.platform()}`",
        f"- Machine: `{platform.machine()}` / `{platform.processor() or 'n/a'}`",
        f"- 配置: `{CFG_PATH.name}`（仅 setup 读一次，**不计入**计时）",
        f"- 参数: iters={iters}, stress_iters={stress_iters}",
        "",
        "## 测试范围",
        "",
        "- **解析 API**：`parse` / `parse_calc` / `parse_line*`",
        "- **压力扩展**：整表持续解析、多表 key 轮询、短帧/空帧（不崩溃）",
        "- **不包含**：配置文件反复读取、CSV 写盘、UI",
        "- Setup 阶段一次性加载 JSON、准备 payload 字节；计时循环内不再访问磁盘",
        "",
    ]

    for group, title in ((GROUP_API, "解析接口"),
                         (GROUP_FORMULA, "公式引擎")):
        rows = [r for r in results if r.group == group]
        if not rows:
            continue
        lines.extend([
            f"## {title}",
            "",
            "| 场景 | 迭代次数 | 总耗时 (s) | 单次 (µs) | 吞吐 (ops/s) | 备注 |",
            "|------|----------|------------|-----------|--------------|------|",
        ])
        for r in rows:
            lines.append(
                f"| {r.name} | {r.iterations} | {r.total_s:.4f} | "
                f"{r.per_call_us:.2f} | {r.ops_per_s:.0f} | {r.notes} |")
        lines.append("")

    # Memory stability
    if "mem" in extra:
        go, po = extra["mem"]
        lines.extend([
            "## 内存稳定性（tracemalloc）",
            "",
            f"- `parse_calc` × 3000 帧：净增长 **{go / 1024:.1f} KB**，峰值 {po / 1024:.1f} KB",
            "- 净增长接近 0 说明长跑无对象泄漏（结果即用即弃场景）。",
            "",
        ])

    # Target coverage
    if target_mbps:
        lines.extend(["## 线速覆盖评估", ""])
        lines.extend(target_coverage(results, target_mbps, extra.get("frame_bytes", 196)))
        lines.append("")

    by_name = {r.name: r for r in results}
    st = by_name.get("STRESS parse_calc(FF)")

    # Optimization history (fixed reference points, same machine)
    lines.extend([
        "## 历次优化对比（同机参考值，parse_calc 整表 FF）",
        "",
        "| 版本 | 单次 (µs/帧) | 吞吐 (帧/s) | 说明 |",
        "|------|--------------|-------------|------|",
        "| C++ 直译初版 | 545 | 1,834 | 每次 eval 编译公式、手工字节翻转、逐字节 hex |",
        "| 第一轮 Pythonic 化 | 283 | 3,529 | 公式编译缓存、bytes.fromhex/.hex、直接大端解包 |",
        "| 按行预编译计划 + include_show | 233 | 4,290 | 行级 plan、快速构造；默认不生成 show |",
        "| 线程内复用 Line/Number/list | 164 | 6,099 | 单帧路径复用结果对象 |",
    ])
    if st:
        lines.append(
            f"| 本轮实测 | {st.per_call_us:.0f} | "
            f"{st.ops_per_s:,.0f} | stress `parse_calc(FF)` |")
    lines.append("")

    lines.extend(["## 评估结论", ""])
    if st:
        lines.append(
            f"1. **`parse_calc`** 持续 **{st.ops_per_s:,.0f} 帧/s**"
            f"（{st.per_call_us:.1f} µs/帧；{st.notes}）。")
    st_full = by_name.get("STRESS parse(FF)")
    pb0 = by_name.get("parse_calc(FF)")
    pb1 = by_name.get("parse(FF)")
    if st_full and st and st_full.ops_per_s > 0:
        gain = (st.ops_per_s / st_full.ops_per_s - 1.0) * 100.0
        lines.append(
            f"2. **API**：parse_calc vs parse → stress **{st.ops_per_s:,.0f}** / "
            f"**{st_full.ops_per_s:,.0f}** 帧/s（calc 约快 **{gain:.0f}%**）。")
    if pb0 and pb1 and pb1.per_call_us > 0:
        lines.append(
            f"   - 单次基准：`parse_calc` {pb0.per_call_us:.1f} µs，"
            f"`parse` {pb1.per_call_us:.1f} µs。")
    lines.extend([
        "3. 同线程连续单帧解析会覆盖上一次返回对象；需保留历史请自行拷贝字段。"
        "剩余耗时主要在每字段字节切片/`hex`/公式求值。",
        "",
        "## 回归门槛与复现",
        "",
        "```bash",
        f"python -m benchmark.bench_parse --iters {iters} --stress {stress_iters} "
        "--baselines benchmark/baselines.json",
        "python -m benchmark.bench_parse --target-mbps 60",
        "python -m benchmark.bench_parse --duration 30",
        "```",
        "",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\nReport written: {path}")


def main() -> None:
    ap = argparse.ArgumentParser(description="TeleMetryParser parse benchmarks")
    ap.add_argument("--iters", type=int, default=2000, help="base iterations for main benches")
    ap.add_argument("--stress", type=int, default=10000, help="stress iterations")
    ap.add_argument("--duration", type=float, default=None,
                    help="run main stress scenarios for N seconds instead of --stress iters")
    ap.add_argument("--target-mbps", type=float, default=None,
                    help="line-rate target (Mbps); report required fps and coverage")
    ap.add_argument("--report", type=str, default=str(ROOT / "benchmark" / "REPORT.md"))
    ap.add_argument("--assert-min-fps", type=float, default=None,
                    help="fail if STRESS parse_calc(FF) ops/s is below this value")
    ap.add_argument("--baselines", type=str, default=None,
                    help="JSON file with min_ops_per_s / assert_min_fps gates")
    ap.add_argument("--write-baselines", type=str, default=None,
                    help="write measured ops/s * 0.7 as a new baselines JSON")
    args = ap.parse_args()

    results, extra = run_benchmarks(args.iters, args.stress, args.duration)
    print("=== Results ===")
    print_table(results)

    if args.target_mbps:
        print("\n=== Target coverage ===")
        for line in target_coverage(results, args.target_mbps, extra.get("frame_bytes", 196)):
            print("  " + line.replace("**", ""))

    write_report(results, extra, Path(args.report), args.iters, args.stress, args.target_mbps)

    if args.write_baselines:
        write_baselines(results, Path(args.write_baselines), args.assert_min_fps)

    baselines_path = Path(args.baselines) if args.baselines else None
    failures = check_gates(results, args.assert_min_fps, baselines_path)
    if failures:
        print("\n=== GATE FAILURES ===")
        for msg in failures:
            print(f"  FAIL: {msg}")
        sys.exit(1)
    if baselines_path or args.assert_min_fps is not None:
        print("\n=== Gates: PASS ===")


if __name__ == "__main__":
    main()
